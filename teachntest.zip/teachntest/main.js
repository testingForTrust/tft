(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	var module = __webpack_require__(id);
	return module;
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/_services/project-creation.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/_services/project-creation.service.ts ***!
  \*******************************************************/
/*! exports provided: ProjectCreationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectCreationService", function() { return ProjectCreationService; });
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};



var ProjectCreationService = /** @class */ (function () {
    function ProjectCreationService(http, http2) {
        this.http = http;
        this.http2 = http2;
    }
    ProjectCreationService.prototype.getHttpResponse = function (args) {
        return __awaiter(this, void 0, void 0, function () {
            var observable_Response, response, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        observable_Response = this.http2.get(args, { responseType: 'text' });
                        return [4 /*yield*/, observable_Response.toPromise()];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 2:
                        e_1 = _a.sent();
                        return [4 /*yield*/, 'error'];
                    case 3: return [2 /*return*/, _a.sent()];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    ProjectCreationService.prototype.extractCsvData = function (res) {
        var csvData = res['_body'] || '';
        var allTextLines = csvData.split(/\r\n|\n/);
        var headers = allTextLines[0].split(',');
        var lines = [];
        for (var i = 1; i < allTextLines.length; i++) {
            // split content based on comma
            if (allTextLines[i]) {
                var data = allTextLines[i].split(',');
                if (data.length == headers.length) {
                    var tarr = [];
                    for (var j = 0; j < headers.length; j++) {
                        tarr.push(data[j]);
                    }
                    lines.push(tarr);
                }
            }
        }
        return lines;
    };
    ProjectCreationService.prototype.extractCsvDataForovarallResponse = function (res) {
        var csvData = res['_body'] || '';
        if (!csvData) {
            csvData = res[0]['_body'] || '';
        }
        var allTextLines = csvData.split(/\r\n|\n/);
        var headers = allTextLines[0].split(',');
        var lines = [];
        for (var i = 1; i < allTextLines.length; i++) {
            // split content based on comma
            if (allTextLines[i]) {
                var data = allTextLines[i].split(',');
                if (data.length == headers.length) {
                    var tarr = [];
                    for (var j = 0; j < headers.length; j++) {
                        tarr.push(data[j]);
                    }
                    lines.push(tarr);
                }
            }
        }
        return lines;
    };
    ProjectCreationService.prototype.extractData = function (res) {
        var filteredData = [];
        var classMatricsData = this.extractCsvData(res);
        for (var i = 0; i < classMatricsData.length; i++) {
            for (var j = 0; j < classMatricsData[i].length; j++) {
                if (isNaN(classMatricsData[i][j])) {
                    //console.log("This is String ",this.classMatricsData[i][j])
                }
                else {
                    classMatricsData[i][j] = Math.round((Math.round((classMatricsData[i][j] * 1 + 0.00001) * 100) / 100) * 100);
                }
            }
        }
        var tempRecall = [];
        for (var i = 0; i < classMatricsData.length; i++) {
            if (classMatricsData[i][6].toUpperCase() == 'TRUE') {
                tempRecall[i] = 'red';
            }
            else {
                tempRecall[i] = 'green';
            }
        }
        for (var i = 0; i < classMatricsData.length; i++) {
            var record = {
                className: classMatricsData[i][0],
                originalExample: classMatricsData[i][4],
                adversarialExample: classMatricsData[i][5],
                diffRecall: tempRecall[i]
            };
            filteredData.push(record);
        }
        // this.showDetailTable = true
        return filteredData;
        //sessionStorage.setItem('filterClassMatricsData',JSON.stringify(filteredData));
    };
    ProjectCreationService.prototype.extractRNTData = function (res) {
        var filteredData = [];
        var classMatricsData = this.extractCsvData(res);
        for (var i = 0; i < classMatricsData.length; i++) {
            for (var j = 0; j < classMatricsData[i].length; j++) {
                if (isNaN(classMatricsData[i][j])) {
                    //console.log("This is String ",this.classMatricsData[i][j])
                }
                else {
                    classMatricsData[i][j] = Math.round((Math.round((classMatricsData[i][j] * 1 + 0.00001) * 100) / 100) * 100);
                }
            }
        }
        var tempRecall = [];
        for (var i = 0; i < classMatricsData.length; i++) {
            if (classMatricsData[i][5].toUpperCase() == 'TRUE') {
                tempRecall[i] = 'red';
            }
            else {
                tempRecall[i] = 'green';
            }
        }
        for (var i = 0; i < classMatricsData.length; i++) {
            var record = {
                className: classMatricsData[i][0],
                originalExample: classMatricsData[i][3],
                adversarialExample: classMatricsData[i][4],
                diffRecall: tempRecall[i]
            };
            filteredData.push(record);
        }
        // this.showDetailTable = true
        return filteredData;
        //sessionStorage.setItem('filterClassMatricsData',JSON.stringify(filteredData));
    };
    ProjectCreationService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"], _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ProjectCreationService);
    return ProjectCreationService;
}());



/***/ }),

/***/ "./src/app/_services/text-class-serve.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/_services/text-class-serve.service.ts ***!
  \*******************************************************/
/*! exports provided: TextClassServeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TextClassServeService", function() { return TextClassServeService; });
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var TextClassServeService = /** @class */ (function () {
    function TextClassServeService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({}),
            responseType: 'text'
        };
    }
    TextClassServeService.prototype.getHttpResponse = function (args) {
        return this.http.get(args);
    };
    TextClassServeService.prototype.extractCsvData = function (res) {
        var csvData = res['_body'] || '';
        var allTextLines = csvData.split(/\r\n/);
        var lines = [];
        //console.log("allTextLines-- ", allTextLines[0])
        for (var i = 1; i < allTextLines.length; i++) {
            if (allTextLines[i])
                lines.push(allTextLines[i]);
        }
        return lines;
    };
    TextClassServeService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"]])
    ], TextClassServeService);
    return TextClassServeService;
}());



/***/ }),

/***/ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.adversarialsetting-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -165px 0px 0px -175px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.adversarialsetting-header{\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  text-align: center;\r\n  margin: 10px 0px 20px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n.adversarialsetting-option-wrap{\r\n  margin: 0px 0px 10px 0px;\r\n  text-align: center;\r\n}\r\n\r\n.adversarialsetting-option-wrap label{\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  width: 90px;\r\n  display: inline-block;\r\n  text-align: left;\r\n}\r\n\r\n.adversarialsetting-option-wrap input{\r\n  width: 240px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n.adversarialsetting-option-wrap p{\r\n  width: 240px;\r\n  float: right;\r\n  font-size: 11px;\r\n  text-align: left;\r\n  margin: 5px 0px\r\n}\r\n\r\n.adversarialsetting-option-wrap  title{\r\n  font-size: 11px;\r\n  text-align: left;\r\n}\r\n\r\n.adversarialsetting-option-wrap select {\r\n    width: 240px;\r\n    height: 28px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    font-family: 'Arial';\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n.methodoption-subsetting{\r\n  margin: 0px 0px 10px 90px;\r\n}\r\n\r\n.methodoption-subsetting input{\r\n  width: 150px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n.methodoption-subsetting select{\r\n  width: 150px;\r\n}\r\n\r\n.adversarialsetting-option-wrap button{\r\n  display: inline-block;\r\n  font-size: 15px;\r\n  padding: 5px 20px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.96);\r\n  border: none;\r\n  margin: 15px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n.tooltip {\r\n    position: relative;\r\n\r\n}\r\n\r\n.tooltip .tooltiptext {\r\n    visibility: hidden;\r\n    width: 340px;\r\n    background: rgba(10, 10, 10, 1);\r\n    color: #fff;\r\n    text-align: left;\r\n    border-radius: 6px;\r\n    padding: 5px;\r\n    font-size: 12px;\r\n    line-height: 14px;\r\n    font-weight: 400;\r\n\r\n    /* Position the tooltip */\r\n    position: absolute;\r\n    bottom: 150%;\r\n    left: 50%;\r\n    margin-left: -170px;\r\n    z-index: 1;\r\n}\r\n\r\n.tooltip:hover .tooltiptext {\r\n    visibility: visible;\r\n}\r\n\r\n.tooltip .tooltiptext::after {\r\n    content: \" \";\r\n    position: absolute;\r\n    top: 100%; /* At the bottom of the tooltip */\r\n    left: 50%;\r\n    margin-left: -5px;\r\n    border-width: 5px;\r\n    border-style: solid;\r\n    border-color: black transparent transparent transparent;\r\n}\r\n\r\n.setting-cont{\r\n  clear: both;\r\n  width: 100%;\r\n}\r\n\r\n.settings-cont-row{\r\n  margin: 5px 0px 5px 0px;\r\n}\r\n\r\n.settings-cont-row label{\r\n  width: 220px; \r\n  float: left;\r\n  padding: 2px 0px;\r\n}\r\n\r\n.setting-value{\r\n  float: left;\r\n  background: rgba(213, 213, 213, 0.98);\r\n  border: solid 1px rgba(176, 176, 176, 0.97);\r\n  padding: 2px 10px;\r\n  width: 100px;\r\n  overflow: hidden;\r\n}\r\n"

/***/ }),

/***/ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.html":
/*!****************************************************************************************!*\
  !*** ./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog adversarialsetting-bg\">\r\n    <div class=\"adversarialsetting-wrap\">\r\n      <div class=\"adversarialsetting-header\">Settings</div>\r\n      <div class=\"setting-cont\">\r\n        <div class=\"settings-cont-row\" *ngFor=\"let head of AdvSettings.settingHeader; let i=index\">\r\n            <label class=\"tooltip\" >{{ head }} <i class=\"fa fa-info-circle\"></i>\r\n              <span class=\"tooltiptext\"> {{ AdvSettings.settingLabels[i] }} </span>\r\n            </label>\r\n            <div class=\"setting-value\" title=\"{{ AdvSettings.settingValues[i] }}\">{{ AdvSettings.settingValues[i] }}</div>\r\n            <div class=\"clearfix\"></div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n      </div>\r\n    </div>\r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div></div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.ts ***!
  \**************************************************************************************/
/*! exports provided: AdversarialInputsSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdversarialInputsSettingsComponent", function() { return AdversarialInputsSettingsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AdversarialInputsSettingsComponent = /** @class */ (function () {
    function AdversarialInputsSettingsComponent() {
        this.methodv = "fgsm";
        this.displayFGSMOptions = true;
        this.displayJSMAOptions = false;
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.adversarialSettingsValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.AdvSettings = {};
        this.adset = false;
        this.tresholdv = 0;
        this.epsilonv = 0;
        this.targetedv = false;
        this.thetadv = 0;
        this.gammav = 0;
        this.model = { "threshold": this.tresholdv, "eps": this.epsilonv, "targeted": this.targetedv };
    }
    // this.model = {};
    AdversarialInputsSettingsComponent.prototype.thresholdValueChange = function ($event) {
        this.tresholdv = this.model.threshold;
    };
    AdversarialInputsSettingsComponent.prototype.epsilonValueChange = function ($event) {
        this.epsilonv = this.model.eps;
    };
    AdversarialInputsSettingsComponent.prototype.targetedValueChange = function ($event) {
        this.targetedv = this.model.targeted;
    };
    AdversarialInputsSettingsComponent.prototype.thetaValueChange = function ($event) {
        this.thetadv = this.model.theta;
    };
    AdversarialInputsSettingsComponent.prototype.gammaValueChange = function ($event) {
        this.gammav = this.model.gamma;
    };
    AdversarialInputsSettingsComponent.prototype.onSubmit = function () {
        // console.log(JSON.stringify(this.model));
        // this.adversarialSettingsValue.emit(JSON.stringify(this.model));
        this.close();
    };
    AdversarialInputsSettingsComponent.prototype.ngOnInit = function () {
    };
    AdversarialInputsSettingsComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    AdversarialInputsSettingsComponent.prototype.methodSelect = function ($event) {
        // console.log($event.target.value);
        this.methodv = $event.target.value;
        if ($event.target.value == "fgsm") {
            this.model = { "threshold": this.tresholdv, "method": this.methodv, "eps": this.epsilonv, "targeted": this.targetedv };
            this.displayFGSMOptions = true;
            this.displayJSMAOptions = false;
        }
        else if ($event.target.value == "jsma") {
            this.model = { "threshold": this.tresholdv, "method": this.methodv, "theta": this.thetadv, "gamma": this.gammav };
            this.displayFGSMOptions = false;
            this.displayJSMAOptions = true;
        }
    };
    AdversarialInputsSettingsComponent.prototype.ngOnChanges = function (changes) {
        //console.log("AdvSettings -- ",this.AdvSettings)
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], AdversarialInputsSettingsComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], AdversarialInputsSettingsComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], AdversarialInputsSettingsComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], AdversarialInputsSettingsComponent.prototype, "adversarialSettingsValue", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], AdversarialInputsSettingsComponent.prototype, "AdvSettings", void 0);
    AdversarialInputsSettingsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-adversarial-inputs-settings',
            template: __webpack_require__(/*! ./adversarial-inputs-settings.component.html */ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.html"),
            styles: [__webpack_require__(/*! ./adversarial-inputs-settings.component.css */ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [])
    ], AdversarialInputsSettingsComponent);
    return AdversarialInputsSettingsComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./homepage/homepage.component */ "./src/app/homepage/homepage.component.ts");
/* harmony import */ var _image_classifier_image_classifier_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./image-classifier/image-classifier.component */ "./src/app/image-classifier/image-classifier.component.ts");
/* harmony import */ var _text_classifier_text_classifier_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./text-classifier/text-classifier.component */ "./src/app/text-classifier/text-classifier.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    { path: '', component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_2__["HomepageComponent"] },
    { path: 'homepage', component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_2__["HomepageComponent"] },
    { path: 'image-classifier', component: _image_classifier_image_classifier_component__WEBPACK_IMPORTED_MODULE_3__["ImageClassifierComponent"] },
    { path: 'text-classifier', component: _text_classifier_text_classifier_component__WEBPACK_IMPORTED_MODULE_4__["TextClassifierComponent"] },
    { path: '**', redirectTo: 'homepage' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, { useHash: true })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\r\n<router-outlet></router-outlet>\r\n<app-footer></app-footer>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _login_user_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login/user.service */ "./src/app/login/user.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AppComponent = /** @class */ (function () {
    function AppComponent(userService) {
        this.userService = userService;
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [_login_user_service__WEBPACK_IMPORTED_MODULE_0__["UserService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-swiper-wrapper */ "./node_modules/ngx-swiper-wrapper/dist/ngx-swiper-wrapper.es5.js");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-pagination */ "./node_modules/ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-malihu-scrollbar */ "./node_modules/ngx-malihu-scrollbar/fesm5/ngx-malihu-scrollbar.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng2-search-filter */ "./node_modules/ng2-search-filter/ng2-search-filter.es5.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./homepage/homepage.component */ "./src/app/homepage/homepage.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _image_classifier_image_classifier_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./image-classifier/image-classifier.component */ "./src/app/image-classifier/image-classifier.component.ts");
/* harmony import */ var _image_classifier_main_settings_image_classifier_main_settings_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./image-classifier-main-settings/image-classifier-main-settings.component */ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.ts");
/* harmony import */ var _adversarial_inputs_settings_adversarial_inputs_settings_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./adversarial-inputs-settings/adversarial-inputs-settings.component */ "./src/app/adversarial-inputs-settings/adversarial-inputs-settings.component.ts");
/* harmony import */ var _interpretability_settings_interpretability_settings_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./interpretability-settings/interpretability-settings.component */ "./src/app/interpretability-settings/interpretability-settings.component.ts");
/* harmony import */ var _comparison_graph_comparison_graph_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./comparison-graph/comparison-graph.component */ "./src/app/comparison-graph/comparison-graph.component.ts");
/* harmony import */ var _performance_graph_performance_graph_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./performance-graph/performance-graph.component */ "./src/app/performance-graph/performance-graph.component.ts");
/* harmony import */ var _performance_comparison_graph_performance_comparison_graph_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./performance-comparison-graph/performance-comparison-graph.component */ "./src/app/performance-comparison-graph/performance-comparison-graph.component.ts");
/* harmony import */ var _text_classifier_text_classifier_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./text-classifier/text-classifier.component */ "./src/app/text-classifier/text-classifier.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

















//import * as Chart from 'chart.js'; 








//import { TFTguardGuard } from './guard/tftguard.guard';







var DEFAULT_SWIPER_CONFIG = {
    observer: true,
    direction: 'horizontal',
    threshold: 50,
    spaceBetween: 5,
    slidesPerView: 1,
    centeredSlides: true
};
var routes = [
    { path: '', component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_17__["HomepageComponent"] },
    { path: 'homepage', component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_17__["HomepageComponent"] },
    { path: 'image-classifier', component: _image_classifier_image_classifier_component__WEBPACK_IMPORTED_MODULE_19__["ImageClassifierComponent"] },
    { path: 'text-classifier', component: _text_classifier_text_classifier_component__WEBPACK_IMPORTED_MODULE_26__["TextClassifierComponent"] },
    { path: '**', redirectTo: 'homepage' },
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_14__["AppComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_15__["HeaderComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_16__["FooterComponent"],
                _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_17__["HomepageComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_18__["LoginComponent"],
                _image_classifier_image_classifier_component__WEBPACK_IMPORTED_MODULE_19__["ImageClassifierComponent"],
                _image_classifier_main_settings_image_classifier_main_settings_component__WEBPACK_IMPORTED_MODULE_20__["ImageClassifierMainSettingsComponent"],
                _adversarial_inputs_settings_adversarial_inputs_settings_component__WEBPACK_IMPORTED_MODULE_21__["AdversarialInputsSettingsComponent"],
                _interpretability_settings_interpretability_settings_component__WEBPACK_IMPORTED_MODULE_22__["InterpretabilitySettingsComponent"],
                _comparison_graph_comparison_graph_component__WEBPACK_IMPORTED_MODULE_23__["ComparisonGraphComponent"],
                _performance_graph_performance_graph_component__WEBPACK_IMPORTED_MODULE_24__["PerformanceGraphComponent"],
                _performance_comparison_graph_performance_comparison_graph_component__WEBPACK_IMPORTED_MODULE_25__["PerformanceComparisonGraphComponent"],
                _text_classifier_text_classifier_component__WEBPACK_IMPORTED_MODULE_26__["TextClassifierComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes, { useHash: true }),
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSidenavModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatFormFieldModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialogModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSortModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_8__["HttpModule"],
                ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_9__["SwiperModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                ngx_pagination__WEBPACK_IMPORTED_MODULE_10__["NgxPaginationModule"],
                ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_11__["MalihuScrollbarModule"].forRoot(),
                ng2_charts__WEBPACK_IMPORTED_MODULE_12__["ChartsModule"],
                ng2_search_filter__WEBPACK_IMPORTED_MODULE_13__["Ng2SearchPipeModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_27__["AppRoutingModule"]
            ],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["NO_ERRORS_SCHEMA"]],
            providers: [
                {
                    provide: ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_9__["SWIPER_CONFIG"],
                    useValue: DEFAULT_SWIPER_CONFIG
                }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_14__["AppComponent"]],
            entryComponents: [
                _login_login_component__WEBPACK_IMPORTED_MODULE_18__["LoginComponent"], _image_classifier_main_settings_image_classifier_main_settings_component__WEBPACK_IMPORTED_MODULE_20__["ImageClassifierMainSettingsComponent"], _adversarial_inputs_settings_adversarial_inputs_settings_component__WEBPACK_IMPORTED_MODULE_21__["AdversarialInputsSettingsComponent"]
            ]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/comparison-graph/comparison-graph.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/comparison-graph/comparison-graph.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.comparisongraph-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -285px 0px 0px -550px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.comparisongraph-wrap{\r\n  width: 1100px;\r\n}\r\n"

/***/ }),

/***/ "./src/app/comparison-graph/comparison-graph.component.html":
/*!******************************************************************!*\
  !*** ./src/app/comparison-graph/comparison-graph.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog comparisongraph-bg\">\r\n    <div class=\"comparisongraph-wrap\">\r\n      <!-- <div class=\"interpretabilitysetting-header\">Interpretability Settings</div> -->\r\n      <div>\r\n  <canvas\r\n      baseChart\r\n      [datasets]=\"chartData\"\r\n      [labels]=\"labels\"\r\n      [options]=\"chartOptions\"\r\n      [plugins]=\"barChartPlugins\"\r\n      [legend]=\"barChartLegend\"\r\n      [chartType]=\"barChartType\">\r\n  </canvas>\r\n</div>\r\n\r\n    </div>\r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/comparison-graph/comparison-graph.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/comparison-graph/comparison-graph.component.ts ***!
  \****************************************************************/
/*! exports provided: ComparisonGraphComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonGraphComponent", function() { return ComparisonGraphComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.piecelabel.js */ "./node_modules/chart.piecelabel.js/src/Chart.PieceLabel.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! chartjs-plugin-datalabels */ "./node_modules/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.js");
/* harmony import */ var chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




;
var ComparisonGraphComponent = /** @class */ (function () {
    // CHART CLICK EVENT.
    // onChartClick(event) {
    //   console.log(event);
    // }
    function ComparisonGraphComponent() {
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.interpretabilitySettingsValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // ADD CHART OPTIONS.
        this.chartOptions = {
            responsive: true,
            // We use these empty structures as placeholders for dynamic theming.
            scales: {
                xAxes: [{
                        ticks: {
                            autoSkip: false
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Methods'
                        }
                    }],
                yAxes: [{
                        ticks: {
                            beginAtZero: true
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Model Accuracy'
                        }
                    }]
            },
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                }
            }
        };
        this.labels = ['Original Accuracy', 'Rotation & Translation', 'Fourier Filtering', 'Gray Scale', 'Contrast', 'Additive Noise', 'Eidolon Noise', 'Adversarial Patches', 'Adversarial Inputs - FGSM', 'Adversarial Inputs - CW'];
        this.barChartType = 'bar';
        this.barChartLegend = true;
        this.barChartPlugins = [chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__];
        // CHART COLOR.
        this.colors = [
            {
                backgroundColor: 'rgba(107, 202, 226, 0.98)'
            },
            {
                backgroundColor: 'rgba(65, 147, 75, 0.98)'
            },
            {
                backgroundColor: 'rgba(254, 132, 3, 0.98)'
            }
        ];
    }
    ;
    ComparisonGraphComponent.prototype.ngOnInit = function () {
    };
    ComparisonGraphComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ComparisonGraphComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ComparisonGraphComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], ComparisonGraphComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], ComparisonGraphComponent.prototype, "interpretabilitySettingsValue", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], ComparisonGraphComponent.prototype, "chartData", void 0);
    ComparisonGraphComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-comparison-graph',
            template: __webpack_require__(/*! ./comparison-graph.component.html */ "./src/app/comparison-graph/comparison-graph.component.html"),
            styles: [__webpack_require__(/*! ./comparison-graph.component.css */ "./src/app/comparison-graph/comparison-graph.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [])
    ], ComparisonGraphComponent);
    return ComparisonGraphComponent;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "footer{\r\n  position: fixed;\r\n  width: 100%;\r\n  bottom: 0px;\r\n  padding: 10px 5px;\r\n  background: rgba(0, 0, 0, 0.4);\r\n  z-index: 999;\r\n}\r\n\r\n.footer-left{\r\n  float: left;\r\n  color: rgba(255, 255, 255, 0.94);\r\n  font-family: 'Open Sans', sans-serif;\r\n  font-size: 12px;\r\n  font-weight: 300;\r\n}\r\n\r\n.footer-right{\r\n  float: right;\r\n  color: rgba(255, 255, 255, 0.94);\r\n  font-family: 'Open Sans', sans-serif;\r\n  font-size: 12px;\r\n  font-weight: 300;\r\n}\r\n"

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<footer>\r\n  <div class=\"main-wrap\">\r\n    <div class=\"footer-left\">© 2018 - 2019, Accenture All Rights Reserved</div>\r\n    <div class=\"footer-right\">Powered by Accenture Labs</div>\r\n    <div class=\"clearfix\"></div>\r\n  </div>\r\n</footer>\r\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "header{\r\n  /*background: #000000;*/\r\n  background: url(\"/teachntest/assets/images/header-bg.svg\") #000000  no-repeat fixed top left;\r\n  background-size: contain;\r\n  width: 100%;\r\n  height: 50px;\r\n  border-bottom: #149dcc solid 2px;\r\n  position: fixed;\r\n  top: 0px;\r\n  z-index: 2;\r\n  overflow: hidden;\r\n}\r\n\r\n.header-left-wrap{\r\n  float: left;\r\n  margin: 0px 0px 0px 10px;\r\n}\r\n\r\n.header-left-wrap span{\r\n  color: rgba(255, 255, 255, 0.99);\r\n  font-size: 26px;\r\n  font-weight: 700;\r\n  display: block;\r\n  margin: 13px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n.header-right-wrap{\r\n  float: right;\r\n  margin: 35px 10px 0px 0px;\r\n  width: 165px;\r\n}\r\n\r\n.login-wrap{\r\n  float: right;\r\n  margin: 17px 10px 0px 0px;\r\n  display: none;\r\n}\r\n\r\n.login-wrap a{\r\n  text-decoration: none;\r\n  color: #fff;\r\n  cursor: pointer;\r\n}\r\n\r\n.login-wrap span{\r\n  color: #fff;\r\n  font-size: 13px;\r\n}\r\n\r\n.login-wrap a span i{\r\n  font-family: 'FontAwesome';\r\n  font-size: 14px;\r\n}\r\n\r\n.login-show{\r\n  display: block;\r\n}\r\n\r\n.username-wrap{\r\n  float: right;\r\n  margin: -10px 5px 0px 0px;\r\n}\r\n"

/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header>\r\n  <div class=\"header-left-wrap\">\r\n    <!-- <img src=\"../assets/images/testingfortrust-logo.svg\" alt=\"Testing for Trust\"> -->\r\n    <span (click)=\"navigateToHP()\">Teach & Test: Testing For Trust</span>\r\n  </div>\r\n  <!-- <div class=\"header-right-wrap\">\r\n    <img src=\"../assets/images/logo.svg\" alt=\"Accenture\">\r\n  </div> -->\r\n\r\n  <!-- <div class=\"login-wrap login-show\">\r\n    <a id=\"LoginButton\" (click)=\"showDialog = !showDialog\" *ngIf=\"showLogin\" ><span>Login <i class=\"fa fa-sign-in\"></i></span></a>\r\n    <div class=\"username-wrap\" *ngIf=\"showLogout\" ><span>Hi {{loggedinUserName}} </span></div>\r\n    <div class=\"clearfix\"></div>\r\n    <a  (click)=\"logout()\" *ngIf=\"showLogout\" ><span>LogOut <i class=\"fa fa-sign-out\"></i></span></a>\r\n\r\n  </div> -->\r\n  <div class=\"clearfix\"></div>\r\n</header>\r\n<app-login [(visible)]=\"showDialog\" (loginValueCheck)=\"loginCheckValue($event)\"> </app-login>\r\n"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _login_user_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../login/user.service */ "./src/app/login/user.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(userService, router) {
        this.userService = userService;
        this.router = router;
        this.showLogin = true;
        this.showLogout = false;
        this.loggedinUserName = "";
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var user = sessionStorage.getItem('currentUser');
        if (user) {
            this.showLogin = false;
            this.showLogout = true;
            this.loggedinUserName = JSON.parse(sessionStorage.getItem('currentUser')).name;
        }
    };
    /* */ HeaderComponent.prototype.loginCheckValue = function ($event) {
        if ($event) {
            this.showLogout = true;
            this.showLogin = false;
            this.loggedinUserName = JSON.parse(sessionStorage.getItem('currentUser')).name;
        }
        else {
            this.showLogout = false;
            this.showLogin = true;
        }
    };
    HeaderComponent.prototype.logout = function () {
        var _this = this;
        this.userService.logoutUser().subscribe(function (response) {
            //sessionStorage.removeItem('currentUser');
            //sessionStorage.removeItem('userToken');
            sessionStorage.clear();
            _this.showLogout = false;
            _this.showLogin = true;
            _this.router.navigate(['\homepage']);
        }, function (error) {
            sessionStorage.removeItem('currentUser');
            sessionStorage.removeItem('userToken');
            _this.showLogout = false;
            _this.showLogin = true;
            _this.router.navigate(['\homepage']);
            //alert("Token is not valid!!!");
        });
    };
    HeaderComponent.prototype.navigateToHP = function () {
        this.router.navigate(['\homepage']);
    };
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        }),
        __metadata("design:paramtypes", [_login_user_service__WEBPACK_IMPORTED_MODULE_0__["UserService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/homepage/homepage.component.css":
/*!*************************************************!*\
  !*** ./src/app/homepage/homepage.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".section-01{\r\n  background: linear-gradient(45deg, #7fd9fc, #6576aa);\r\n  font-family: 'Rubik', sans-serif;\r\n}\r\n\r\n.section-02{\r\n  background: url(\"/teachntest/assets/images/homepage-images/section-02_bg.jpg\") #000000  no-repeat center center;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n}\r\n\r\n.section-03{\r\n  background: linear-gradient(0deg, #f9f9f9, #149dcc);\r\n  font-family: 'Rubik', sans-serif;\r\n}\r\n\r\n.section-01 h1{\r\n  display: block;\r\n  text-align: center;\r\n  color: #FFF;\r\n  font-size: 70px;\r\n  font-weight: 300;\r\n  margin: 10px 0px 30px 0px;\r\n  opacity: 0;\r\n}\r\n\r\n.section-01 p{\r\n  display: block;\r\n  text-align: center;\r\n  color: #FFF;\r\n  font-size: 25px;\r\n  line-height: 35px;\r\n  font-weight: 400;\r\n  width: 90%;\r\n  margin: 0 auto;\r\n  opacity: 0;\r\n}\r\n\r\n.media-container-row{\r\n  flex-wrap: nowrap;\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n  justify-content: center;\r\n  align-content: center;\r\n  align-items: start;\r\n}\r\n\r\n.card{\r\n  position: relative;\r\n  width: 33%;\r\n  min-height: 1px;\r\n  padding-right: 15px;\r\n  padding-left: 15px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  word-wrap: break-word;\r\n  background-clip: border-box;\r\n  opacity: 0;\r\n}\r\n\r\n.card-col{\r\n  display: inline-block;\r\n}\r\n\r\n.card-img{\r\n  background: #149dcc;\r\n  padding: 10px;\r\n  text-align: center;\r\n  padding: 0px 0px 0px 0px\r\n}\r\n\r\n.card-img span{\r\n  display: block;\r\n  width: 150px;\r\n  height: 150px;\r\n  color: rgb(255, 255, 255);\r\n  margin: 0 auto;\r\n}\r\n\r\n.card-img span.icon-01{\r\n  background: url(\"/teachntest/assets/images/homepage-images/icons/audit.svg\")  no-repeat center center;\r\n  background-size: cover;\r\n}\r\n\r\n.card-img span.icon-02{\r\n  background: url(\"/teachntest/assets/images/homepage-images/icons/structured-data.svg\")  no-repeat center center;\r\n  background-size: cover;\r\n}\r\n\r\n.card-img span.icon-03{\r\n  background: url(\"/teachntest/assets/images/homepage-images/icons/unstructured-data.svg\")  no-repeat center center;\r\n  background-size: cover;\r\n}\r\n\r\n.card-box{\r\n  background: linear-gradient(#149dcc, transparent);\r\n  padding: 10px;\r\n  text-align: center;\r\n}\r\n\r\n.card-title{\r\n  font-size: 18px;\r\n  color: rgb(255, 255, 255);\r\n  margin: 10px 0px 10px 0px;\r\n  display: block;\r\n  min-height: 90px;\r\n}\r\n\r\n.card-txt{\r\n  font-size: 14px;\r\n  color: rgb(255, 255, 255);\r\n}\r\n\r\n.card-btn{\r\n  clear: both;\r\n  margin: 10px 0px 50px 0px;\r\n}\r\n\r\n.card-btn a{\r\n  font-size: 18px;\r\n  color: #ffffff;\r\n  background: #ff3366;\r\n  border-color: #ff3366;\r\n  border-radius: 30px;\r\n  padding: 15px 50px;\r\n  text-decoration: none;\r\n  display: inline-block;\r\n  cursor: pointer;\r\n}\r\n\r\n.media-container-row-alt{\r\n\r\n}\r\n\r\n.section-title{\r\n  font-size: 50px;\r\n  color: rgb(255, 255, 255);\r\n  display: block;\r\n  text-align: center;\r\n  margin: 0px 0px 30px 0px;\r\n  opacity: 0;\r\n}\r\n\r\n.section-03-cont-wrap{\r\n  opacity: 0;\r\n}\r\n\r\n.nav-tabs{\r\n\r\n}\r\n\r\n.nav-tabs{\r\n  text-align: center;\r\n  margin: 20px 0px;\r\n}\r\n\r\n.nav-tabs li{\r\n  display: inline-block;\r\n  margin: 0px 20px;\r\n}\r\n\r\n.nav-tabs li a{\r\n  font-size: 16px;\r\n  color: #fff;\r\n  padding: 18px 60px;\r\n  min-width: 210px;\r\n  display: inline-block;\r\n  border-radius: 25px;\r\n  text-decoration: none;\r\n  border: #fff solid 1px;\r\n  cursor: pointer;\r\n}\r\n\r\n.nav-tabs li a:hover, .nav-tabs li a.active{\r\n  background: #ff3366;\r\n  border: #fff solid 1px;\r\n}\r\n\r\n/* Animation for Slides */\r\n\r\n.animated{\r\n  transition: all 0.5s ease;\r\n}\r\n\r\n.anim_delay_01{\r\n  -webkit-animation-delay: 1s;\r\n          animation-delay: 1s;\r\n}\r\n\r\n.fadeIn{\r\n  opacity: 1 !important;\r\n}\r\n\r\n.tab-pane{\r\n  min-height: 100px;\r\n  text-align: center;\r\n  font-size: 16px;\r\n  line-height: 28px;\r\n  width: 700px;\r\n  margin: 30px auto 0 auto;\r\n}\r\n"

/***/ }),

/***/ "./src/app/homepage/homepage.component.html":
/*!**************************************************!*\
  !*** ./src/app/homepage/homepage.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"fullpage\">\r\n<div class=\"section section-01\">\r\n<div class=\"fixed-width-wrap\">\r\n<h1>Testing for Trust</h1>\r\n<p>Testing for Trust envisages testing black box ML models for generalization, robustness and interpretability. Audits can be made on Image Classifiers, Classifiers on Structured data and classifiers on unstructured text data.</p>\r\n</div>\r\n</div>\r\n<div class=\"section section-02\">\r\n<div class=\"fixed-width-wrap\">\r\n<div class=\"media-container-row\">\r\n<div class=\"card card-col card-01\">\r\n<div class=\"card-img\">\r\n<span class=\"icon-01\"></span>\r\n</div>\r\n<div class=\"card-box\">\r\n<span class=\"card-title\">Audit image classifier models</span>\r\n<p class=\"card-text\"></p>\r\n<!-- <div class=\"card-btn\"><a class=\"\" (click)=\"showDialog = !showDialog\">Click</a></div> -->\r\n<div class=\"card-btn\"><a class=\"\" (click)=\"routetoImageClassifiers()\">Click</a></div>\r\n<!-- <div class=\"card-btn\" (click)=\"triggerclick()\" routerLink=\"/image-classifier\">Click</div> -->\r\n</div>\r\n</div>\r\n<div class=\"card card-col card-02\">\r\n<div class=\"card-img\">\r\n<span class=\"icon-02\"></span>\r\n</div>\r\n<div class=\"card-box\">\r\n<span class=\"card-title\">Audit predictive models on Structured data</span>\r\n<p class=\"card-text\"></p>\r\n<div class=\"card-btn\"><a class=\"\" (click)=\"showDialog = !showDialog\">Click</a></div>\r\n</div>\r\n</div>\r\n<div class=\"card card-col card-03\">\r\n<div class=\"card-img\">\r\n<span class=\"icon-03\"></span>\r\n</div>\r\n<div class=\"card-box\">\r\n<span class=\"card-title\">Audit classifier models on Unstrcutured text data</span>\r\n<p class=\"card-text\"></p>\r\n<div class=\"card-btn\"><a class=\"\" (click)=\"routetoTextClassifiers()\">Click</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"section section-03\">\r\n<div class=\"fixed-width-wrap\">\r\n<div class=\"media-container-row-alt\">\r\n<span class=\"section-title\">What does it mean?</span>\r\n<div class=\"media-container-row\">\r\n<div class=\"section-03-cont-wrap\">\r\n<ul class=\"nav nav-tabs\" role=\"tablist\">\r\n  <li class=\"nav-item\"><a class=\"nav-link active\" [ngClass]=\"{active: tab01}\" (click)=\"showTabContent($event)\">\r\n  Generalization</a></li>\r\n<li class=\"nav-item\"><a class=\"nav-link\" (click)=\"showTabContent($event)\" [ngClass]=\"{active: tab02}\">\r\nRobustness</a></li>\r\n<!-- <li class=\"nav-item\"><a class=\"nav-link\" (click)=\"showTabContent($event)\" [ngClass]=\"{active: tab03}\">\r\nDiscrimination</a></li> -->\r\n<li class=\"nav-item\"><a class=\"nav-link\" (click)=\"showTabContent($event)\" [ngClass]=\"{active: tab03}\">\r\nInterpretability</a></li>\r\n</ul>\r\n<div class=\"tab-content\">\r\n<div #tab01 class=\"tab-pane active show\" role=\"tabpanel\" *ngIf=\"tab01\">\r\n<div class=\"tab-cont\">\r\n<p>Measures the ability of the algorithm to perform well on new inputs not seen during training</p>\r\n</div>\r\n</div>\r\n<div #tab02 class=\"tab-pane\" role=\"tabpanel\" *ngIf=\"tab02\">\r\n<div class=\"tab-cont\">\r\n<p>Measures the ability of the algorithm to be not susceptible to maliciously crafted inputs to specifically fool the algorithm</p>\r\n</div>\r\n</div>\r\n<!-- <div #tab03 class=\"tab-pane\" role=\"tabpanel\" *ngIf=\"tab03\">\r\n<div class=\"tab-cont\">\r\n<p>Any distinction, exclusion or preference made on the basis of race, color, sex, religion, political opinion, national extraction or social origin, which has the effect of nullifying or impairing equality of opportunity or treatment.</p>\r\n</div>\r\n</div> -->\r\n<div #tab03 class=\"tab-pane\" role=\"tabpanel\" *ngIf=\"tab03\">\r\n<div class=\"tab-cont\">\r\n<p>Provides clue to interpret the decision of the algorithm</p>\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<!-- <app-login [(visible)]=\"showDialog\"> </app-login> -->\r\n<!-- <app-header *ngIf=\"clickTrigger\"></app-header> -->\r\n"

/***/ }),

/***/ "./src/app/homepage/homepage.component.ts":
/*!************************************************!*\
  !*** ./src/app/homepage/homepage.component.ts ***!
  \************************************************/
/*! exports provided: HomepageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomepageComponent", function() { return HomepageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var HomepageComponent = /** @class */ (function () {
    function HomepageComponent(dialog, router) {
        this.dialog = dialog;
        this.router = router;
        this.tab01 = true;
        this.tab02 = false;
        this.tab03 = false;
    }
    HomepageComponent.prototype.ngOnInit = function () {
        // @ViewChild('myDiv') private myDiv: ElementRef;
        // if(window.sessionStorage.getItem('user')==="true"){
        // 	this.userCheck = false;
        // }
        //alert("IN home page")
        $('#fullpage').fullpage({
            //Navigation
            // menu: '#menu',
            // lockAnchors: false,
            // anchors:['firstPage', 'secondPage'],
            navigation: false,
            navigationPosition: 'right',
            navigationTooltips: ['firstSlide', 'secondSlide'],
            showActiveTooltip: false,
            slidesNavigation: false,
            slidesNavPosition: 'bottom',
            //Scrolling
            css3: true,
            scrollingSpeed: 700,
            autoScrolling: true,
            fitToSection: true,
            fitToSectionDelay: 1000,
            scrollBar: false,
            easing: 'easeInOutCubic',
            easingcss3: 'ease',
            loopBottom: false,
            loopTop: false,
            loopHorizontal: true,
            continuousVertical: false,
            continuousHorizontal: false,
            scrollHorizontally: false,
            interlockedSlides: false,
            dragAndMove: false,
            offsetSections: false,
            resetSliders: false,
            fadingEffect: false,
            normalScrollElements: '#element1, .element2',
            scrollOverflow: false,
            scrollOverflowReset: false,
            scrollOverflowOptions: null,
            touchSensitivity: 15,
            normalScrollElementTouchThreshold: 5,
            bigSectionsDestination: null,
            //Accessibility
            keyboardScrolling: true,
            animateAnchor: true,
            recordHistory: true,
            //Design
            controlArrows: true,
            verticalCentered: true,
            sectionsColor: ['#ccc', '#fff'],
            paddingTop: '3em',
            paddingBottom: '10px',
            fixedElements: '#header, .footer',
            responsiveWidth: 0,
            responsiveHeight: 0,
            responsiveSlides: false,
            parallax: false,
            parallaxOptions: { type: 'reveal', percentage: 62, property: 'translate' },
            //Custom selectors
            sectionSelector: '.section',
            slideSelector: '.slide',
            lazyLoading: true,
            //events
            onLeave: function (index, nextIndex, direction) {
                if (index == 1) {
                    $('.section-02').find('.card-01').delay(500).animate({
                        opacity: '1',
                    }, 4000, 'easeOutExpo');
                    $('.section-02').find('.card-02').delay(1000).animate({
                        opacity: '1',
                    }, 4000, 'easeOutExpo');
                    $('.section-02').find('.card-03').delay(1500).animate({
                        opacity: '1',
                    }, 4000, 'easeOutExpo');
                }
                if (index == 1 && nextIndex == 2) {
                    // $('.card').addClass('animated fadeIn');
                    // $('.card').eq(0).css('animation-delay', '.3s');
                }
                if (index == 2) {
                    $('.section-03').find('span').delay(500).animate({
                        opacity: '1',
                    }, 4000, 'easeOutExpo');
                    $('.section-03').find('.section-03-cont-wrap').delay(1000).animate({
                        opacity: '1',
                    }, 4000, 'easeOutExpo');
                }
            },
            afterLoad: function (anchorLink, index) { },
            afterRender: function () {
                $('.section-01').find('h1').delay(500).animate({
                    opacity: '1',
                }, 4000, 'easeOutExpo');
                $('.section-01').find('p').delay(1500).animate({
                    opacity: '1',
                }, 4000, 'easeOutExpo');
            },
            afterResize: function () { },
            afterResponsive: function (isResponsive) { },
            afterSlideLoad: function (anchorLink, index, slideAnchor, slideIndex) { },
            onSlideLeave: function (anchorLink, index, slideIndex, direction, nextSlideIndex) { }
        });
    };
    HomepageComponent.prototype.showTabContent = function ($event) {
        if ($event.target.innerText === "Generalization") {
            this.tab01 = true;
            this.tab02 = this.tab03 = false;
        }
        else if ($event.target.innerText === "Robustness") {
            this.tab02 = true;
            this.tab01 = this.tab03 = false;
        }
        // }else if($event.target.innerText==="Discrimination"){
        //   this.tab02 = true;
        // 	this.tab01=  this.tab03 =false;
        // 	}
        else {
            this.tab03 = true;
            this.tab01 = this.tab02 = false;
        }
    };
    // ngAfterViewInit() {
    //     // console.log(this.input.nativeElement.value);
    //     // console.debug(this.divs);
    //   }
    HomepageComponent.prototype.routetoImageClassifiers = function () {
        var element = document.getElementById('LoginButton');
        this.router.navigate(['/image-classifier']);
        // if(sessionStorage.getItem('currentUser')){
        //   this.router.navigate(['\image-classifier']);
        // }
        // else{
        //   element.click();
        //   this.router.navigate(['\image-classifier']);
        // }
    };
    HomepageComponent.prototype.routetoTextClassifiers = function () {
        this.router.navigate(['/text-classifier']);
    };
    HomepageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-homepage',
            template: __webpack_require__(/*! ./homepage.component.html */ "./src/app/homepage/homepage.component.html"),
            styles: [__webpack_require__(/*! ./homepage.component.css */ "./src/app/homepage/homepage.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialog"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HomepageComponent);
    return HomepageComponent;
}());



/***/ }),

/***/ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.css":
/*!*********************************************************************************************!*\
  !*** ./src/app/image-classifier-main-settings/image-classifier-main-settings.component.css ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.imageclassifiersetting-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -223px 0px 0px -175px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.imageclassifiersetting-header{\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  text-align: center;\r\n  margin: 10px 0px 20px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n.imageclassifiersetting-option-wrap{\r\n  margin: 0px 0px 10px 0px;\r\n  /* text-align: center; */\r\n}\r\n\r\n.imageclassifiersetting-option-wrap label{\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  width: auto;\r\n  display: inline-block;\r\n  text-align: left;\r\n}\r\n\r\n.imageclassifiersetting-option-wrap input{\r\n  width: 240px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n.imageclassifiersetting-option-wrap p{\r\n  width: 240px;\r\n  float: right;\r\n  font-size: 11px;\r\n  text-align: left;\r\n  margin: 5px 0px\r\n}\r\n\r\n.imageclassifiersetting-option-wrap  title{\r\n  font-size: 11px;\r\n  text-align: left;\r\n}\r\n\r\n.imageclassifiersetting-option-wrap select {\r\n    width: 240px;\r\n    height: 28px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    font-family: 'Arial';\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n.imageclassifiersetting-subsetting{\r\n  margin: 0px 0px 10px 30px;\r\n}\r\n\r\n.imageclassifiersetting-subsetting label{\r\n  font-size: 13px;\r\n  width: auto;\r\n}\r\n\r\n.imageclassifiersetting-subsetting input{\r\n  width: 150px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n.imageclassifiersetting-subsetting select{\r\n  width: 150px;\r\n}\r\n\r\n.imageclassifiersetting-option-wrap button{\r\n  display: inline-block;\r\n  font-size: 15px;\r\n  padding: 5px 20px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.96);\r\n  border: none;\r\n  margin: 15px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n.imageclassifiersetting-option-wrap button:disabled{\r\n    background: rgba(20, 157, 204, 0.5);\r\n}\r\n\r\n.tooltip {\r\n    position: relative;\r\n\r\n}\r\n\r\n.tooltip .tooltiptext {\r\n    visibility: hidden;\r\n    width: 340px;\r\n    background: rgba(10, 10, 10, 1);\r\n    color: #fff;\r\n    text-align: left;\r\n    border-radius: 6px;\r\n    padding: 5px;\r\n    font-size: 12px;\r\n    line-height: 14px;\r\n    font-weight: 400;\r\n\r\n    /* Position the tooltip */\r\n    position: absolute;\r\n    bottom: 150%;\r\n    left: 50%;\r\n    margin-left: -170px;\r\n    z-index: 1;\r\n}\r\n\r\n.tooltip:hover .tooltiptext {\r\n    visibility: visible;\r\n}\r\n\r\n.tooltip .tooltiptext::after {\r\n    content: \" \";\r\n    position: absolute;\r\n    top: 100%; /* At the bottom of the tooltip */\r\n    left: 50%;\r\n    margin-left: -5px;\r\n    border-width: 5px;\r\n    border-style: solid;\r\n    border-color: black transparent transparent transparent;\r\n}\r\n\r\n.checkbox_wrap {\r\n  width: 25px !important;\r\n    display: block;\r\n    position: relative;\r\n    padding: 5px;\r\n    margin: 0px 5px 5px 0px;\r\n    cursor: pointer;\r\n    font-size: 22px;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n}\r\n\r\n/* Hide the browser's default checkbox */\r\n\r\n.checkbox_wrap input {\r\n    position: absolute;\r\n    opacity: 0;\r\n    cursor: pointer;\r\n}\r\n\r\n/* Create a custom checkbox */\r\n\r\n.checkmark {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    height: 20px;\r\n    width: 20px;\r\n    background-color: #eee;\r\n}\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n.checkbox_wrap:hover input ~ .checkmark {\r\n    background-color: #ccc;\r\n}\r\n\r\n/* When the checkbox is checked, add a blue background */\r\n\r\n.checkbox_wrap input:checked ~ .checkmark {\r\n    background-color: #2196F3;\r\n}\r\n\r\n/* Create the checkmark/indicator (hidden when not checked) */\r\n\r\n.checkmark:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    display: none;\r\n}\r\n\r\n/* Show the checkmark when checked */\r\n\r\n.checkbox_wrap input:checked ~ .checkmark:after {\r\n    display: block;\r\n}\r\n\r\n/* Style the checkmark/indicator */\r\n\r\n.checkbox_wrap .checkmark:after {\r\n    left: 6px;\r\n    top: 2px;\r\n    width: 5px;\r\n    height: 10px;\r\n    border: solid white;\r\n    border-width: 0 3px 3px 0;\r\n    -webkit-transform: rotate(45deg);\r\n    transform: rotate(45deg);\r\n}\r\n"

/***/ }),

/***/ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.html":
/*!**********************************************************************************************!*\
  !*** ./src/app/image-classifier-main-settings/image-classifier-main-settings.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog imageclassifiersetting-bg\">\r\n  <div class=\"imageclassifiersetting-wrap\">\r\n    <div class=\"imageclassifiersetting-header tooltip\">Model Audit Settings <i class=\"fa fa-info-circle\"></i>\r\n      <span class=\"tooltiptext\">\r\n      Please choose categories to audit the model with respect to Robustness, Discrimination and Interpretability; together or individually.\r\n      </span>\r\n    </div>\r\n    <form name=\"form\" (ngSubmit)=\"onSubmit()\" #f=\"ngForm\" novalidate>\r\n    <div class=\"imageclassifiersetting-cont-wrap\">\r\n      <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input [disabled]=\"this.model.fourierfilteringValue || this.model.colortograyscaleValue || this.model.modelcomplexityValue\" type=\"checkbox\" name=\"generalizaionValue\" [(ngModel)]=\"model.generalizaionValue\" #generalizaionValue=\"ngModel\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Generalization <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          We are defining robustness on the basis of three categories - Attribute variation, Adversarial inputs, Model complexity.\r\n          </span>\r\n        </label>\r\n\r\n        <!-- <input type=\"text\" name=\"thresholdValue\" [(ngModel)]=\"model.thresholdValue\" #thresholdValue=\"ngModel\" (ngModelChange)=\"thresholdValueChange($event)\" class=\"form-control\"> -->\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"fourierfilteringValue\" [(ngModel)]=\"model.fourierfilteringValue\" #fourierfilteringValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Fourier Filtering <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"colortograyscaleValue\" [(ngModel)]=\"model.colortograyscaleValue\" #colortograyscaleValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Color to Grayscale <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"contrastValue\" [(ngModel)]=\"model.contrastValue\" #contrastValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Contrast <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"additivenoiseValue\" [(ngModel)]=\"model.additivenoiseValue\" #additivenoiseValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Additive noise <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"eidolonnoiseValue\" [(ngModel)]=\"model.eidolonnoiseValue\" #eidolonnoiseValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Eidolon noise <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"modelcomplexityValue\" [(ngModel)]=\"model.modelcomplexityValue\" #modelcomplexityValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Model Complexity <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input [disabled]=\"model.adversarialExamplesValue || this.model.attributeVariationValue || this.model.modelComplexityValue\" type=\"checkbox\" name=\"robustnessValue\" [(ngModel)]=\"model.robustnessValue\" #robustnessValue=\"ngModel\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Robustness <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          We are defining robustness on the basis of three categories - Attribute variation, Adversarial inputs, Model complexity.\r\n          </span>\r\n        </label>\r\n\r\n        <!-- <input type=\"text\" name=\"thresholdValue\" [(ngModel)]=\"model.thresholdValue\" #thresholdValue=\"ngModel\" (ngModelChange)=\"thresholdValueChange($event)\" class=\"form-control\"> -->\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"adversarialExamplesValue\" [(ngModel)]=\"model.adversarialExamplesValue\" #adversarialExamplesValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Adversarial Inputs <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"attributeVariationValue\" [(ngModel)]=\"model.attributeVariationValue\" #attributeVariationValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Attribute Variation <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n            This test check Model performance on synthetic and yet real-life possible inputs.\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"discriminationValue\" [(ngModel)]=\"model.discriminationValue\" #discriminationValue=\"ngModel\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Discrimination <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          Any distinction, exclusion or preference made on the basis of race, color, sex, religion, political opinion, national extraction or social origin, which has the effect of nullifying or impairing equality of opportunity or treatment.\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n        <label class=\"checkbox_wrap\">\r\n          <input type=\"checkbox\" name=\"explainabilityValue\" [(ngModel)]=\"model.explainabilityValue\" #explainabilityValue=\"ngModel\">\r\n          <span class=\"checkmark\"></span>\r\n        </label>\r\n        <label for=\"\" class=\"tooltip\">Interpretability <i class=\"fa fa-info-circle\"></i>\r\n          <span class=\"tooltiptext\">\r\n          About explaining the predictions of a ML Model.\r\n          </span>\r\n        </label>\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n        <button>Submit</button>\r\n      </div>\r\n    </div>\r\n    </form>\r\n\r\n  </div>\r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/image-classifier-main-settings/image-classifier-main-settings.component.ts ***!
  \********************************************************************************************/
/*! exports provided: ImageClassifierMainSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageClassifierMainSettingsComponent", function() { return ImageClassifierMainSettingsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ImageClassifierMainSettingsComponent = /** @class */ (function () {
    function ImageClassifierMainSettingsComponent() {
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.imageClassifierSettingsValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.model = { robustnessValue: false, adversarialExamplesValue: false, attributeVariationValue: false, modelComplexityValue: false, discriminationValue: false, explainabilityValue: false };
    }
    ImageClassifierMainSettingsComponent.prototype.ngOnInit = function () {
        this.imageClassifierSettingsValue.emit(JSON.stringify(this.model));
    };
    ImageClassifierMainSettingsComponent.prototype.onsubChange = function ($event) {
        if (this.model.adversarialExamplesValue === true || this.model.attributeVariationValue === true) {
            this.model.robustnessValue = true;
        }
        else {
            this.model.robustnessValue = false;
        }
    };
    ImageClassifierMainSettingsComponent.prototype.ongensubChange = function ($event) {
        if (this.model.fourierfilteringValue === true || this.model.colortograyscaleValue === true || this.model.contrastValue === true || this.model.additivenoiseValue === true || this.model.eidolonnoiseValue === true || this.model.modelcomplexityValue === true) {
            this.model.generalizaionValue = true;
        }
        else {
            this.model.generalizaionValue = false;
        }
    };
    ImageClassifierMainSettingsComponent.prototype.onSubmit = function () {
        // console.log(JSON.stringify(this.model));
        this.imageClassifierSettingsValue.emit(JSON.stringify(this.model));
        this.close();
    };
    ImageClassifierMainSettingsComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ImageClassifierMainSettingsComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], ImageClassifierMainSettingsComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], ImageClassifierMainSettingsComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], ImageClassifierMainSettingsComponent.prototype, "imageClassifierSettingsValue", void 0);
    ImageClassifierMainSettingsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-image-classifier-main-settings',
            template: __webpack_require__(/*! ./image-classifier-main-settings.component.html */ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.html"),
            styles: [__webpack_require__(/*! ./image-classifier-main-settings.component.css */ "./src/app/image-classifier-main-settings/image-classifier-main-settings.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [])
    ], ImageClassifierMainSettingsComponent);
    return ImageClassifierMainSettingsComponent;
}());



/***/ }),

/***/ "./src/app/image-classifier/image-classifier.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/image-classifier/image-classifier.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ::ng-deep .fp-enabled{\r\n  height: auto !important;\r\n  overflow-y: scroll !important;\r\n}\r\n\r\n\r\n/* body.fp-viewing-1{\r\n  height: auto !important;\r\n  overflow-y: scroll !important;\r\n} */\r\n\r\n\r\n.insidepage-container{\r\n  margin: 0px 0px 0px 0px;\r\n  padding: 40px 0px 12px 0px;\r\n}\r\n\r\n\r\n.insidepage-container {\r\n  width: 100%;\r\n  height: 100%;\r\n  /* border: 1px solid rgba(0, 0, 0, 0.5); */\r\n\r\n}\r\n\r\n\r\n.insidepage-sidenav-content {\r\n  width: 100%;\r\n  display: flex;\r\n  height: 100%;\r\n  align-items: center;\r\n  /* justify-content: center; */\r\n}\r\n\r\n\r\n.insidepage-sidenav {\r\n  padding: 80px 10px 50px 0px;\r\n  height:100vh;\r\n  position: fixed;\r\n  background: rgba(255, 255, 255, 0.8);\r\n  /* border-right: rgba(20, 157, 204, 0.98) solid 1px; */\r\n}\r\n\r\n\r\n.img-classifier-wrap{\r\n  background: rgba(255, 255, 255, 0.96);\r\n}\r\n\r\n\r\n.btn-menu{\r\n  /* position: absolute; */\r\n  position: static;\r\n  min-width: 40px;\r\n  padding: 0 10px;\r\n}\r\n\r\n\r\n.sidenav-cont-header span{\r\n  display: block;\r\n  margin: 10px 0px 15px 10px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 20px;\r\n  font-weight: 500;\r\n  float: left;\r\n}\r\n\r\n\r\n.sidenav-cont-header a{\r\n  display: block;\r\n  margin: 15px 10px 30px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 25px;\r\n  float: right;\r\n}\r\n\r\n\r\n.sidenav-select-project a{\r\n  display: block;\r\n  margin: 8px 0px 2px 10px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  float: right;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.sidenav-cont-header a i{\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.sidenav-cont-wrap{\r\n  margin: 0px 0px 0px 10px;\r\n  position: relative;\r\n}\r\n\r\n\r\n/* .sidenav-cont-wrap span{\r\n  display: block;\r\n  margin: 10px 0px 10px 0px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 14px;\r\n} */\r\n\r\n\r\n.sidenav-cont-wrap input{\r\n  width: 200px;\r\n  font-size: 14px;\r\n  font-weight: 400;\r\n  padding: 5px 2px;\r\n}\r\n\r\n\r\n/* .sidenav-cont-wrap i{\r\n  position: absolute;\r\n  top: 30px;\r\n  left: 180px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  cursor: pointer;\r\n} */\r\n\r\n\r\n.sidenav-cont-input{\r\n  position: relative;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n/* .sidenav-cont-input input{\r\n  width: 290px;\r\n  font-size: 14px;\r\n  font-weight: 400;\r\n  padding: 5px 2px;\r\n\r\n} */\r\n\r\n\r\n.form-control-validation{\r\n  font-size: 12px;\r\n  color: rgba(204, 7, 5, 0.98);\r\n  position: absolute;\r\n  left: 0px;\r\n  bottom: -2px;\r\n}\r\n\r\n\r\n.custom-upload-btn{\r\n\r\n}\r\n\r\n\r\ndiv.custom-upload-btn{\r\n  width: auto;\r\n  display: inline-flex;\r\n  margin: 0px 0px 0px 5px;\r\n}\r\n\r\n\r\ndiv .custom-upload-btn label{\r\n  width: auto;\r\n}\r\n\r\n\r\n.custom-upload-btn label{\r\n    padding: 7px 15px;\r\n    background: rgba(20, 157, 204, 0.98);\r\n    display: table;\r\n    color: #fff;\r\n\r\n}\r\n\r\n\r\n.custom-upload-btn input[type=\"file\"] {\r\n    display: none;\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap{\r\n\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap button{\r\n    display: inline-block;\r\n    color: #fff;\r\n    padding: 7px 15px;\r\n    background: rgba(20, 157, 204, 0.98);\r\n    margin: 0px 5px 0px 0px;\r\n    font-size: 14px;\r\n    font-weight: 400;\r\n    border: none;\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap button:disabled{\r\n    background: rgba(20, 157, 204, 0.5);\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap i{\r\n    color: #fff;\r\n    font-size: 18px;\r\n}\r\n\r\n\r\n.sidenav-select-project, .sidenav-select-benchmark{\r\n  margin: 0px 0px 10px 10px;\r\n}\r\n\r\n\r\n.sidenav-select-project span, .sidenav-select-benchmark span{\r\n  display: inline-block;\r\n  margin: 0px 0px 5px 0px;\r\n  font-size: 13px;\r\n}\r\n\r\n\r\n.innerpage-wrap{\r\n  padding: 10px 10px;\r\n  width: 970px;\r\n  margin: 0 auto;\r\n}\r\n\r\n\r\n.innerpage-row{\r\n  padding: 0px 0px 0px 0px;\r\n  background: rgba(205, 205, 205, 0.05);\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  text-align: center;\r\n  width: 100%;\r\n  margin: 0px 0px 10px 0px;\r\n}\r\n\r\n\r\n.innerpage-row-col{\r\n  display:inline-block;\r\n  padding: 10px;\r\n  margin: 0.5% 0.5% 0.5% 0.5%;\r\n  float: left;\r\n  background: rgba(255, 255, 255, 0.99);\r\n  border: rgba(205, 205, 205, 0.3) solid 1px;\r\n  min-height: 275px;\r\n  position: relative;\r\n  /* width: 31%; */\r\n  /* -webkit-box-shadow: 0px 0px 112px -8px rgba(0,0,0,1);\r\n  -moz-box-shadow: 0px 0px 112px -8px rgba(0,0,0,1);\r\n  box-shadow: 0px 0px 112px -8px rgba(0,0,0,1); */\r\n}\r\n\r\n\r\n.row-col-left{\r\n  /* background: -webkit-linear-gradient(bottom left, #7fd9fc, #6576aa);\r\n  background: -o-linear-gradient(bottom left, #7fd9fc, #6576aa);\r\n  background: linear-gradient(to top right, #7fd9fc, #6576aa); */\r\n  border: none;\r\n  background: transparent;\r\n  display: table;\r\n  height: 100%;\r\n  width: 100%;\r\n\r\n}\r\n\r\n\r\n.row-col-header{\r\n  width: 100%;\r\n  position: relative;\r\n  margin: 0px 0px 10px 0px;\r\n}\r\n\r\n\r\n.row-col-header span{\r\n  display: block;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 15px;\r\n  font-size: 500;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.row-col-header span.row-col-header-sub{\r\n  display: block;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 12px;\r\n  font-size: 500;\r\n  text-align: left;\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.row-col-header a{\r\n  position: absolute;\r\n  right: 0px;\r\n  top: 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 16px;\r\n}\r\n\r\n\r\n.row-col-header a i{\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.row-col-content{\r\n  margin: 20px 0px 0px 0px;\r\n  padding: 10px 0px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  font-size: 14px;\r\n  line-height: 18px;\r\n  border-top: rgba(20, 157, 204, 0.98) solid 1px;\r\n  border-bottom: rgba(20, 157, 204, 0.98) solid 1px;\r\n}\r\n\r\n\r\n.row-col-left{\r\n  width: 21%;\r\n  /* margin: 170px 0px 0px 0px; */\r\n}\r\n\r\n\r\n.row-col-mid{\r\n  /* background: -webkit-linear-gradient(bottom left, #6576aa, #7fd9fc);\r\n  background: -o-linear-gradient(bottom left, #6576aa, #7fd9fc);\r\n  background: linear-gradient(to top right, #6576aa, #7fd9fc); */\r\n  width: 31%;\r\n  /* float: right; */\r\n  /* min-height: 240px; */\r\n\r\n}\r\n\r\n\r\n.row-col-right{\r\n  width: 45%;\r\n  /* float: right; */\r\n  max-height: 275px;\r\n\r\n\r\n}\r\n\r\n\r\n.col-mid-left{\r\n  width: 33.33%;\r\n  float: left;\r\n}\r\n\r\n\r\n.col-mid-img-cont-wrap{\r\n  /* float: left; */\r\n}\r\n\r\n\r\n.col-mid-left{\r\n  width: 40%;\r\n}\r\n\r\n\r\n.col-mid-mid{\r\n  width: 20%;\r\n  font-size: 30px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: relative;\r\n  min-height: 215px;\r\n  float: left;\r\n}\r\n\r\n\r\n.col-mid-mid i{\r\n  position: absolute;\r\n  top: 70%;\r\n  left: 50%;\r\n  margin: -15px 0 0 -15px;\r\n}\r\n\r\n\r\n.col-mid-right{\r\n  width: 40%;\r\n  float: right;\r\n}\r\n\r\n\r\n.col-mid-img-wrap{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.col-mid-img-cont-wrap p{\r\n  font-size: 12px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  min-height: 90px;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.col-mid-img-wrap img{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-matrix-content{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-matrix-content img{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-right{\r\n  /* padding: 0px; */\r\n  overflow-y: scroll;\r\n}\r\n\r\n\r\n.col-right-table-wrap{\r\n  width: 100%;\r\n  color: rgba(84, 84, 84, 0.95);\r\n}\r\n\r\n\r\n.col-right-table-wrap table{\r\n  table-layout:fixed;\r\n}\r\n\r\n\r\n.col-right-table-wrap th{\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  padding: 5px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  text-align: center;\r\n  white-space:nowrap;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap th:first-child{\r\n  text-align: left;\r\n}\r\n\r\n\r\n.col-right-table-wrap th{\r\n  cursor:default;\r\n}\r\n\r\n\r\n.col-right-table-wrap td{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  padding: 5px;\r\n  word-wrap:break-word;\r\n  white-space:nowrap;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap td:first-child{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  white-space:nowrap;\r\n  text-align: left;\r\n  font-weight: 600;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap{\r\n  margin: 20px 0px 0px 0px;\r\n  color: rgba(84, 84, 84, 0.95);\r\n}\r\n\r\n\r\n.col-right-table-header-wrap table{\r\n  table-layout:fixed;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap th{\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  padding: 5px;\r\n  text-align: left;\r\n  word-wrap:break-word;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap th:first-child{\r\n  color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n\r\n.col-right-table-header-wrap td{\r\n  font-size: 12px;\r\n  padding: 5px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  text-align: left;\r\n  font-weight: 600;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap td:first-child{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  text-align: left;\r\n  font-weight: 600;\r\n}\r\n\r\n\r\n.col-right-table-header{\r\n  font-size: 16px;\r\n  line-height: 20px;\r\n}\r\n\r\n\r\n.viewbtn-wrap{\r\n  position: absolute;\r\n  bottom: 10px;\r\n  width: 100%;\r\n}\r\n\r\n\r\n.viewbtn-wrap span{\r\n  display: inline-block;\r\n  color: #fff;\r\n  padding: 7px 15px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  text-decoration: none;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.slider-wrap{\r\n  position: relative;\r\n}\r\n\r\n\r\n.slider-wrap img{\r\n  width: 100%;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.adversarialpatche-display{\r\n  position: relative;\r\n  width: 75%;\r\n  margin: 0 auto;\r\n  padding: 8% 0 0 0;\r\n}\r\n\r\n\r\n.adversarialpatche-display img{\r\n  width: 100%;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.adversarialpatche-display a{\r\n  position: absolute;\r\n  font-size: 12px;\r\n  text-decoration: none;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  display: inline-block;\r\n  top: -5px;\r\n  left: -25px;\r\n\r\n}\r\n\r\n\r\n.btn-prev{\r\n\r\n}\r\n\r\n\r\n.item {\r\n  padding: 0;\r\n  width: 272px;\r\n  height: auto;\r\n  color: #fff;\r\n  font-size: 50px;\r\n  text-align: center;\r\n  background-color: black;\r\n  overflow: visible;\r\n}\r\n\r\n\r\n.item-inside{\r\n  /* background-color: crimson; */\r\n  display:inline-block;\r\n  width: 40%;\r\n  height: auto;\r\n  float: left;\r\n\r\n}\r\n\r\n\r\n.item-inside p{\r\n  font-size: 12px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  min-height: 95px;\r\n  text-align: center;\r\n  word-wrap: break-word;\r\n  overflow: hidden;\r\n}\r\n\r\n\r\n.item-inside-01{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.item-inside-02{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.innerpage-row-01 .row-col-left{\r\n  margin: 40px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-02 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-03 .row-col-left{\r\n  margin: 55px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-04 .row-col-left{\r\n  margin: 60px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-05 .row-col-left{\r\n  margin: 60px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-06 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-07 .row-col-left{\r\n  margin: 75px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-08 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-09 .row-col-left{\r\n  margin: 55px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-10 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.slider-txt-display p{\r\n  font-size: 16px;\r\n  line-height: 22px;\r\n  text-align: center;\r\n  margin: 90px 20px 0px 20px;\r\n\r\n}\r\n\r\n\r\n.row-col-loader{\r\n  width: 78%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.loader-fixedwidth{\r\n  width: 60%;\r\n  margin: 50px auto 0px auto;\r\n}\r\n\r\n\r\n.row-col-loader-header{\r\n  display: block;\r\n  font-size: 16px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.row-col-loader-txt{\r\n  display: block;\r\n  font-size: 12px;\r\n  line-height: 14px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.row-col-initial{\r\n  width: 78%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.row-noresult-wrap{\r\n  font-size: 16px;\r\n  line-height: 250px;\r\n}\r\n\r\n\r\n.row-col-initial-header{\r\n  display: block;\r\n  font-size: 16px;\r\n  line-height: 20px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.initial-circle-wrap{\r\n  margin: 30px 0px 0px 0px;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.initial-circle-content{\r\n  display: inline-block;\r\n  margin: 0 40px;\r\n  width: 200px; \r\n}\r\n\r\n\r\n.circle-header{\r\n  clear: both;\r\n  font-size: 16px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 10px 0px 0px 0px;\r\n}\r\n\r\n\r\n.circle-btn{\r\n  position: absolute;\r\n  bottom: 2px;\r\n  right: 2px;\r\n  font-size: 11px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.detailExample-wrap{\r\n  margin: 20px 0px 0px 0px;\r\n}\r\n\r\n\r\n.detailExample-cont{\r\n  margin: 10px 0px 10px 0px;\r\n  padding: 10px;\r\n  text-align: center;\r\n  box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  clear: both;\r\n}\r\n\r\n\r\n.detailExample-cont-className{\r\n  /* display: inline-block; */\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  text-align: left;\r\n  width: 40%;\r\n  float: left;\r\n  padding: 35px 0px 0px 0px;\r\n  cursor: pointer;\r\n  overflow-wrap: break-word;\r\n  overflow: hidden;\r\n}\r\n\r\n\r\n.detailExample-cont-circle{\r\n  /* display: inline-block; */\r\n  margin: 0px 0px;\r\n  width: 30%;\r\n  float: left;\r\n}\r\n\r\n\r\n.detailExample-cont-header{\r\n  font-size: 12px;\r\n  text-align: center;\r\n  clear: both;\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.ip-row{\r\n  width: 100%;\r\n  border: rgba(205, 205, 205, 0.9) solid 1px;\r\n  border-bottom: none;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n.list{\r\n  border: rgba(205, 205, 205, 0.9) solid 1px;\r\n  border-top: none;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n.emptylist{\r\n  color: rgba(0, 0, 0, 0.95);\r\n  font-size: 15px;\r\n  padding: 30px 20px;\r\n}\r\n\r\n\r\n.ip-header{\r\n  font-size: 20px;\r\n  font-weight: 600px;\r\n  margin: 10px 0px 20px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-setting-btn-wrap{\r\n  font-size: 26px;\r\n  font-weight: 600px;\r\n  margin: 5px 10px 0px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  float: right;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.ip-result-header-01{\r\n  width: 20%;\r\n  float: left;\r\n  font-size: 14px;\r\n  text-align: center;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.ip-result-header-02{\r\n  width: 80%;\r\n  float: left;\r\n  font-size: 14px;\r\n  text-align: center;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.ip-result-wrap{\r\n  /* -webkit-box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  -moz-box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15); */\r\n  padding: 5px;\r\n  margin: 0px auto 15px auto;\r\n  border: rgba(205, 205, 205, 0.7) solid 1px;\r\n  width: 99%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.ip-result-col-left{\r\n  width: 20%;\r\n  float: left;\r\n  margin: 0 0.5% 0 0;\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-right{\r\n  width: 39.5%;\r\n  float: left;\r\n  margin: 0 0.5% 0 0;\r\n  border: 1px solid rgba(205, 205, 205, 0.6);\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt{\r\n  width: 39.5%;\r\n  float: left;\r\n  border: 1px solid rgba(205, 205, 205, 0.6);\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-left span{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 14px;\r\n  color: rgba(0, 0, 0, 0.9);\r\n  margin: 5px 0px 2px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right span, .ip-result-col-right-alt span{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 14px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 2px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-left-01{\r\n  width: 100%;\r\n  padding: 5px;\r\n\r\n}\r\n\r\n\r\n.ip-result-col-right-gen{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-01{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-02{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-03{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-01{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-02{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-left-01 img, .ip-result-col-right-01 img, .ip-result-col-right-02 img, .ip-result-col-right-03 img, .ip-result-col-right-gen img{\r\n  width:100%;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-01 img, .ip-result-col-right-alt-02 img{\r\n  width:100%;\r\n}\r\n\r\n\r\n.ip-result-col-left p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.9);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n/* Progress Bar */\r\n\r\n\r\n.progress-bar {\r\n    float: left;\r\n    width: 0;\r\n    height: 100%;\r\n    font-size: 12px;\r\n    line-height: 20px;\r\n    color: #fff;\r\n    text-align: center;\r\n    background-color: #337ab7;\r\n    box-shadow: inset 0 -1px 0 rgba(0,0,0,.15);\r\n    transition: width .6s ease;\r\n}\r\n\r\n\r\n.progress-bar-striped, .progress-striped .progress-bar {\r\n    background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);\r\n    background-size: 40px 40px;\r\n}\r\n\r\n\r\n.progress-bar-info {\r\n    background-color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n\r\n.progress-bar.active, .progress.active .progress-bar {\r\n    -webkit-animation: progress-bar-stripes 2s linear infinite;\r\n    animation: progress-bar-stripes 2s linear infinite;\r\n}\r\n\r\n\r\n.progress {\r\n    height: 20px;\r\n    margin-bottom: 20px;\r\n    overflow: hidden;\r\n    background-color: #f5f5f5;\r\n    border-radius: 0px;\r\n    box-shadow: inset 0 1px 2px rgba(0,0,0,.1);\r\n}\r\n\r\n\r\n.progress-title{\r\n    font-size: 18px;\r\n    font-weight: 700;\r\n    color: #1c2647;\r\n    margin: 0 0 10px;\r\n}\r\n\r\n\r\n.progress{\r\n    height: 30px;\r\n    background: #fff;\r\n    /* border-top: 5px solid #1c2647;\r\n    border-bottom: 5px solid #1c2647; */\r\n    border-radius: 0;\r\n    margin: 0px 0px 20px 0px;\r\n    overflow: visible;\r\n    position: relative;\r\n}\r\n\r\n\r\n/* .progress:before,\r\n.progress:after{\r\n    content: \"\";\r\n    width: 5px;\r\n    background: #1c2647;\r\n    position: absolute;\r\n    top: 0;\r\n    left: -5px;\r\n    bottom: 0;\r\n}\r\n.progress:after{\r\n    left: auto;\r\n    right: -5px;\r\n} */\r\n\r\n\r\n.progress .progress-bar{\r\n    border: none;\r\n    box-shadow: none;\r\n    -webkit-animation: 2s linear 0s normal none infinite running progress-bar-stripes,animate-positive 1s;\r\n    animation: 2s linear 0s normal none infinite running progress-bar-stripes,animate-positive 1s;\r\n}\r\n\r\n\r\n@-webkit-keyframes animate-positive{\r\n    0%{ width: 0; }\r\n}\r\n\r\n\r\n@keyframes animate-positive{\r\n    0%{ width: 0; }\r\n}\r\n\r\n\r\n@-webkit-keyframes progress-bar-stripes{\r\n    from{\r\n        background-position:40px 0\r\n    }\r\n    to{\r\n        background-position:0 0\r\n    }\r\n}\r\n\r\n\r\n@keyframes progress-bar-stripes{\r\n    from{\r\n        background-position:40px 0\r\n    }\r\n    to{\r\n        background-position:0 0\r\n    }\r\n}\r\n\r\n\r\n.details-back-btn{\r\n  position: absolute;\r\n  right: 2px;\r\n  bottom: 2px;\r\n  font-size: 11px;\r\n  /* color: rgba(20, 157, 204, 0.98); */\r\n  color: rgba(0, 0, 0, 0.5);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.view-patch-btn{\r\n  position: absolute;\r\n  left: 2px;\r\n  bottom: 2px;\r\n  font-size: 11px;\r\n  /* color: rgba(20, 157, 204, 0.98); */\r\n  color: rgba(0, 0, 0, 0.5);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap{\r\n  margin: 0px 0px 10px 0px;\r\n  /* text-align: center; */\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap label{\r\n  font-size: 13px;\r\n  /* font-weight: 500; */\r\n  width: auto;\r\n  display: inline-block;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap input{\r\n  width: 240px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap p{\r\n  width: 240px;\r\n  float: right;\r\n  font-size: 11px;\r\n  text-align: left;\r\n  margin: 5px 0px\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap  title{\r\n  font-size: 11px;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap select {\r\n    width: 240px;\r\n    height: 28px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    font-family: 'Arial';\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting{\r\n  margin: 0px 0px 10px 30px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting label{\r\n  font-size: 13px;\r\n  width: auto;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting input{\r\n  width: 150px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting select{\r\n  width: 150px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap button{\r\n  display: inline-block;\r\n  font-size: 15px;\r\n  padding: 5px 20px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.96);\r\n  border: none;\r\n  margin: 15px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap button:disabled{\r\n    background: rgba(20, 157, 204, 0.5);\r\n}\r\n\r\n\r\n.tooltip {\r\n    position: relative;\r\n\r\n}\r\n\r\n\r\n.tooltip .tooltiptext {\r\n    visibility: hidden;\r\n    width: 250px;\r\n    background: rgba(10, 10, 10, 1);\r\n    color: #fff;\r\n    text-align: left;\r\n    border-radius: 6px;\r\n    padding: 5px;\r\n    font-size: 12px;\r\n    line-height: 14px;\r\n    font-weight: 400;\r\n\r\n    /* Position the tooltip */\r\n    position: absolute;\r\n    bottom: 150%;\r\n    left: 50%;\r\n    margin-left: -95px;\r\n    z-index: 1;\r\n    overflow: visible !important;\r\n}\r\n\r\n\r\n.tooltip:hover .tooltiptext {\r\n    visibility: visible;\r\n}\r\n\r\n\r\n.tooltip .tooltiptext::after {\r\n    content: \" \";\r\n    position: absolute;\r\n    top: 100%; /* At the bottom of the tooltip */\r\n    left: 50%;\r\n    margin-left: -5px;\r\n    border-width: 5px;\r\n    border-style: solid;\r\n    border-color: black transparent transparent transparent;\r\n}\r\n\r\n\r\n.checkbox_wrap {\r\n  width: 25px !important;\r\n    display: block;\r\n    position: relative;\r\n    padding: 5px;\r\n    margin: 0px 5px 5px 0px;\r\n    cursor: pointer;\r\n    font-size: 22px;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n}\r\n\r\n\r\n/* Hide the browser's default checkbox */\r\n\r\n\r\n.checkbox_wrap input {\r\n    position: absolute;\r\n    opacity: 0;\r\n    cursor: pointer;\r\n}\r\n\r\n\r\n/* Create a custom checkbox */\r\n\r\n\r\n.checkmark {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    height: 20px;\r\n    width: 20px;\r\n    background-color: #eee;\r\n}\r\n\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n\r\n.checkbox_wrap:hover input ~ .checkmark {\r\n    background-color: #ccc;\r\n}\r\n\r\n\r\n/* When the checkbox is checked, add a blue background */\r\n\r\n\r\n.checkbox_wrap input:checked ~ .checkmark {\r\n    background-color: #2196F3;\r\n}\r\n\r\n\r\n/* Create the checkmark/indicator (hidden when not checked) */\r\n\r\n\r\n.checkmark:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    display: none;\r\n}\r\n\r\n\r\n/* Show the checkmark when checked */\r\n\r\n\r\n.checkbox_wrap input:checked ~ .checkmark:after {\r\n    display: block;\r\n}\r\n\r\n\r\n/* Style the checkmark/indicator */\r\n\r\n\r\n.checkbox_wrap .checkmark:after {\r\n    left: 6px;\r\n    top: 2px;\r\n    width: 5px;\r\n    height: 10px;\r\n    border: solid white;\r\n    border-width: 0 3px 3px 0;\r\n    -webkit-transform: rotate(45deg);\r\n    transform: rotate(45deg);\r\n}\r\n\r\n\r\n.info-container {\r\n  padding: 12px 16px;\r\n\r\n  line-height: 24px;\r\n}\r\n\r\n\r\n.action-container,\r\n.content-container {\r\n  position: relative;\r\n\r\n  overflow: auto;\r\n  height: 300px;\r\n  min-height: 0;\r\n  margin: 8px 16px;\r\n  border-radius: 4px;\r\n\r\n  background-color: #fff;\r\n}\r\n\r\n\r\n.action-container {\r\n  padding: 16px;\r\n}\r\n\r\n\r\n.vertical-container,\r\n.horizontal-container {\r\n  min-height: 0 !important;\r\n}\r\n\r\n\r\n.action-button {\r\n  box-sizing: border-box;\r\n  width: calc(100% - 16px);\r\n  min-height: 35px;\r\n  padding: 4px 16px;\r\n  margin: 8px;\r\n  border: 1px solid #555;\r\n  border-radius: 4px;\r\n\r\n  cursor: pointer;\r\n  font-size: 14px;\r\n  font-weight: bold;\r\n  line-height: 14px;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.action-button:hover {\r\n  color: #fff;\r\n  background-color: #555;\r\n}\r\n\r\n\r\n.swiper-container {\r\n  position: absolute;\r\n  top: 0;\r\n  right: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n}\r\n\r\n\r\n.swiper-slide {\r\n  color: #aaa;\r\n  /* background-color: #eee; */\r\n}\r\n\r\n\r\n.swiper-slide-active {\r\n  color: #fff;\r\n  /* background-color: #aaa; */\r\n}\r\n\r\n\r\n.ngx-pagination{\r\n  width: 100%;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.google-search-wrap{\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.9);\r\n  float: right;\r\n  margin: 5px 15px 5px 0px;\r\n}\r\n\r\n\r\n.google-search-wrap a{\r\n  text-decoration: none;\r\n  color: rgba(0, 0, 0, 0.9);\r\n}\r\n\r\n\r\n.ip-filter-wrap{\r\n  float: left;\r\n  text-align: center;\r\n  margin: 0px 0px 0px 0px\r\n}\r\n\r\n\r\n.ip-filter-wrap div{\r\n  display: inline-block;\r\n  margin: 0px 0px;\r\n}\r\n\r\n\r\n.ip-filter-wrap div button{\r\n  border: none;\r\n  background: rgba(205, 205, 205, 0.6);\r\n  color: rgba(0, 0, 0, 0.6);\r\n  border-right: solid 1px rgba(205, 205, 205, 0.6);\r\n  /* border-left: solid 1px rgba(20, 157, 204, 0.9); */\r\n  padding: 10px 15px;\r\n  margin: 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.ip-filter-wrap div button:hover, .ip-filter-wrap div button.active{\r\n  background: rgba(255, 255, 255, 0.9);\r\n  color: rgba(0, 0, 0, 0.6);\r\n  /* border-bottom: solid 1px rgba(255, 255, 255, 0.9); */\r\n}\r\n\r\n\r\n.lime-setting-probablitychange-wrap{\r\n  margin: 10px 0px 0px 0px;\r\n  font-size: 13px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  text-align: center;\r\n  min-height: 40px;\r\n}\r\n\r\n\r\n.lspcw-01{\r\n  display: inline-block;\r\n  margin: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n.lspcw-02, .lspcw-03{\r\n  display: inline-block;\r\n  margin: 2px 0px 3px 0px;\r\n}\r\n\r\n\r\n.lspcw-04{\r\n  display: inline-block;\r\n  margin: 2px 2px 3px 2px;\r\n  width: 540px;\r\n  text-align: right;\r\n}\r\n\r\n\r\n.lspcw-05{\r\n  display: inline-block;\r\n  margin: 2px 2px 3px 2px;\r\n  width: 180px;\r\n}\r\n\r\n\r\n.lspcw-06{\r\n  display: inline-block;\r\n  margin: 2px 2px 3px 2px;\r\n  width: 180px;\r\n}\r\n\r\n\r\n.lspcw-02 input, .lspcw-03 input, .lspcw-04 input, .lspcw-05 input, .lspcw-06 input{\r\n  width: 30px;\r\n  font-size: 12px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  margin: 0 5px;\r\n  padding: 2px 2px;\r\n}\r\n\r\n\r\n.lspcw-02 button, .lspcw-03 button, .lspcw-04 button, .lspcw-05 button, .lspcw-06 button{\r\n  /* padding: 5px; */\r\n  background: rgba(205, 205, 205, 0.6);\r\n  color: rgba(0, 0, 0, 0.6);\r\n  text-decoration: none;\r\n  border: none;\r\n  /* background: none; */\r\n  cursor: pointer;\r\n  padding: 3px 10px;\r\n}\r\n\r\n\r\n.commentbox-wrap{\r\n  width: 100%;\r\n  margin: 10px 0px 5px 0px;\r\n  display: none;\r\n}\r\n\r\n\r\n.commentbox-wrap.active{\r\n  display: block;\r\n}\r\n\r\n\r\n.commentbox-wrap span{\r\n  display: block;\r\n  width: 100%;\r\n  margin: 5px 0px 5px 0px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n}\r\n\r\n\r\n.commentbox-wrap textarea{\r\n  width: 100%;\r\n  height: 100px;\r\n  padding:5px;\r\n  color: rgba(0, 0, 0, 0.4);\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  border-radius: 0px;\r\n}\r\n\r\n\r\n.commentbox-wrap p{\r\n  float: left;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n}\r\n\r\n\r\n.comment-submit-wrap{\r\n  text-align: right;\r\n  float: right;\r\n}\r\n\r\n\r\n.comment-submit-wrap button{\r\n  /* padding: 5px; */\r\n  background: rgba(205, 205, 205, 0.6);\r\n  color: rgba(0, 0, 0, 0.6);\r\n  text-decoration: none;\r\n  border: none;\r\n  /* background: none; */\r\n  cursor: pointer;\r\n  padding: 3px 10px;\r\n}\r\n\r\n\r\n.limeResult-followup-wrap{\r\n  position: absolute;\r\n  background: rgba(255, 255, 255, 1);\r\n  top: 0px;\r\n  right: 0px;\r\n}\r\n\r\n\r\n.limeResult-followup-wrap label{\r\n  display: inline-block;\r\n}\r\n\r\n\r\n.comment-icon-wrap{\r\n  display: inline-block;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  font-size: 16px;\r\n  margin: 0px 0px;\r\n}\r\n\r\n\r\n.comment-icon-wrap-alt{\r\n  display: inline-block;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  font-size: 20px;\r\n  margin: 0px 5px;\r\n}\r\n\r\n\r\n.comment-icon-wrap.active, .comment-icon-wrap-alt.active{\r\n  color: rgba(33, 150, 244, 0.98);\r\n}\r\n\r\n\r\n.showcase {\r\n  display: inline-block;\r\n}\r\n\r\n\r\n.showcase  .content {\r\n    border-radius: 0px;\r\n    width: 176px;\r\n    height: auto;\r\n    /* max-height: 200px; */\r\n    padding: 0px;\r\n    overflow-x: hidden;\r\n    overflow-y: hidden;\r\n    white-space: nowrap;\r\n    min-height: 191px;\r\n}\r\n\r\n\r\n/*\r\n.showcase  .content ul{\r\n    margin: 0;\r\n\tpadding: 0;\r\n\tlist-style: none;\r\n\toverflow: hidden;\r\n  overflow-x: auto;\r\n  white-space: nowrap;\r\n}\r\n\r\n.showcase .content ul li{\r\n    float: left;\r\n    width: 200px;\r\n}\r\n\r\n.showcase .content ul li img{\r\n    width: 200px;\r\n}\r\n*/\r\n\r\n\r\n.showcase .content img{\r\n  display: inline-block;\r\n  height: 173px;\r\n  width: auto;\r\n  margin: 0 1px;\r\n}\r\n\r\n\r\n.sidenav-select-project select, .sidenav-select-benchmark select {\r\n    width: 240px;\r\n    height: 28px;\r\n    font-size: 13px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n\r\n.sidenav-select-project select option{\r\n  margin: 2px 0px 2px 0px;\r\n}\r\n\r\n\r\n.sidenav-select-project select option span{\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.sidenav-comparewrap-header{\r\n  margin: 5px 0px 10px 10px;\r\n}\r\n\r\n\r\n.sidenav-comparewrap-header span{\r\n  font-size: 16px;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.compare-proj-wrap{\r\n  width: 230px;\r\n  margin: 0px 0px 0px 10px;\r\n}\r\n\r\n\r\n/* Compare check box */\r\n\r\n\r\n.container-radiobtn {\r\n  display: block;\r\n  position: relative;\r\n  padding:2px 0px 0px 23px;\r\n  margin:0px 10px 15px 0px;\r\n  cursor: pointer;\r\n  font-size: 13px;\r\n  -webkit-user-select: none;\r\n  -moz-user-select: none;\r\n  -ms-user-select: none;\r\n  user-select: none;\r\n  display: inline-block;\r\n  width: 100px;\r\n}\r\n\r\n\r\n/* Hide the browser's default radio button */\r\n\r\n\r\n.container-radiobtn input {\r\n  position: absolute;\r\n  opacity: 0;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n/* Create a custom radio button */\r\n\r\n\r\n.checkmark-radiobtn {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  height: 20px;\r\n  width: 20px;\r\n  background-color: #eee;\r\n  border-radius: 50%;\r\n}\r\n\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n\r\n.container-radiobtn:hover input ~ .checkmark-radiobtn {\r\n  background-color: #ccc;\r\n}\r\n\r\n\r\n/* When the radio button is checked, add a blue background */\r\n\r\n\r\n.container-radiobtn input:checked ~ .checkmark-radiobtn {\r\n  background-color: #2196F3;\r\n}\r\n\r\n\r\n/* Create the indicator (the dot/circle - hidden when not checked) */\r\n\r\n\r\n.checkmark-radiobtn:after {\r\n  content: \"\";\r\n  position: absolute;\r\n  display: none;\r\n}\r\n\r\n\r\n/* Show the indicator (dot/circle) when checked */\r\n\r\n\r\n.container-radiobtn input:checked ~ .checkmark-radiobtn:after {\r\n  display: block;\r\n}\r\n\r\n\r\n/* Style the indicator (dot/circle) */\r\n\r\n\r\n.container-radiobtn .checkmark-radiobtn:after {\r\n \ttop: 6px;\r\n\tleft: 6px;\r\n\twidth: 8px;\r\n\theight: 8px;\r\n\tborder-radius: 50%;\r\n\tbackground: white;\r\n}\r\n\r\n\r\n.compare-submitbtn{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.compare-submitbtn button{\r\n  padding: 7px 15px;\r\n  border:none;\r\n  margin: 0px 0px 0px 10px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.98);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.compare-submitbtn button:disabled{\r\n  background: rgba(204, 204, 204, 0.98);\r\n  color: rgba(130, 130, 130, 0.98);\r\n}\r\n\r\n\r\ninput[type=number]::-webkit-inner-spin-button,\r\ninput[type=number]::-webkit-outer-spin-button {\r\n  -webkit-appearance: none;\r\n  margin: 0;\r\n}\r\n\r\n"

/***/ }),

/***/ "./src/app/image-classifier/image-classifier.component.html":
/*!******************************************************************!*\
  !*** ./src/app/image-classifier/image-classifier.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"img-classifier-wrap\">\r\n<mat-drawer-container class=\"insidepage-container\" autosize>\r\n<mat-drawer #drawer class=\"insidepage-sidenav content\" mode=\"side\">\r\n<div class=\"sidenav-cont-header\">\r\n<span>Project & Benchmark</span> <!-- <a (click)=\"showMainSetting = !showMainSetting\" ><i class=\"fa fa-cogs\"></i></a> -->\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"sidenav-select-project\">\r\n  <span>Project / Benchmark Models</span>\r\n  <form name=\"form\" #spf=\"ngForm\" novalidate>\r\n    <select name=\"projectname\" [(ngModel)]=\"spmodel.projectname\" #projectname=\"ngModel\" (ngModelChange)=\"projectNameChange($event)\">\r\n      <!-- <option value=\"Project 1\" selected>Project 1</option>\r\n      <option value=\"Project 2\">Project 2</option> -->\r\n      <option *ngFor=\"let pName of projectList; let i = index\" value={{pName}} [selected]=\"i == 0\">{{pName}}</option>\r\n      <option disabled><span>Benchmark</span></option>\r\n      <option value=\"Benchmark/InceptionV3\">InceptionV3</option>\r\n      <option value=\"Benchmark/TrafficSign\">TrafficSign</option>\r\n      <option value=\"Benchmark/ResNet\">ResNet</option>\r\n      <option value=\"Benchmark/DenseNet\">DenseNet</option>\r\n    </select>\r\n  </form>\r\n</div>\r\n\r\n\r\n\r\n\r\n<div class=\"sidenav-cont-header\">\r\n<span>{{ projectNameDisplay }} ran for</span> <!-- <a (click)=\"showMainSetting = !showMainSetting\" ><i class=\"fa fa-cogs\"></i></a> -->\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n<!-- <form class=\"form-horizontal\" [formGroup]=\"imgClassifierForm\" ngIfnovalidate (ngSubmit)=\"createProject()\"> -->\r\n<form name=\"form\" #f=\"ngForm\" novalidate>\r\n<div class=\"sidenav-form-wrap\">\r\n<div class=\"sidenav-cont-wrap sidenav-cont-input\">\r\n<!-- <span>Project Name</span>\r\n<input type=\"text\"\r\nclass=\"form-control\"\r\nformControlName=\"projectName\"\r\nrequired\r\nplaceholder=\"Project Name\"\r\n>\r\n<div class=\"form-control-validation\"\r\n*ngIf=\"projectName.errors && (projectName.dirty || projectName.touched)\">\r\n<p>Project name is required</p>\r\n</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n<div class=\"sidenav-cont-wrap sidenav-cont-input\">\r\n<span>Model Path</span>\r\n<input type=\"text\"\r\nclass=\"form-control\"\r\nformControlName=\"modelName\"\r\nrequired\r\nplaceholder=\"Model Path\">\r\n<div class=\"form-control-validation\"\r\n*ngIf=\"modelName.errors && (modelName.dirty || modelName.touched)\">\r\n<p>Model path is required</p>\r\n</div>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n\r\n<div class=\"sidenav-cont-wrap sidenav-cont-input\">\r\n<span>Sample Data Path</span>\r\n<input type=\"text\"\r\nclass=\"form-control\"\r\nformControlName=\"sampleData\"\r\nrequired\r\nplaceholder=\"Sample Data Path\">\r\n<div class=\"form-control-validation\"\r\n*ngIf=\"sampleData.errors && (sampleData.dirty || sampleData.touched)\">\r\n<p>Sample data is required</p>\r\n</div>\r\n</div>\r\n<div class=\"sidenav-cont-wrap\">\r\n<div class=\"sidenav-cont-settings-wrap\">\r\n<button type=\"submit\" class=\"btn-register\" [disabled]=\"(checkicValue()!==true || !imgClassifierForm.valid)\">\r\nTesting For Trust\r\n</button>\r\n</div> -->\r\n<div class=\"imageclassifiersetting-cont-wrap\">\r\n<div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"this.model.fourierfilteringValue || this.model.colortograyscaleValue || this.model.contrastValue || this.model.additivenoiseValue || this.model.eidolonnoiseValue || this.model.modelcomplexityValue\" type=\"checkbox\"\r\n      name=\"generalizaionValue\" [(ngModel)]=\"model.generalizaionValue\" #generalizaionValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Generalization <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Measures the ability of the algorithm to perform well on new inputs not seen during training.\r\n    </span>\r\n  </label>\r\n\r\n  <!-- <input type=\"text\" name=\"thresholdValue\" [(ngModel)]=\"model.thresholdValue\" #thresholdValue=\"ngModel\" (ngModelChange)=\"thresholdValueChange($event)\" class=\"form-control\"> -->\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"rotationtranslationValue\" [(ngModel)]=\"model.rotationtranslationValue\" #rotationtranslationValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Rotation & Translation <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks the ability of the classifier to be invariant to small rotations (i.e. changing the orientation) and translations (shifting of the pixels) of the image.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"fourierfilteringValue\" [(ngModel)]=\"model.fourierfilteringValue\" #fourierfilteringValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Fourier Filtering <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks the ability of the classifier to be invariant to information loss – where frequencies with low information content are removed.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"colortograyscaleValue\" [(ngModel)]=\"model.colortograyscaleValue\" #colortograyscaleValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Color to Grayscale <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks whether the classifier is invariant to the color content of the image.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"contrastValue\" [(ngModel)]=\"model.contrastValue\" #contrastValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Contrast <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks whether the classifier is invariant to the contrast of the image.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"additivenoiseValue\" [(ngModel)]=\"model.additivenoiseValue\" #additivenoiseValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Additive noise <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks whether the classifier is invariant to low amounts of noise in an image.\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"eidolonnoiseValue\" [(ngModel)]=\"model.eidolonnoiseValue\" #eidolonnoiseValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Eidolon noise <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<!-- <div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"modelcomplexityValue\" [(ngModel)]=\"model.modelcomplexityValue\" #modelcomplexityValue=\"ngModel\" (ngModelChange)=\"ongensubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Model Complexity <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks whether the model is susceptible to overfitting or underfitting.\r\n    </span>\r\n  </label>\r\n</div> -->\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"model.adversarialExamplesValue || this.model.adversarialPatchesValue || this.model.modelComplexityValue\" type=\"checkbox\" name=\"robustnessValue\" [(ngModel)]=\"model.robustnessValue\" #robustnessValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Robustness <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Measures the ability of the algorithm to be not susceptible to maliciously crafted inputs to specifically fool the algorithm.\r\n    </span>\r\n  </label>\r\n\r\n  <!-- <input type=\"text\" name=\"thresholdValue\" [(ngModel)]=\"model.thresholdValue\" #thresholdValue=\"ngModel\" (ngModelChange)=\"thresholdValueChange($event)\" class=\"form-control\"> -->\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"adversarialPatchesValue\" [(ngModel)]=\"model.adversarialPatchesValue\" #adversarialPatchesValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Adversarial Patches <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This tests the impact of the classifier when a specially crafted adversarial patch is introduced.\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"fastGradientSignMethod\" [(ngModel)]=\"model.fastGradientSignMethod\" #fastGradientSignMethod=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Adversarial Inputs - FGSM <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"carliniWagnerMethod\" [(ngModel)]=\"model.carliniWagnerMethod\" #carliniWagnerMethod=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Adversarial Inputs - CW <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<!-- <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"discriminationValue\" [(ngModel)]=\"model.discriminationValue\" #discriminationValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Discrimination <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Any distinction, exclusion or preference made on the basis of race, color, sex, religion, political opinion, national extraction or social origin, which has the effect of nullifying or impairing equality of opportunity or\r\n      treatment.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div> -->\r\n<div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"explainabilityValue\" [(ngModel)]=\"model.explainabilityValue\" #explainabilityValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Interpretability <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Provides clue to interpret the decision of the algorithm.\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<!-- <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n<button>Submit</button>\r\n</div> -->\r\n</div>\r\n\r\n</div>\r\n</div>\r\n</form>\r\n<div class=\"sidenav-comparewrap-header\">\r\n<span>Select & Compare</span>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<form name=\"form\" #cpf=\"ngForm\" novalidate>\r\n<div class=\"compare-proj-wrap\">\r\n  <label class=\"container-radiobtn\" *ngFor=\"let item of compareData\"> {{ item.name }}\r\n    <input type=\"checkbox\" class=\"compare\" [(ngModel)]=\"item.checked\" [name]=\"item.name\" (ngModelChange)=\"compareChanged(item.checked)\">\r\n    <span class=\"checkmark-radiobtn\"></span>\r\n  </label>\r\n</div>\r\n<div class=\"compare-submitbtn\"><button [disabled]=\"compareEnable\" (click)=\"comparisonGraph = !comparisonGraph; prepareGraph()\">Compare</button>\r\n</div>\r\n</form>\r\n\r\n<div class=\"clearfix\"></div>\r\n\r\n<div class=\"sidenav-cont-header\">\r\n<span>Performance</span>\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"sidenav-select-project\">\r\n  <span>Project / Benchmark Models</span>\r\n  <form name=\"form\" #spf=\"ngForm\" novalidate>\r\n    <select name=\"projectname\" [(ngModel)]=\"spPerformanceModel.performanceProjectName\" #projectname=\"ngModel\" (ngModelChange)=\"projectNameChangeForPerformance($event)\">\r\n      <option *ngFor=\"let pName of projectListForPerformance; let i = index\" value={{pName}} [selected]=\"i == 0\">{{pName}}</option>\r\n      <option disabled><span>Benchmark</span></option>\r\n      <option value=\"Benchmark/InceptionV3\">InceptionV3</option>\r\n      <option value=\"Benchmark/TrafficSign\">TrafficSign</option>\r\n      <option value=\"Benchmark/ResNet\">ResNet</option>\r\n      <option value=\"Benchmark/DenseNet\">DenseNet</option>\r\n    </select>\r\n  </form>\r\n  <a (click)=\"performanceGraph = !performanceGraph\">View Performance</a>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"sidenav-comparewrap-header\">\r\n<span>Select & Compare Inference</span>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<form name=\"pcform\" #pcgf=\"ngForm\" novalidate>\r\n<div class=\"compare-proj-wrap\">\r\n  <label class=\"container-radiobtn\" *ngFor=\"let item of compareData2\"> {{ item.name }}\r\n    <input type=\"checkbox\" class=\"compare\" [(ngModel)]=\"item.checked\" [name]=\"item.name\" (ngModelChange)=\"compareChangedMInfer(item.checked)\">\r\n    <span class=\"checkmark-radiobtn\"></span>\r\n  </label>\r\n</div>\r\n<div class=\"compare-submitbtn\"><button [disabled]=\"compareEnable2\" (click)=\"performanceComparisonGraph = !performanceComparisonGraph; prepareGraphMInfer()\">Compare</button>\r\n</div>\r\n</form>\r\n\r\n</mat-drawer>\r\n\r\n<div class=\"insidepage-sidenav-content\">\r\n<button class=\"btn-menu\" type=\"button\" mat-button (click)=\"drawer.toggle()\">\r\n<div #menuBurger class=\"burger\" (click)=\"menuclick()\" id=\"menuBurger\">\r\n<div class=\"x\"></div>\r\n<div class=\"y\"></div>\r\n<div class=\"z\"></div>\r\n</div>\r\n</button>\r\n\r\n<mat-tab-group class=\"full-width-wrap\" md-no-pagination=\"true\" (selectedTabChange)=\"forceScrollUpdate($event)\" animationDuration=\"2000ms\" [selectedIndex]=\"selectedActiveIndex\">\r\n\r\n<mat-tab label=\"Generalization\">\r\n<ng-template matTabContent>\r\n\r\n<div class=\"innerpage-wrap\">\r\n<div class=\"innerpage-row innerpage-row-01\" >\r\n  <div class=\"innerpage-row-col row-col-left\">\r\n    <div class=\"row-col-header\">\r\n      <span>Rotation & Translation</span>\r\n      <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"rnts\" class=\"fa fa-cogs\"></i></a>\r\n    </div>\r\n    <div class=\"row-col-content\">\r\n      This test checks the ability of the classifier to be invariant to small rotations (i.e. changing the orientation) and translations (shifting of the pixels) of the image.\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"rotNtrans\">\r\n      Rotation & Translation Results Not Available.\r\n  </div>\r\n  <div *ngIf=\"!rotNtrans\">\r\n  <div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableRotationTranslation\">\r\n    <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n    <div class=\"clearfix\"></div>\r\n\r\n    <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecRotationTranslationData\">\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n          <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">On Original</div>\r\n      </div>\r\n\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n          <span>{{ rec.overallMatricsPrecision }}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">On Rotation & Translation</div>\r\n      </div>\r\n    </div>\r\n    <div class=\"circle-btn\" (click)=\"showDetailFuncRotationTranslation()\">View Further Details</div>\r\n  </div>\r\n  </div>\r\n  <div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableRotationTranslation\">\r\n    <div class=\"row-col-matrix-content\">\r\n      <div class=\"col-right-table-wrap\">\r\n        <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n        <div class=\"detailExample-wrap\">\r\n          <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_RotationTranslation\">\r\n            <div class=\"detailExample-cont-className\" title=\" {{ rec.className }} \" (click)=\"selectedClassItems_RotationTranslation($event); rotationtranslationClassClick()\">{{rec.className}}</div>\r\n            <div class=\"detailExample-cont-circle\">\r\n              <div class=\"c100 p{{rec.originalExample}} small green\">\r\n                <span>{{ rec.originalExample }}%</span>\r\n                <div class=\"slice\">\r\n                  <div class=\"bar\"></div>\r\n                  <div class=\"fill\"></div>\r\n                </div>\r\n              </div>\r\n              <div class=\"detailExample-cont-header\">On Original</div>\r\n            </div>\r\n            <div class=\"detailExample-cont-circle\">\r\n              <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n                <span>{{rec.adversarialExample}}%</span>\r\n                <div class=\"slice\">\r\n                  <div class=\"bar\"></div>\r\n                  <div class=\"fill\"></div>\r\n                </div>\r\n              </div>\r\n              <div class=\"detailExample-cont-header\">On Rotation & Translation</div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableRotationTranslation\">\r\n    <div class=\"slider-txt-display\" *ngIf=\"rotationtranslationshowPara\">\r\n      <p>Click on Class Name to view the Example of each Class</p>\r\n    </div>\r\n    <div class=\"slider-wrap\" *ngIf=\"rotationtranslationshowSlider\">\r\n\t<div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index1\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecRotationTranslationImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{ item.orgName }}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/RotationNTranslation/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n      <p title=\"With Rotation {{ item.rotationDegree }} Degree/s & Translation of {{ item.translationPixel\r\n       }} Pixels, Image Classified as - {{item.perName}}\">With Rotation {{ item.rotationDegree }} Degree/s & Translation of {{ item.translationPixel\r\n       }} Pixels, Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/RotationNTranslation/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n\r\n    </div>\r\n    <div class=\"details-back-btn\" (click)=\"showInitialFuncRotationTranslation()\">View Overall Metrics.</div>\r\n  </div>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-02\" >\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Fourier Filtering</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"ffs\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks the ability of the classifier to be invariant to information loss – where frequencies with low information content are removed.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"fourierFilter\">\r\n        Fourier Filtering Information Not Available.\r\n</div>\r\n<div *ngIf=\"!fourierFilter\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableFourierFiltering\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallFourierData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Fourier Filtering</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncFourierFiltering()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableFourierFiltering\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Fourier\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_Fourier($event); fourierfilteringClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Fourier Filtering</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableFourierFiltering\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"fourierfilteringshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"fourierfilteringshowSlider\">\r\n    <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index2\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of fourierFilteredImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/FourierRadialFiltering/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/FourierRadialFiltering/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncFourierFiltering()\">View Overall Metrics.</div>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n\r\n<div class=\"innerpage-row innerpage-row-03\" >\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Gray Scale</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"gss\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks whether the classifier is invariant to the color content of the image.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"objRecGrayScale\">\r\n        Gray Scale Information not Available.\r\n</div>\r\n<div *ngIf=\"!objRecGrayScale\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableGrayScale\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecGrayScaleData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Gray Scale</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncGrayScale()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableGrayScale\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_GrayScale\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_GrayScale($event); grayscaleClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Gray Scale</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableGrayScale\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"grayscaleshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"grayscaleshowSlider\">\r\n    <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index3\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecGrayScaleImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/GrayScale/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/GrayScale/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncGrayScale()\">View Overall Metrics.</div>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n\r\n<div class=\"innerpage-row innerpage-row-04\" >\r\n\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Contrast</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"cs\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks whether the classifier is invariant to the contrast of the image.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"objLowContrast\">\r\n        Low Contrast Information not Available.\r\n</div>\r\n<div *ngIf=\"!objLowContrast\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableContrast\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecContrastData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Contrast</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncContrast()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableContrast\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_Contrast\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_Contrast($event); contrastClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Contrast</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableContrast\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"contrastshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n\r\n  <div class=\"slider-wrap\" *ngIf=\"contrastshowSlider\">\r\n    <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index4\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecContrastImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/LowContrast/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/LowContrast/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncContrast()\">View Overall Metrics.</div>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n\r\n<div class=\"innerpage-row innerpage-row-05\" >\r\n\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Additive Noise</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"ans\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks whether the classifier is invariant to low amounts of noise in an image.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"objAddNoise\">\r\n        Additive Noise Information not Available.\r\n</div>\r\n<div *ngIf=\"!objAddNoise\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableAdditiveNoise\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecAdditiveNoiseData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Additive Noise</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncAdditiveNoise()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableAdditiveNoise\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_AdditiveNoise\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_AdditiveNoise($event); addtivenoiseClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Additive Noise</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableAdditiveNoise\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"additivenoiseshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"additivenoiseshowSlider\">\r\n    <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index5\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecAdditiveNoiseImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/Noisy/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/Noisy/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncAdditiveNoise()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n\r\n<div class=\"innerpage-row innerpage-row-06\" >\r\n\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Eidolon Noise</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"ens\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks whether the classifier is invariant to noise which creates a form of deformation (Eidolon) that is not a problem for human vision.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"objEdNoise\">\r\n        Eidolon Noise Information not Available.\r\n</div>\r\n<div *ngIf=\"!objEdNoise\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableEidolonNoise\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecEidolonNoiseData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Eidolon Noise</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncEidolonNoise()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableEidolonNoise\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_EidolonNoise\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_EidolonNoise($event); eidolonnoiseClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Eidolon Noise</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableEidolonNoise\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"eidolonnoiseshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"eidolonnoiseshowSlider\">\r\n    <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index6\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecEidolonNoiseImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/Eidolon/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Generalization/Object_Recognition/Eidolon/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncEidolonNoise()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n\r\n<!-- <div class=\"innerpage-row innerpage-row-07\">\r\n\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Model Complexity</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"mcs\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This test checks whether the model is susceptible to overfitting or underfitting.\r\n  </div>\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableModelComplexity\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallObjRecModelComplexityData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Model Complexity</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncModelComplexity()\">View Further Details</div>\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableModelComplexity\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class Model</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Obj_ModelComplexity\">\r\n          <div class=\"detailExample-cont-className\" (click)=\"selectedClassItems_ModelComplexity($event); modelcomplexityClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Model Complexity</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableModelComplexity\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"modelcomplexityshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"modelcomplexityshowSlider\">\r\n\r\n\t<div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index7\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of objectRecModelComplexityImages\" class=\"swiper-slide\">\r\n    <div >\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p>Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/Generalization/ModelComplexity/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p>Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/Generalization/ModelComplexity/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncModelComplexity()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div> -->\r\n\r\n\r\n</div>\r\n</ng-template>\r\n</mat-tab>\r\n\r\n<mat-tab label=\"Robustness\">\r\n<ng-template matTabContent>\r\n<div class=\"innerpage-wrap\">\r\n  <!-- Patches Code goes here -->\r\n\r\n<div class=\"innerpage-row innerpage-row-09\" >\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Adversarial Patches</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"aps\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n    This tests the impact of the classifier when a specially crafted adversarial patch is introduced.\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"advPatches\">\r\n        Adversarial Patches Information not Available.\r\n</div>\r\n<div *ngIf=\"!advPatches\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableAdversarialPatches\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallAdversarialPatchesData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Adversarial Patches</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncAdversarialPatches()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableAdversarialPatches\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_AdversarialPatches\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_AdversarialPatches($event); adversarialpatchesClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Adversarial Patches</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableAdversarialPatches\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"adversarialpatchesshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"adversarialpatchesshowSlider\">\r\n\r\n  <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index9\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of adversarialPatchesImages\" class=\"swiper-slide\" >\r\n    <div>\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialPatches/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialPatches/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n  </div>\r\n  <div class=\"adversarialpatche-display\" *ngIf=\"adversarialpatchesshowPatch\">\r\n    <div *ngFor=\"let item of adversarialPatchesImages | slice:0:1\">\r\n      <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialPatches/Results/patch.png\">\r\n      <a href=\"./assets/results/{{ projectName }}/Robustness/AdversarialPatches/Results/patch.png\" download=\"patch.png\">Download Patch</a>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"view-patch-btn\" *ngIf=\"showViewPatch\" (click)=\"showAdversarialPatches()\">View Patch</div>\r\n  <div class=\"view-patch-btn\" *ngIf=\"showHidePatch\" (click)=\"hideAdversarialPatches()\">Hide Patch</div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncAdversarialPatches()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-08\" >\r\n<div class=\"innerpage-row-col row-col-left\">\r\n<div class=\"row-col-header\">\r\n  <span>Adversarial Inputs </span>\r\n  <span class=\"row-col-header-sub\"> (Fast Gradient Sign Method)</span>\r\n  <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"ais\" class=\"fa fa-cogs\"></i></a>\r\n</div>\r\n<div class=\"row-col-content\">\r\n  This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"adversInp\">\r\n      Adversarial Information not Available.\r\n</div>\r\n<div *ngIf=\"!adversInp\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableAdversarialInputs\">\r\n<div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n<div class=\"clearfix\"></div>\r\n\r\n<div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallAdversarialData\">\r\n  <div class=\"initial-circle-content\">\r\n    <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n      <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n      <div class=\"slice\">\r\n        <div class=\"bar\"></div>\r\n        <div class=\"fill\"></div>\r\n      </div>\r\n    </div>\r\n    <div class=\"circle-header\">On Original</div>\r\n  </div>\r\n\r\n  <div class=\"initial-circle-content\">\r\n    <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n      <span>{{ rec.overallMatricsPrecision }}%</span>\r\n      <div class=\"slice\">\r\n        <div class=\"bar\"></div>\r\n        <div class=\"fill\"></div>\r\n      </div>\r\n    </div>\r\n    <div class=\"circle-header\">On Adversarial Inputs</div>\r\n  </div>\r\n</div>\r\n<div class=\"circle-btn\" (click)=\"showDetailFuncAdversarialInputs()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableAdversarialInputs\">\r\n<div class=\"row-col-matrix-content\">\r\n  <div class=\"col-right-table-wrap\">\r\n    <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n    <div class=\"detailExample-wrap\">\r\n      <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_Adv\">\r\n        <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_AdversarialInputs($event); adversarialInputsClassClick()\">{{rec.className}}</div>\r\n        <div class=\"detailExample-cont-circle\">\r\n          <div class=\"c100 p{{rec.originalExample}} small green\">\r\n            <span>{{ rec.originalExample }}%</span>\r\n            <div class=\"slice\">\r\n              <div class=\"bar\"></div>\r\n              <div class=\"fill\"></div>\r\n            </div>\r\n          </div>\r\n          <div class=\"detailExample-cont-header\">On Original</div>\r\n        </div>\r\n        <div class=\"detailExample-cont-circle\">\r\n          <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n            <span>{{rec.adversarialExample}}%</span>\r\n            <div class=\"slice\">\r\n              <div class=\"bar\"></div>\r\n              <div class=\"fill\"></div>\r\n            </div>\r\n          </div>\r\n          <div class=\"detailExample-cont-header\">On Adversarial Inputs</div>\r\n        </div>\r\n        <div class=\"clearfix\"></div>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableAdversarialInputs\">\r\n<div class=\"slider-txt-display\" *ngIf=\"adversarialInputsshowPara\">\r\n  <p>Click on Class Name to view the Example of each Class</p>\r\n</div>\r\n<div class=\"slider-wrap\" *ngIf=\"adversarialInputsshowSlider\">\r\n <div class=\"carousel-wrapper\">\r\n  <swiper  [config]=\"config\" [(index)]=\"index8\" [disabled]=\"disabled\"\r\n  (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n  <div *ngFor=\"let item of advImages\" class=\"swiper-slide\">\r\n  <div >\r\n  <div class=\"item\">\r\n  <div class=\"item-inside item-inside-01\">\r\n  <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n  <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialInputs/fastGradientSignMethod/Results/{{item.className}}/original/{{item.image}}\">\r\n  </div>\r\n  <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n  <i class=\"fa fa-long-arrow-right\"></i>\r\n  </div>\r\n  <div class=\"item-inside item-inside-02\">\r\n  <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n  <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialInputs/fastGradientSignMethod/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n  </div>\r\n  </div>\r\n  </div>\r\n  </div>\r\n  </swiper>\r\n  </div>\r\n</div>\r\n<div class=\"details-back-btn\" (click)=\"showInitialFuncAdversarialInputs()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-10\" >\r\n<div class=\"innerpage-row-col row-col-left\">\r\n  <div class=\"row-col-header\">\r\n    <span>Adversarial Inputs</span>\r\n    <span class=\"row-col-header-sub\"> (Carlini and Wagner Method)</span>\r\n    <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"aiscw\" class=\"fa fa-cogs\"></i></a>\r\n  </div>\r\n  <div class=\"row-col-content\">\r\n   This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n  </div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"adversInpCW\">\r\n        Adversarial Inputs CW Information not Available.\r\n</div>\r\n<div *ngIf=\"!adversInpCW\">\r\n<div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableAdversarialInputsCW\">\r\n  <div class=\"row-col-initial-header\">% of Examples Classified by the Model Correctly</div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"initial-circle-wrap\" *ngFor=\"let rec of overallAdversarialInputsCWData\">\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsOriginalPrecision }} green\">\r\n        <span>{{ rec.overallMatricsOriginalPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Original</div>\r\n    </div>\r\n\r\n    <div class=\"initial-circle-content\">\r\n      <div class=\"c100 p{{ rec.overallMatricsPrecision }} {{ rec.overallMatricsDiff }}\">\r\n        <span>{{ rec.overallMatricsPrecision }}%</span>\r\n        <div class=\"slice\">\r\n          <div class=\"bar\"></div>\r\n          <div class=\"fill\"></div>\r\n        </div>\r\n      </div>\r\n      <div class=\"circle-header\">On Adversarial Inputs</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"circle-btn\" (click)=\"showDetailFuncAdversarialInputsCW()\">View Further Details</div>\r\n</div>\r\n</div>\r\n<div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableAdversarialInputsCW\">\r\n  <div class=\"row-col-matrix-content\">\r\n    <div class=\"col-right-table-wrap\">\r\n      <div class=\"col-right-table-header\">% of Examples Correctly Classified for each Class</div>\r\n      <div class=\"detailExample-wrap\">\r\n        <div class=\"detailExample-cont\" *ngFor=\"let rec of filterClassMatricsData_AdversarialInputsCW\">\r\n          <div class=\"detailExample-cont-className\" title=\"{{rec.className}}\" (click)=\"selectedClassItems_AdversarialInputsCW($event); adversarialInputsCWClassClick()\">{{rec.className}}</div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.originalExample}} small green\">\r\n              <span>{{ rec.originalExample }}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Original</div>\r\n          </div>\r\n          <div class=\"detailExample-cont-circle\">\r\n            <div class=\"c100 p{{rec.adversarialExample}} small {{ rec.diffRecall }}\">\r\n              <span>{{rec.adversarialExample}}%</span>\r\n              <div class=\"slice\">\r\n                <div class=\"bar\"></div>\r\n                <div class=\"fill\"></div>\r\n              </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-header\">On Adversarial Inputs</div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"innerpage-row-col row-col-mid\" *ngIf=\"showDetailTableAdversarialInputsCW\">\r\n  <div class=\"slider-txt-display\" *ngIf=\"adversarialInputsCWshowPara\">\r\n    <p>Click on Class Name to view the Example of each Class</p>\r\n  </div>\r\n  <div class=\"slider-wrap\" *ngIf=\"adversarialInputsCWshowSlider\">\r\n\r\n  <div class=\"carousel-wrapper\">\r\n    <swiper  [config]=\"config\" [(index)]=\"index10\" [disabled]=\"disabled\"\r\n    (indexChange)=\"onIndexChange($event)\" (swiperTransitionStart)=\"onSwiperEvent('transitionStart')\" (swiperTransitionEnd)=\"onSwiperEvent('transitionEnd')\">\r\n    <div *ngFor=\"let item of adversarialInputsCWImages\" class=\"swiper-slide\" >\r\n    <div>\r\n    <div class=\"item\">\r\n    <div class=\"item-inside item-inside-01\">\r\n    <p title=\"Original Image Classified as - {{item.orgName}}\">Original Image Classified as - {{item.orgName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialInputs/carliniWagnerMethod/Results/{{item.className}}/original/{{item.image}}\">\r\n    </div>\r\n    <div class=\"col-mid-img-cont-wrap col-mid-mid\">\r\n    <i class=\"fa fa-long-arrow-right\"></i>\r\n    </div>\r\n    <div class=\"item-inside item-inside-02\">\r\n    <p title=\"Perturbed Image Classified as - {{item.perName}}\">Perturbed Image Classified as - {{item.perName}}</p>\r\n    <img src=\"./assets/results/{{ projectName }}/Robustness/AdversarialInputs/carliniWagnerMethod/Results/{{item.className}}/perturbed/{{item.image}}\">\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </div>\r\n    </swiper>\r\n    </div>\r\n  </div>\r\n  <div class=\"details-back-btn\" (click)=\"showInitialFuncAdversarialInputsCW()\">View Overall Metrics.</div>\r\n</div>\r\n\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n</div>\r\n</ng-template>\r\n</mat-tab>\r\n<!-- <mat-tab label=\"Discrimination\">\r\n\r\n<div class=\"container\">\r\n\r\n</div>\r\n\r\n</mat-tab> -->\r\n\r\n<mat-tab label=\"Interpretability\">\r\n<ng-template matTabContent>\r\n\r\n<div class=\"lime-setting-probablitychange-wrap\" *ngIf=\"interPret\">\r\n        <b>Interpretability Information not Available.</b>\r\n</div>\r\n\r\n<div class=\"innerpage-wrap\" *ngIf=\"!interPret\">\r\n<div class=\"ip-row\">\r\n<div class=\"ip-filter-wrap\">\r\n  <div><button [ngClass]=\"{'active': activateAll}\" (click)=\"myMethod($event)\" id=\"overall\" name=\"overall\">Show All</button></div>\r\n  <div><button [ngClass]=\"{'active': activateMisclassified}\" (click)=\"myMethod($event)\" id=\"wrongly_classified\" name=\"wrongly classified\">Misclassified with High Probability</button></div>\r\n  <div><button [ngClass]=\"{'active': activateClassified}\" (click)=\"myMethod($event)\" id=\"Correctly_classified\" name=\"Correctly classified\">Correctly Classified with Low Probability</button></div>\r\n  <div><button [ngClass]=\"{'active': activateCorrectHighProbablity}\" (click)=\"myMethod($event)\" id=\"Correctly_classified_High_Probablity\" name=\"Correctly classified\">Correctly Classified with High Probability</button></div>\r\n</div>\r\n\r\n<!-- <div class=\"ip-header\">Results</div> -->\r\n<div class=\"ip-setting-btn-wrap\">\r\n<a> <i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"ipt\" class=\"fa fa-cogs\"> </i></a>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n\r\n<div class=\"lime-setting-probablitychange-wrap\">\r\n  <form name=\"pform\" #pf=\"ngForm\" novalidate>\r\n  <div class=\"lspcw-01\" *ngIf=\"overallExplanation\">Misclassified samples are shown first and then cascaded with correctly classifed samples as per the descending order of probability of top most prediction.</div>\r\n  <div class=\"lspcw-01\" *ngIf=\"misclassifiedwithHighProbablityExplanation\">By default, results are shown where the probability of top most prediction is > 0.5 </div>\r\n  <div class=\"lspcw-01\" *ngIf=\"correctlyClassifiedwithHighProbablityExplanation\">By default, results are shown where the probability of top most prediction is < 0.5 </div>\r\n  <div class=\"lspcw-01\" *ngIf=\"classifiedwithHighProbablityExplanation\">By default, results are shown where the probability of top most prediction is > 0.5 </div>\r\n</form>\r\n  <div class=\"lspcw-02\" *ngIf=\"overallExplanation || correctlyClassifiedwithHighProbablityExplanation\">Input a probability value where you want to see the results less than that value<input name=\"probablityValue1\" [(ngModel)]=\"pmodel.probablitylcValue\" #probablityValue=\"ngModel\" (keyup)=\"plcKeyPress($event)\">  <button (click)=\"onplcSubmit()\">Submit</button></div>\r\n  <div class=\"lspcw-03\" *ngIf=\"overallExplanation || misclassifiedwithHighProbablityExplanation || classifiedwithHighProbablityExplanation\">Input a probability value where you want to see the results greater than that value<input name=\"probablityValue2\" [(ngModel)]=\"pmodel.probablitygcValue\" #probablityValue=\"ngModel\" (keyup)=\"pgcKeyPress($event)\">  <button (click)=\"onpgcSubmit()\">Submit</button></div>\r\n  <div class=\"clearfix\"></div>\r\n\r\n  <div class=\"lspcw-04\">Number of images in Sample Set</div>\r\n  <div class=\"lspcw-05\"><input type=\"number\" id=\"sampleId1\" name=\"sampleData1\" [ngModel]=\"restrictImageDisplay\" #sampleData1=\"ngModel\" (keyup)=\"applyFilter1($event)\">\r\n    <button (click)=\"setSampleData_1(sampleData1)\">Submit</button>\r\n    <p *ngIf=\"err1\">The value must be in range of 1-50</p></div>\r\n  <div class=\"lspcw-06\"><input type=\"number\" id=\"sampleId2\" name=\"sampleData2\" [ngModel]=\"restrictImageDisplay1\" #sampleData2=\"ngModel\" (keyup)=\"applyFilter2($event)\">\r\n    <button (click)=\"setSampleData_2(sampleData2)\">Submit</button>\r\n    <p *ngIf=\"err2\">The value must be in range of 1-50</p></div>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n</div>\r\n\r\n\r\n<div class=\"list emptylist\" *ngIf=\"blankFlag\">No Images to be displayed</div>\r\n\r\n<div class=\"list\" *ngIf=\"!blankFlag && overal_LimeCsvData.length > 0\">\r\n\t\t<ul>\r\n\t\t\t<li *ngFor=\"let glRec of limeCsvData | paginate: { itemsPerPage: 10, currentPage: page }; let Mindex=index\">\r\n          <div class=\"ip-result-wrap\">\r\n            <div class=\"limeResult-followup-wrap form-group\">\r\n              <div class=\"comment-icon-wrap\" [ngClass]=\"{'active': glRec.isSelected == 'True'}\"><i class=\"fa fa-thumb-tack\"></i></div>\r\n              <div class=\"comment-icon-wrap-alt\" [ngClass]=\"{'active': glRec.comments !=''}\"><i class=\"fa fa-comments-o\"></i></div>\r\n              <label class=\"checkbox_wrap\">\r\n                <input class=\"checkbox\" type=\"checkbox\" name=\"followUpLime\"  (click)=\"followUpSelect($event, Mindex)\">\r\n                <span class=\"checkmark\"></span>\r\n              </label>\r\n            </div>\r\n              <div class=\"ip-result-col-left\">\r\n                <span>Original</span>\r\n                <div class=\"ip-result-col-left-01\">\r\n                  <img src=\"./assets/results/{{ projectName }}/Interpretability/Results/{{ glRec.limeOriginalClassName }}/{{ glRec.limeImgFolder }}/{{ glRec.limeOriginalImage }}\">\r\n                  <p>Class - {{ glRec.limeOriginalClassName }}</p>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"ip-result-col-right\">\r\n                <span>Explaining an Original Image on Top 2 Prediction </span>\r\n                <div class=\"ip-result-col-right-01\" *ngFor=\"let rec of glRec.predictions; let myIndex=index\">\r\n                  <img src=\"./assets/results/{{ projectName }}/Interpretability/Results/{{ glRec.limeOriginalClassName }}/{{ glRec.limeImgFolder }}/{{glRec.explaination[myIndex]}}\">\r\n                  <p>Explaining {{ glRec.predictions[myIndex] }} ({{ glRec.probablity[myIndex] }})</p>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"ip-result-col-right-alt\">\r\n                <span>Samples from Test Data </span>\r\n                <div class=\"ip-result-col-right-alt-01\">\r\n                  <main>\r\n                    <div class=\"showcase\">\r\n                    <div class=\"content horizontal-images\" id=\"imageNetScroll-01\">\r\n                        <img *ngFor=\"let rec of imageNetLimeCsvData[glRec.limeOriginalClassName] | slice:0:restrictImageDisplay; let myIIndex=index\" src=\"assets/results/{{ projectName }}/Interpretability/Results/{{imageNetLimeCsvData[glRec.limeOriginalClassName][myIIndex]}}\"/>\r\n              \t\t\t</div>\r\n                    <p>Samples of {{ glRec.limeOriginalClassName }}</p>\r\n                  </div>\r\n                </main>\r\n                </div>\r\n\r\n                <div class=\"ip-result-col-right-alt-02\" >\r\n                  <main>\r\n                    <div class=\"showcase\" *ngIf=\"glRec.predictions[0] == glRec.limeOriginalClassName && glRec.predictions[1] != glRec.limeOriginalClassName\">\r\n                    <div  class=\"content horizontal-images\" id=\"imageNetScroll-02\">\r\n                      <img  *ngFor=\"let rec of imageNetLimeCsvData[glRec.predictions[1]] | slice:0:restrictImageDisplay1; let myIIndex=index\" src=\"assets/results/{{ projectName }}/Interpretability/Results/{{imageNetLimeCsvData[glRec.predictions[1]][myIIndex]}}\"/>\r\n              \t\t\t</div>\r\n                    <p>Samples of {{ glRec.predictions[1] }}</p>\r\n                  </div>\r\n\r\n                  <div class=\"showcase\" *ngIf=\"glRec.predictions[0] != glRec.limeOriginalClassName\">\r\n                  <div  class=\"content horizontal-images\" id=\"imageNetScroll-02\">\r\n                    <img  *ngFor=\"let rec of imageNetLimeCsvData[glRec.predictions[0]] | slice:0:restrictImageDisplay1; let myIIndex=index\" src=\"assets/results/{{ projectName }}/Interpretability/Results/{{imageNetLimeCsvData[glRec.predictions[0]][myIIndex]}}\"/>\r\n                  </div>\r\n                  <p>Samples of {{ glRec.predictions[0] }}</p>\r\n                </div>\r\n                </main>\r\n                </div>\r\n              </div>\r\n              <div class=\"clearfix\"></div>\r\n              <!-- <div class=\"google-search-wrap\">\r\n                <a href=\"h<img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />\r\n                <img src=\"assets/results/Interpretability/Results/imagenet/img2.jpg\" />ttps://www.google.com/search?tbm=isch&q={{ glRec.classNameToSearch }}\" target=\"_blank\">Search why {{ glRec.classNameToSearch }} misclassified as {{glRec.firstPrediction}} in Google</a>\r\n              </div> -->\r\n              <div class=\"commentbox-wrap\" >\r\n                <span>Comments</span>\r\n                <form name=\"cform\" #cf=\"ngForm\" novalidate (ngSubmit)=\"oncSubmit(Mindex, page)\">\r\n                <textarea name=\"commentValue\" [(ngModel)]=\"cmodel.commentValue[10 * (page - 1) + Mindex].comments\" #commentValue=\"ngModel\" required (input)=\"clearError()\"></textarea>\r\n                <p *ngIf=\"10 * (page - 1) + Mindex==textIndex\">{{ thankyouMsg }}</p>\r\n                <div class=\"comment-submit-wrap\"><button (click)=\"setSample(commentValue)\">Submit</button></div>\r\n                </form>\r\n              </div>\r\n              <div class=\"clearfix\"></div>\r\n          </div>\r\n      </li>\r\n\t\t</ul>\r\n\r\n\t\t<pagination-controls (pageChange)=\"page = $event\" (click)=\"pageChanged($event)\"></pagination-controls>\r\n</div>\r\n\r\n<!--<div class=\"ip-row\">\r\n <div class=\"ip-result-wrap\" *ngFor=\"let glRec of limeCsvData\">\r\n  <div class=\"ip-result-col-left\">\r\n    <span>Original</span>\r\n    <div class=\"ip-result-col-left-01\">\r\n      <img src=\"./assets/results/Interpretability/Results/{{ glRec.limeOriginalClassName }}/{{ glRec.limeImgFolder }}/{{ glRec.limeOriginalImage }}\">\r\n      <p>Class - {{ glRec.limeOriginalClassName }}</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"ip-result-col-right\">\r\n    <span>Explaining an Original Image on Top 3 Prediction </span>\r\n    <div class=\"ip-result-col-right-01\" *ngFor=\"let rec of glRec.explaination; let myIndex=index\">\r\n      <img src=\"./assets/results/Interpretability/Results/{{ glRec.limeOriginalClassName }}/{{ glRec.limeImgFolder }}/{{glRec.explaination[myIndex]}}\">\r\n      <p>Explaining {{ glRec.predictions[myIndex] }} ({{ glRec.probablity[myIndex] }})</p>\r\n    </div>\r\n\r\n  </div>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n</div>-->\r\n\r\n</div>\r\n</ng-template>\r\n</mat-tab>\r\n\r\n</mat-tab-group>\r\n\r\n\r\n</div>\r\n\r\n</mat-drawer-container>\r\n\r\n</div>\r\n\r\n<!-- <app-image-classifier-main-settings [(visible)]=\"showMainSetting\" (imageClassifierSettingsValue)=\"imageClassifierSettingsValue($event)\"></app-image-classifier-main-settings> -->\r\n<app-adversarial-inputs-settings [(visible)]=\"adversarialSetting\" [AdvSettings]=\"settingDict\"></app-adversarial-inputs-settings>\r\n<app-interpretability-settings [(visible)]=\"interpretabilitySetting\" (interpretabilitySettingsValue)=\"interpretabilitySettingsValue($event)\"></app-interpretability-settings>\r\n<app-comparison-graph [(visible)]=\"comparisonGraph\" (comparisonGraphValue)=\"comparisonGraphValue($event)\" *ngIf=\"show\" [chartData]=\"listitem\"></app-comparison-graph>\r\n<app-performance-graph [(visible)]=\"performanceGraph\" (performanceGraphValue)=\"performancenGraphValue($event)\" *ngIf=\"show2\" [chartMIData]=\"chartMiData\" [chartLOData]=\"chartLoData\" [chartMILabels]=\"chartMiLabels\" [performPNmae]=\"performPNmae\" [detailedinfoCSVlink]=\"detailedinfoCSVlink\"></app-performance-graph>\r\n<app-performance-comparison-graph [(visible)]=\"performanceComparisonGraph\" (performanceComparisonGraphValue)=\"performanceComparisonGraphValue($event)\" *ngIf=\"showMInfer\" [mInferData]=\"mInferData\" [mInferLabel]=\"mInferLabel\"></app-performance-comparison-graph>\r\n"

/***/ }),

/***/ "./src/app/image-classifier/image-classifier.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/image-classifier/image-classifier.component.ts ***!
  \****************************************************************/
/*! exports provided: ImageClassifierComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageClassifierComponent", function() { return ImageClassifierComponent; });
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _services_project_creation_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../_services/project-creation.service */ "./src/app/_services/project-creation.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-swiper-wrapper */ "./node_modules/ngx-swiper-wrapper/dist/ngx-swiper-wrapper.es5.js");
/* harmony import */ var ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-malihu-scrollbar */ "./node_modules/ngx-malihu-scrollbar/fesm5/ngx-malihu-scrollbar.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var ImageClassifierComponent = /** @class */ (function () {
    // [{
    //   label: 'InceptionV3',
    //   data: [0, 0, 0, 0, 0, 0, 0, 0]
    // },
    // {
    //   label: 'TrafficSign',
    //   data: [85, 25, 77, 69, 77, 46, 35, 71]
    // },
    // {
    //   label: 'Resnet',
    //   data: [58, 37, 47, 48, 52, 8, 18, 0]
    // }];
    // scrollbarOptions = { axis: 'x', theme: 'dark', scrollButtons:{enable:true}, autoExpandScrollbar:true, advanced:{ autoExpandHorizontalScroll: true }};
    // scrollbarOptions = { axis: 'x', theme: 'dark', scrollButtons:{enable:true}, autoExpandScrollbar:true, advanced:{ autoExpandHorizontalScroll: true }};
    // addSlide() {
    //   this.items.push({
    //     title: `Slide 4`,
    //     titlealt: `Slide 4 alt`,
    //   });
    // }
    // doSomething($event){
    //   console.log($event+" SLider reset");
    // }
    //collection = [];
    function ImageClassifierComponent(cdRef, projectServe, http2, http, elRef, mScrollbarService) {
        this.cdRef = cdRef;
        this.projectServe = projectServe;
        this.http2 = http2;
        this.http = http;
        this.elRef = elRef;
        this.mScrollbarService = mScrollbarService;
        // formdata = new FormGroup({
        //   txtInput: new FormControl(""),
        //   uploadTxtFile: new FormControl("")
        // });
        // private modelDataPath: any = 'Path to Model Data';
        // private testDataPath: any = 'Path to Test Data';
        // private showPara: boolean = true;
        // private showSlider: boolean = false;
        this.rotationtranslationshowPara = true;
        this.rotationtranslationshowSlider = false;
        this.fourierfilteringshowPara = true;
        this.fourierfilteringshowSlider = false;
        this.grayscaleshowPara = true;
        this.grayscaleshowSlider = false;
        this.contrastshowPara = true;
        this.contrastshowSlider = false;
        this.additivenoiseshowPara = true;
        this.additivenoiseshowSlider = false;
        this.eidolonnoiseshowPara = true;
        this.eidolonnoiseshowSlider = false;
        this.modelcomplexityshowPara = true;
        this.modelcomplexityshowSlider = false;
        this.adversarialInputsshowPara = true;
        this.adversarialInputsshowSlider = false;
        this.adversarialpatchesshowPara = true;
        this.adversarialpatchesshowSlider = false;
        this.adversarialInputsCWshowPara = true;
        this.adversarialInputsCWshowSlider = false;
        //private showLoader: boolean = false;
        this.showInitialTableRotationTranslation = true;
        this.showDetailTableRotationTranslation = false;
        this.showInitialTableFourierFiltering = true;
        this.showDetailTableFourierFiltering = false;
        this.showInitialTableGrayScale = true;
        this.showDetailTableGrayScale = false;
        this.showInitialTableContrast = true;
        this.showDetailTableContrast = false;
        this.showInitialTableAdditiveNoise = true;
        this.showDetailTableAdditiveNoise = false;
        this.showInitialTableEidolonNoise = true;
        this.showDetailTableEidolonNoise = false;
        this.showInitialTableModelComplexity = true;
        this.showDetailTableModelComplexity = false;
        this.showInitialTableAdversarialInputs = true;
        this.showDetailTableAdversarialInputs = false;
        this.showInitialTableAdversarialInputsCW = true;
        this.showDetailTableAdversarialInputsCW = false;
        this.showInitialTableAdversarialPatches = true;
        this.showDetailTableAdversarialPatches = false;
        this.adversarialpatchesshowPatch = false;
        this.showViewPatch = false;
        this.showHidePatch = false;
        this.showCommentBox = false;
        this.tcomm = "";
        this.thankyouMsg = "";
        this.items = [];
        this.index1 = 0;
        this.index2 = 0;
        this.index3 = 0;
        this.index4 = 0;
        this.index5 = 0;
        this.index6 = 0;
        this.index7 = 0;
        this.index8 = 0;
        this.index9 = 0;
        this.index10 = 0;
        this.mIndex = 0;
        this.sIndex = 1;
        this.compareData = [];
        this.compareData2 = [];
        this.nameListToCompare = [];
        this.projectList = [''];
        this.projectListForPerformance = [''];
        this.listitem = [];
        //private mInferlabel = []
        this.mInferData = [];
        this.mInferLabel = [];
        this.chartLoData = [];
        this.chartMiData = [];
        this.chartMiLabels = [];
        this.show = false;
        this.show2 = false;
        this.showMInfer = false;
        this.selectedActiveIndex = 0;
        this.count = 0;
        this.count2 = 0;
        this.compareEnable = true;
        this.compareEnable2 = true;
        this.performanceCsvUrl = './assets/results/';
        this.advImages = [];
        this.objectRecRotationTranslationImages = [];
        // rotationtranslationClassTextName:any[] = [];
        // rotationtranslationClassText:any;
        // rotationDegree:any;
        // translationPixel:any;
        this.fourierFilteredImages = [];
        this.objectRecGrayScaleImages = [];
        this.objectRecContrastImages = [];
        this.objectRecAdditiveNoiseImages = [];
        this.objectRecEidolonNoiseImages = [];
        this.objectRecModelComplexityImages = [];
        this.adversarialPatchesImages = [];
        this.adversarialInputsCWImages = [];
        //Array holds the json record related to the clicked class from csvImgData_Obj_GrayScale
        // see the selectedClassItems function how it is filtering the information
        this.csvImgData_Adversarial = [];
        this.csvImgData_Obj_RotationTranslation = [];
        this.csvImgData_FourierFiltering = [];
        this.csvImgData_Obj_GrayScale = [];
        this.csvImgData_Obj_Contrast = [];
        this.csvImgData_Obj_AdditiveNoise = [];
        this.csvImgData_Obj_EidolonNoise = [];
        this.csvImgData_Obj_ModelComplexity = [];
        this.csvImgData_AdversarialPatches = [];
        this.csvImgData_AdversarialInputsCW = [];
        //Array contains information from output csv used in imageDisplay function
        //which is later used to filter the clicked class information to display in slider
        //just a representation of all output csv data as an array for later use
        // see the imageDisplay function
        this.limeCsvData = [];
        this.imageNetLimeCsvData = [];
        this.overal_LimeCsvData = [];
        this.updateLimeCsv = [];
        this.filterClassMatricsData_Adv = [];
        this.filterClassMatricsData_Obj_RotationTranslation = [];
        this.filterClassMatricsData_Fourier = [];
        this.filterClassMatricsData_Obj_GrayScale = []; //Array Contains class level information used in processClassMatrics function
        this.filterClassMatricsData_Obj_Contrast = [];
        this.filterClassMatricsData_Obj_AdditiveNoise = [];
        this.filterClassMatricsData_Obj_EidolonNoise = [];
        this.filterClassMatricsData_Obj_ModelComplexity = [];
        this.filterClassMatricsData_AdversarialPatches = [];
        this.filterClassMatricsData_AdversarialInputsCW = [];
        this.overallFourierRadialFilteringData = [];
        // (overallObjRecGrayScaleData is an array) To display overall % used in readoverallMatricsCsvData function
        this.overallObjRecGrayScaleData = [];
        this.overallAdversarialData = [];
        this.overallObjRecRotationTranslationData = [];
        this.overallFourierData = [];
        this.overallObjRecContrastData = [];
        this.overallObjRecAdditiveNoiseData = [];
        this.overallObjRecEidolonNoiseData = [];
        this.overallObjRecModelComplexityData = [];
        this.overallAdversarialPatchesData = [];
        this.overallAdversarialInputsCWData = [];
        this.experimentsRancsvData = [];
        this.adversarialtSettingsHeader = [];
        this.setFlag = false;
        this.adversarialSettingValues = [];
        this.adversarialSettingLabels = [];
        this.interpretabilitySettingscsvData = [];
        this.settingDict = {};
        this.page = 1;
        // private icValue: any;
        this.ipValue = {};
        //private interpretabilitySetting: any;
        this.activateAll = true;
        this.activateMisclassified = false;
        this.activateClassified = false;
        this.activateCorrectHighProbablity = false;
        this.blankFlag = false;
        this.min = 10;
        this.max = 50;
        this.model = { generalizaionValue: false, rotationtranslationValue: false, fourierfilteringValue: false, colortograyscaleValue: false, contrastValue: false, additivenoiseValue: false, eidolonnoiseValue: false, modelcomplexityValue: false, robustnessValue: false, adversarialPatchesValue: false, fastGradientSignMethod: false, carliniWagnerMethod: false, discriminationValue: false, explainabilityValue: false };
        this.pmodel = { probablitylcValue: 0.5, probablitygcValue: 0.5 };
        this.cmodel = { commentValue: '' };
        this.spmodel = { projectname: this.projectName };
        this.spPerformanceModel = { projectname: this.performanceProjectName };
        this.restrictImageDisplay1 = 10;
        this.restrictImageDisplay = 10;
        // private err_msg1 = ''
        // private err_msg2 = ''
        this.err1 = false;
        this.err2 = false;
        this.rotNtrans = false;
        this.fourierFilter = false;
        this.objRecGrayScale = false;
        this.objLowContrast = false;
        this.objAddNoise = false;
        this.objEdNoise = false;
        this.adversInp = false;
        this.adversInpCW = false;
        this.advPatches = false;
        this.interPret = false;
        this.showFiller = false;
        this.type = 'component';
        this.disabled = false;
        this.config = {
            a11y: true,
            direction: 'horizontal',
            slidesPerView: 1,
            keyboard: true,
            mousewheel: true,
            scrollbar: false,
            navigation: true,
            pagination: false
        };
        elRef.nativeElement.ownerDocument.body.style.overflowY = 'scroll';
        // for (let i = 1; i <= 100; i++) {
        //   this.collection.push(`item ${i}`);
        // }
    }
    ImageClassifierComponent.prototype.resetToStart = function () {
        var _this = this;
        this.showInitialFuncRotationTranslation();
        this.showInitialFuncFourierFiltering();
        this.showInitialFuncGrayScale();
        this.showInitialFuncContrast();
        this.showInitialFuncAdditiveNoise();
        this.showInitialFuncEidolonNoise();
        this.showInitialFuncModelComplexity();
        this.showInitialFuncAdversarialInputs();
        this.showInitialFuncAdversarialPatches();
        this.rotationtranslationshowPara = true;
        this.rotationtranslationshowSlider = false;
        this.fourierfilteringshowPara = true;
        this.fourierfilteringshowSlider = false;
        this.grayscaleshowPara = true;
        this.grayscaleshowSlider = false;
        this.contrastshowPara = true;
        this.contrastshowSlider = false;
        this.additivenoiseshowPara = true;
        this.additivenoiseshowSlider = false;
        this.eidolonnoiseshowPara = true;
        this.eidolonnoiseshowSlider = false;
        this.modelcomplexityshowPara = true;
        this.modelcomplexityshowSlider = false;
        this.adversarialInputsshowPara = true;
        this.adversarialInputsshowSlider = false;
        this.adversarialpatchesshowPara = true;
        this.adversarialpatchesshowSlider = false;
        this.adversarialInputsCWshowPara = true;
        this.adversarialInputsCWshowSlider = false;
        //console.log("Got the overall")
        this.allClassifiedClasses(this.overal_LimeCsvData);
        this.correctlyClassifiedwithHighProbablityExplanation = this.misclassifiedwithHighProbablityExplanation = this.classifiedwithHighProbablityExplanation = false;
        this.thankyouMsg = '';
        this.page = 1;
        this.overallExplanation = true;
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
    };
    ImageClassifierComponent.prototype.listProjects = function () {
        var _this = this;
        this.http.get('http://localhost:5000/projectDirs/imageClassifier')
            .subscribe(function (resp) {
            _this.projectList = JSON.parse(resp['_body']);
            _this.projectListForPerformance = _this.projectList;
            if (_this.projectList.length > 0) {
                _this.loadLatestProject();
            }
            else {
                _this.loadInception();
            }
            // console.log(this.projectList);
        }, function (err) { return console.log('some error occuresd in file uploading'); });
    };
    ImageClassifierComponent.prototype.loadInception = function () {
        this.projectName = 'Benchmark/InceptionV3';
        this.fileNames();
        this.loadAllCSVDataFunc();
        this.compareData.push({ name: 'InceptionV3', selected: false }, { name: 'TrafficSign', selected: false }, { name: 'ResNet', selected: false }, { name: 'DenseNet', selected: false });
        this.compareData2.push({ name: 'InceptionV3', selected: false }, { name: 'TrafficSign', selected: false }, { name: 'ResNet', selected: false }, { name: 'DenseNet', selected: false });
        this.projectNameChangeForPerformance('Benchmark/InceptionV3');
    };
    ImageClassifierComponent.prototype.loadLatestProject = function () {
        var _this = this;
        //this.compareData=[]
        if (this.projectList) {
            this.projectList.forEach(function (item) {
                _this.compareData.push({ name: item, selected: false });
                _this.compareData2.push({ name: item, selected: false });
            });
            this.compareData.push({ name: 'InceptionV3', selected: false }, { name: 'TrafficSign', selected: false }, { name: 'ResNet', selected: false }, { name: 'DenseNet', selected: false });
            this.compareData2.push({ name: 'InceptionV3', selected: false }, { name: 'TrafficSign', selected: false }, { name: 'ResNet', selected: false }, { name: 'DenseNet', selected: false });
            this.projectNameChange(this.projectList[0]);
            this.projectNameChangeForPerformance(this.projectList[0]);
        }
    };
    ImageClassifierComponent.prototype.prepareGraph = function () {
        var _this = this;
        this.nameListToCompare = [];
        var name = '';
        var benchMark = ['DenseNet', 'TrafficSign', 'InceptionV3', 'ResNet'];
        this.compareData.forEach(function (item) {
            if (item.checked) {
                _this.nameListToCompare.push(item.name);
            }
        });
        if (this.nameListToCompare.length > 0) {
            this.getChartData(this.nameListToCompare);
        }
    };
    ImageClassifierComponent.prototype.prepareGraphMInfer = function () {
        var _this = this;
        this.nameListToCompare = [];
        var name = '';
        var benchMark = ['DenseNet', 'TrafficSign', 'InceptionV3', 'ResNet'];
        this.compareData2.forEach(function (item) {
            if (item.checked) {
                _this.nameListToCompare.push(item.name);
            }
        });
        if (this.nameListToCompare.length > 0) {
            this.getChartDataMInfer(this.nameListToCompare);
        }
    };
    ImageClassifierComponent.prototype.getChartData = function (nameList) {
        return __awaiter(this, void 0, void 0, function () {
            var url, pName, onPerturbed, record, onOriginal, benchMark, innerPath, i, j, resp;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.listitem = [];
                        this.show = false;
                        pName = '';
                        onPerturbed = [];
                        onOriginal = [];
                        benchMark = ['DenseNet', 'TrafficSign', 'InceptionV3', 'ResNet'];
                        innerPath = ['/Generalization/RotationNTranslation/Results/overallmetrics.csv',
                            '/Generalization/FourierRadialFiltering/Results/overallmetrics.csv',
                            '/Generalization/Object_Recognition/GrayScale/Results/overallmetrics.csv',
                            '/Generalization/Object_Recognition/LowContrast/Results/overallmetrics.csv',
                            '/Generalization/Object_Recognition/Noisy/Results/overallmetrics.csv',
                            '/Generalization/Object_Recognition/Eidolon/Results/overallmetrics.csv',
                            '/Robustness/AdversarialPatches/Results/overallmetrics.csv',
                            '/Robustness/AdversarialInputs/fastGradientSignMethod/Results/overallmetrics.csv',
                            '/Robustness/AdversarialInputs/carliniWagnerMethod/Results/overallmetrics.csv',
                        ];
                        i = 0;
                        _a.label = 1;
                    case 1:
                        if (!(i < nameList.length)) return [3 /*break*/, 7];
                        if (benchMark.indexOf(nameList[i]) == -1) {
                            pName = nameList[i];
                        }
                        else {
                            pName = 'Benchmark/' + nameList[i];
                        }
                        j = 0;
                        _a.label = 2;
                    case 2:
                        if (!(j < innerPath.length)) return [3 /*break*/, 5];
                        url = './assets/results/' + pName + innerPath[j];
                        return [4 /*yield*/, this.projectServe.getHttpResponse(url)];
                    case 3:
                        resp = _a.sent();
                        if (resp !== 'error') {
                            record = resp.split(/\r\n|\n/)[1].split(',');
                            onPerturbed.push(Math.round((Math.round((record[2] * 1 + 0.00001) * 100) / 100) * 100));
                            onOriginal[0] = Math.round((Math.round((record[1] * 1 + 0.00001) * 100) / 100) * 100);
                        }
                        else {
                            onPerturbed.push(0);
                            if (onOriginal.length == 0) {
                                onOriginal[0] = 0;
                            }
                        }
                        _a.label = 4;
                    case 4:
                        j++;
                        return [3 /*break*/, 2];
                    case 5:
                        onPerturbed = onOriginal.concat(onPerturbed);
                        this.listitem.push({ data: onPerturbed, label: nameList[i] });
                        onPerturbed = [];
                        onOriginal = [];
                        _a.label = 6;
                    case 6:
                        i++;
                        return [3 /*break*/, 1];
                    case 7:
                        // console.log("output ---- ",this.listitem)
                        // this.graphList = this.listitem
                        this.show = true;
                        return [2 /*return*/];
                }
            });
        });
    };
    ImageClassifierComponent.prototype.getChartDataMInfer = function (nameList) {
        return __awaiter(this, void 0, void 0, function () {
            var url, pName, record, benchMark, i, resp;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.listitem = [];
                        this.showMInfer = false;
                        pName = '';
                        this.mInferData = [];
                        this.mInferLabel = [];
                        benchMark = ['DenseNet', 'TrafficSign', 'InceptionV3', 'ResNet'];
                        i = 0;
                        _a.label = 1;
                    case 1:
                        if (!(i < nameList.length)) return [3 /*break*/, 4];
                        if (benchMark.indexOf(nameList[i]) == -1) {
                            pName = nameList[i];
                        }
                        else {
                            pName = 'Benchmark/' + nameList[i];
                        }
                        url = './assets/results/' + pName + '/Performance/model_inference.csv';
                        return [4 /*yield*/, this.projectServe.getHttpResponse(url)];
                    case 2:
                        resp = _a.sent();
                        if (resp !== 'error') {
                            //record = resp.split(/\r\n|\n/)[1].split(',')
                            //this.mInferLabel = resp.split(/\r\n|\n/)[0].split(',')
                            //mData = {data: resp.split(/\r\n|\n/)[0].split(','), label: nameList[i]}
                            this.mInferData.push({ data: resp.split(/\r\n|\n/)[1].split(',').map(function (i) { return Number(Number(i).toFixed(4)); }), label: nameList[i] });
                            //console.log("original --- ",resp.split(/\r\n|\n/)[1].split(',').map(i => Number(Number(i).toFixed(3))))
                            this.mInferLabel = resp.split('\n')[0].split(',');
                            // onPerturbed.push(Math.round((Math.round((record[2] * 1 + 0.00001) * 100) / 100) * 100))
                            // onOriginal[0] = Math.round((Math.round((record[1] * 1 + 0.00001) * 100) / 100) * 100)
                        }
                        else {
                            // onPerturbed.push(0)
                            // if(onOriginal.length==0){
                            //   onOriginal[0] = 0
                            //}
                            console.log("No model inference info available");
                        }
                        _a.label = 3;
                    case 3:
                        i++;
                        return [3 /*break*/, 1];
                    case 4:
                        // console.log("output ---- ",this.listitem)
                        // this.graphList = this.listitem
                        //this.mInferData = this.transpose(this.mInferData)
                        //this.mInferLabel = nameList
                        this.showMInfer = true;
                        return [2 /*return*/];
                }
            });
        });
    };
    ImageClassifierComponent.prototype.transpose = function (a) {
        return Object.keys(a[0]).map(function (c) {
            return a.map(function (r) { return r[c]; });
        });
    };
    ImageClassifierComponent.prototype.getChartDataVal = function (chartData) {
        chartData = this.listitem;
    };
    ImageClassifierComponent.prototype.requestDataFromMultipleSources = function (pName) {
        return this.http.get(pName);
        // Observable.forkJoin (RxJS 5) changes to just forkJoin() in RxJS 6
    };
    ImageClassifierComponent.prototype.projectNameChange = function ($event) {
        //this.hideAdversarialPatches();
        this.projectName = $event;
        this.projectNameDisplay = $event.replace('Benchmark/', '');
        // switch($event){
        //   case 'InceptionV3':{ this.projectName = 'Benchmark/' + this.projectName; break;}
        //   case 'TrafficSign':{ this.projectName = 'Benchmark/' + this.projectName; break;}
        //   case 'ResNet':{ this.projectName = 'Benchmark/' + this.projectName; break;}
        //   case 'DenseNet':{ this.projectName = 'Benchmark/' + this.projectName; break;}
        // }
        //console.log(this.projectName);
        this.fileNames();
        this.loadAllCSVDataFunc();
        //this.resetToStart();
        //this.setToDefaultAll()
        this.setDefaultLime();
        //this.forceScrollUpdate(null)
        this.selectedActiveIndex += 1;
        if (this.selectedActiveIndex >= 1)
            this.selectedActiveIndex = 0;
        // this.selectedActiveIndex = 0;
    };
    ImageClassifierComponent.prototype.projectNameChangeForPerformance = function ($event) {
        var _this = this;
        this.performanceProjectName = $event;
        this.show2 = false;
        //console.log("performanceProjectName --- ",this.performanceProjectName)
        var layersAbsUrl = this.performanceCsvUrl + this.performanceProjectName + '/Performance/layers_output_tokened.csv';
        var modelInferenceAbsUrl = this.performanceCsvUrl + this.performanceProjectName + '/Performance/model_inference.csv';
        this.detailedinfoCSVlink = this.performanceCsvUrl + this.performanceProjectName + '/Performance/layers_info_detailed.csv';
        this.http2.get(layersAbsUrl, { responseType: 'text' }).subscribe(function (res) {
            //console.log('res --- ',res)
            _this.http2.get(modelInferenceAbsUrl, { responseType: 'text' }).subscribe(function (resp) {
                _this.performanceFilter(res, resp, _this.performanceProjectName);
            }, function (error) {
                _this.chartMiData = [];
                _this.chartLoData = [];
                _this.performPNmae = _this.performanceProjectName.replace('Benchmark/', '');
                _this.show2 = true;
                console.log('inference csv is not found!!!');
            });
        }, function (err) {
            _this.chartLoData = [];
            _this.chartMiData = [];
            _this.performPNmae = _this.performanceProjectName.replace('Benchmark/', '');
            _this.show2 = true;
            console.log('layers output Not found!!!!');
        });
        //console.log("performance project name -- ",this.performanceProjectName);
    };
    ImageClassifierComponent.prototype.performanceFilter = function (layersOutput, inferenceOutput, pname) {
        var _this = this;
        this.chartLoData = [];
        this.chartMiData = [];
        this.chartMiLabels = [];
        this.performPNmae = '';
        var splitCData;
        var chartData = layersOutput.split(/\r\n/);
        var infOutput = inferenceOutput.split(/\r\n/);
        for (var j = 1; j < chartData.length; j++) {
            splitCData = chartData[j].split(',');
            // this.chartLOLabels.push(splitCData[0])
            // chartData.push(splitCData[1])
            // this.chartLOlabelsAfterChange.push(splitCData[0])
            // this.chartLODataAfterChange.push(splitCData[1])
            if (splitCData != '') {
                this.chartLoData.push({ name: splitCData[0], time: splitCData[1] });
            }
        }
        for (var j = 1; j < infOutput.length; j++) {
            if (infOutput[j]) {
                infOutput[j].split(',').forEach(function (element) {
                    //console.log("chartMiData -- ",Number(element).toFixed(4))
                    _this.chartMiData.push(Number(element).toFixed(4));
                });
            }
        }
        this.performPNmae = pname.replace('Benchmark/', '');
        this.chartMiLabels = infOutput[0].split(',');
        for (var i = 0; i < this.chartMiData.length; i++) {
            this.chartMiLabels[i] += ':' + this.chartMiData[i];
        }
        this.show2 = true;
        //console.log(this.chartLoData)
        //console.log(this.chartMiData)
    };
    ImageClassifierComponent.prototype.compareChanged = function ($event) {
        var _this = this;
        //console.log($event)
        this.count = 0;
        this.compareData.forEach(function (item) {
            if (item.checked) {
                _this.count = _this.count + 1;
                if (_this.count == 3) {
                    _this.compareEnable = false;
                    //console.log(this.count);
                }
                else {
                    _this.compareEnable = true;
                }
            }
        });
    };
    ImageClassifierComponent.prototype.compareChangedMInfer = function ($event) {
        var _this = this;
        //console.log($event)
        this.count2 = 0;
        this.compareData2.forEach(function (item) {
            if (item.checked) {
                _this.count2 = _this.count2 + 1;
                if (_this.count2 == 3) {
                    _this.compareEnable2 = false;
                    //console.log(this.count2);
                }
                else {
                    _this.compareEnable2 = true;
                }
            }
        });
    };
    ImageClassifierComponent.prototype.fileNames = function () {
        // tftRobCsvUrl: string = '/tft/assets/results/Robustness/AdversarialInputs/Results'
        // tftInterCsvUrl: string = '/tft/assets/results/Interpretability/Results'
        this.resultPath = './assets/results/' + this.projectName;
        this.tftRobPath = this.resultPath + '/Robustness';
        this.tftInterPath = this.resultPath + '/Interpretability';
        this.tftGenUrl = this.resultPath + '/Generalization';
        this.overallMatriCsUrlAdv = this.tftRobPath + '/AdversarialInputs/fastGradientSignMethod/Results/overallmetrics.csv';
        this.classMatriCsUrlAdv = this.tftRobPath + '/AdversarialInputs/fastGradientSignMethod/Results/classmetrics.csv'; // URL to web API
        this.outputCsvUrlAdv = this.tftRobPath + '/AdversarialInputs/fastGradientSignMethod/Results/output.csv';
        this.overallMatriCsUrl_Obj_RotationTranslation = this.tftGenUrl + '/RotationNTranslation/Results/overallmetrics.csv';
        this.classMatriCsUrl_Obj_RotationTranslation = this.tftGenUrl + '/RotationNTranslation/Results/classmetrics.csv';
        this.outputCsvUrl_Obj_RotationTranslation = this.tftGenUrl + '/RotationNTranslation/Results/output.csv';
        this.overallMatriCsUrlFourier = this.tftGenUrl + '/FourierRadialFiltering/Results/overallmetrics.csv';
        this.classMatriCsUrlFourier = this.tftGenUrl + '/FourierRadialFiltering/Results/classmetrics.csv';
        this.outputCsvUrlFourier = this.tftGenUrl + '/FourierRadialFiltering/Results/output.csv';
        /* ********* Please take a special care about flags set in "showDetailFunc" ***************/
        //Path for overall csv data (gray scale)
        this.overallMatriCsUrl_Obj_GrayScale = this.tftGenUrl + '/Object_Recognition/GrayScale/Results/overallmetrics.csv';
        //Path for class level csv data (gray scale)
        this.classMatriCsUrl_Obj_GrayScaler = this.tftGenUrl + '/Object_Recognition/GrayScale/Results/classmetrics.csv';
        //output csv path to pick the image and show them in the slider
        this.outputCsvUrl_Obj_GrayScale = this.tftGenUrl + '/Object_Recognition/GrayScale/Results/output.csv';
        this.overallMatriCsUrl_Obj_Contrast = this.tftGenUrl + '/Object_Recognition/LowContrast/Results/overallmetrics.csv';
        this.classMatriCsUrl_Obj_Contrast = this.tftGenUrl + '/Object_Recognition/LowContrast/Results/classmetrics.csv';
        this.outputCsvUrl_Obj_Contrast = this.tftGenUrl + '/Object_Recognition/LowContrast/Results/output.csv';
        this.overallMatriCsUrl_Obj_AdditiveNoise = this.tftGenUrl + '/Object_Recognition/Noisy/Results/overallmetrics.csv';
        this.classMatriCsUrl_Obj_AdditiveNoise = this.tftGenUrl + '/Object_Recognition/Noisy/Results/classmetrics.csv';
        this.outputCsvUrl_Obj_AdditiveNoise = this.tftGenUrl + '/Object_Recognition/Noisy/Results/output.csv';
        this.overallMatriCsUrl_Obj_EidolonNoise = this.tftGenUrl + '/Object_Recognition/Eidolon/Results/overallmetrics.csv';
        this.classMatriCsUrl_Obj_EidolonNoise = this.tftGenUrl + '/Object_Recognition/Eidolon/Results/classmetrics.csv';
        this.outputCsvUrl_Obj_EidolonNoise = this.tftGenUrl + '/Object_Recognition/Eidolon/Results/output.csv';
        this.overallMatriCsUrl_Obj_ModelComplexity = this.tftGenUrl + '/ModelComplexity/Results/overallmetrics.csv';
        this.classMatriCsUrl_Obj_ModelComplexity = this.tftGenUrl + '/ModelComplexity/Results/classmetrics.csv';
        this.outputCsvUrl_Obj_ModelComplexity = this.tftGenUrl + '/ModelComplexity/Results/output.csv';
        this.overallMatriCsUrlAdversarialPatches = this.tftRobPath + '/AdversarialPatches/Results/overallmetrics.csv';
        this.classMatriCsUrlAdversarialPatches = this.tftRobPath + '/AdversarialPatches/Results/classmetrics.csv'; // URL to web API
        this.outputCsvUrlAdversarialPatches = this.tftRobPath + '/AdversarialPatches/Results/output.csv';
        this.overallMatriCsUrlAdversarialInputsCW = this.tftRobPath + '/AdversarialInputs/carliniWagnerMethod/Results/overallmetrics.csv';
        this.classMatriCsUrlAdversarialInputsCW = this.tftRobPath + '/AdversarialInputs/carliniWagnerMethod/Results/classmetrics.csv'; // URL to web API
        this.outputCsvUrlAdversarialInputsCW = this.tftRobPath + '/AdversarialInputs/carliniWagnerMethod/Results/output.csv';
        this.interpretablityCsvUrl = this.tftInterPath + '/Results/limeoutput.csv';
        this.experimentsCsvURL = this.resultPath + '/experiments.csv';
        // adversarialinputSettingsCsvURL = this.tftRobPath + '/AdversarialInputs/settings.csv';
        this.adversarialinputSettingsCsvURL;
        this.interpretabilitySettingsCsvURL = this.tftInterPath + '/settings.csv';
        this.filePath = './assets/results/' + this.projectName + '/Interpretability/Results/limeoutput.csv';
    };
    ImageClassifierComponent.prototype.ngOnInit = function () {
        //this.createProjectFormControll();
        //this.createProjectForm();
        // this.adversarialImgClass();
        // this.readLimeData();
        // this.fourier();
        // this.objectRecognition_WeakSignals();
        // this.adversarialpatchesImgClass();
        // this.readexperimentsran();
        // this.interpretabilitySettingFunc();
        //this.fileNames();
        this.listProjects();
    };
    ImageClassifierComponent.prototype.loadAllCSVDataFunc = function () {
        this.adversarialImgClass();
        this.readLimeData();
        this.fourier();
        this.objectRecognition_WeakSignals();
        this.adversarialpatchesImgClass();
        this.adversarialInputsCWImgClass();
        this.readexperimentsran();
        this.interpretabilitySettingFunc();
        this.forceScrollUpdate(null);
    };
    ImageClassifierComponent.prototype.ngAfterViewInit = function () {
        $(".insidepage-sidenav").mCustomScrollbar({
            scrollButtons: { enable: false },
            theme: "dark-thin",
            autoHideScrollbar: true,
            scrollbarPosition: "outside"
        });
        $('#ScrollExp').mCustomScrollbar({
            callbacks: {
                onInit: function () {
                    console.log("scrollbars initialized");
                }
            }
        });
    };
    ImageClassifierComponent.prototype.forceScrollUpdate = function ($event) {
        var _this = this;
        // alert("Hi");
        //console.log("selected index -- ", this.selectedIndex);
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 10);
        this.overallExplanation = true;
        if ($event) {
            if ($event.tab.textLabel == 'Robustness') {
                this.setDefaultGen();
                this.err1 = false;
                this.err2 = false;
            }
            if ($event.tab.textLabel == 'Generalization') {
                this.setDefaultRob();
                this.err1 = false;
                this.err2 = false;
            }
            else {
                this.setDefaultLime();
            }
        }
    };
    ImageClassifierComponent.prototype.setDefaultRob = function () {
        this.showInitialTableAdversarialPatches = true;
        this.showDetailTableAdversarialPatches = false;
        this.showInitialTableAdversarialInputs = true;
        this.showDetailTableAdversarialInputs = false;
        this.showInitialTableAdversarialInputsCW = true;
        this.showDetailTableAdversarialInputsCW = false;
        this.adversarialpatchesshowPara = true;
        this.adversarialpatchesshowSlider = false;
        this.adversarialInputsshowPara = true;
        this.adversarialInputsshowSlider = false;
        this.adversarialInputsCWshowPara = true;
        this.adversarialInputsCWshowSlider = false;
        this.showViewPatch = false;
        this.adversarialpatchesshowPatch = false;
        this.showHidePatch = false;
        this.clearMsgs();
    };
    ImageClassifierComponent.prototype.setDefaultGen = function () {
        this.showInitialTableRotationTranslation = true;
        this.showDetailTableRotationTranslation = false;
        this.showInitialTableFourierFiltering = true;
        this.showDetailTableFourierFiltering = false;
        this.showInitialTableGrayScale = true;
        this.showDetailTableGrayScale = false;
        this.showInitialTableContrast = true;
        this.showDetailTableContrast = false;
        this.showInitialTableAdditiveNoise = true;
        this.showDetailTableAdditiveNoise = false;
        this.showInitialTableEidolonNoise = true;
        this.showDetailTableEidolonNoise = false;
        this.showInitialTableModelComplexity = true;
        this.showDetailTableModelComplexity = false;
        this.rotationtranslationshowPara = true;
        this.rotationtranslationshowSlider = false;
        this.fourierfilteringshowPara = true;
        this.fourierfilteringshowSlider = false;
        this.grayscaleshowPara = true;
        this.grayscaleshowSlider = false;
        this.contrastshowPara = true;
        this.contrastshowSlider = false;
        this.additivenoiseshowPara = true;
        this.additivenoiseshowSlider = false;
        this.eidolonnoiseshowPara = true;
        this.eidolonnoiseshowSlider = false;
        this.modelcomplexityshowPara = true;
        this.modelcomplexityshowSlider = false;
        this.clearMsgs();
    };
    ImageClassifierComponent.prototype.setDefaultLime = function () {
        this.setDefaultRob();
        this.setDefaultGen();
    };
    ImageClassifierComponent.prototype.clearMsgs = function () {
        this.err1 = false;
        this.err2 = false;
        this.clearError();
    };
    // setDefaultGenRob(){
    //   this.setDefaultRob()
    //   this.setDefaultGen()
    // }
    // setToDefaultAll(){
    //   this.setDefaultLime()
    //   //this.clearError()
    //   //this.err_msg1=''
    //   //this.err_msg2=''
    //   //this.setToDefaultLime()
    // }
    ImageClassifierComponent.prototype.pageChanged = function ($event) {
        var _this = this;
        // alert($event);
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 10);
    };
    ImageClassifierComponent.prototype.onplcSubmit = function () {
        this.searchClasseswithProbabilityLesser(this.overal_LimeCsvData);
    };
    ImageClassifierComponent.prototype.plcKeyPress = function ($event) {
        //console.log("plc key event -- ",$event)
        // console.log($event.target.value)
        if ($event.key === "Enter") {
            this.onplcSubmit();
        }
    };
    ImageClassifierComponent.prototype.onpgcSubmit = function () {
        this.searchClasseswithProbabilityGreater(this.overal_LimeCsvData);
    };
    ImageClassifierComponent.prototype.pgcKeyPress = function ($event) {
        //console.log("pgc key event -- ",$event)
        // console.log($event.target.value)
        if ($event.key === "Enter") {
            this.onpgcSubmit();
        }
    };
    ImageClassifierComponent.prototype.setSampleData_1 = function (val) {
        if (val.value > 0 && val.value <= 50) {
            this.restrictImageDisplay = val.value;
            this.err1 = false;
        }
        else {
            //this.err_msg1 = 'The value must be in range of 1-50'
            this.err1 = true;
            //this.restrictImageDisplay=10;
        }
    };
    ImageClassifierComponent.prototype.setSampleData_2 = function (val) {
        if (val.value > 0 && val.value <= 50) {
            this.restrictImageDisplay1 = val.value;
            this.err2 = false;
        }
        else {
            //this.err_msg2 = 'The value must be in range of 1-50'
            this.err2 = true;
            this.restrictImageDisplay = 10;
        }
    };
    ImageClassifierComponent.prototype.setSample = function (val) {
        if (val.value == '') {
            this.thankyouMsg = 'Please enter some text';
        }
    };
    ImageClassifierComponent.prototype.applyFilter1 = function ($event) {
        // console.log("key event -- ",$event)
        // console.log($event.target.value)
        if ($event.key === "Enter") {
            if (Number($event.target.value) > 0 && Number($event.target.value) <= 50) {
                this.restrictImageDisplay = Number($event.target.value);
            }
            else {
                this.err1 = true;
            }
        }
        else {
            this.err1 = false;
        }
    };
    ImageClassifierComponent.prototype.applyFilter2 = function ($event) {
        // console.log("key event -- ",$event)
        // console.log($event.target.value)
        if ($event.key === "Enter") {
            if (Number($event.target.value) > 0 && Number($event.target.value) <= 50) {
                this.restrictImageDisplay1 = Number($event.target.value);
            }
            else {
                this.err2 = true;
            }
        }
        else {
            this.err2 = false;
        }
    };
    ImageClassifierComponent.prototype.clearError = function () {
        this.thankyouMsg = '';
    };
    // clearErr1(){
    //   this.err1=false
    //   this.restrictImageDisplay = 10
    // }
    // clearErr2(){
    //   this.err2=false
    //   this.restrictImageDisplay1 = 10
    // }
    ImageClassifierComponent.prototype.oncSubmit = function (index, page) {
        //console.log("comment ----- ",this.cmodel.commentValue[this.mIndex].comments);
        // console.log("while submit --- ", this.mIndex)
        this.tcomm = this.limeCsvData[this.mIndex].comments;
        this.textIndex = 10 * (page - 1) + index;
        //this.cmodel.commentValue[this.mIndex] = this.tcomm
        var comnt = this.cmodel.commentValue[this.mIndex].comments;
        if (this.cmodel.commentValue[this.mIndex].comments != '') {
            this.appendToLimeCsv(this.mIndex, comnt);
        }
    };
    ImageClassifierComponent.prototype.appendToLimeCsv = function (indexVal, commentVal) {
        //console.log(this.updateLimeCsv)
        //console.log('commentVal ---- ',commentVal)
        var limeRecAtIndex = this.limeCsvData[indexVal];
        this.limeCsvData[indexVal].isSelected = 'True';
        this.limeCsvData[indexVal].comments = commentVal;
        for (var i = 0; i < this.updateLimeCsv.length; i++) {
            if (this.updateLimeCsv[i].IMAGE.replace(/["]/g, '') == limeRecAtIndex.limeOriginalImage.replace(/["]/g, '')) {
                this.updateLimeCsv[i].comments = commentVal.replace(/,/g, ';');
                this.updateLimeCsv[i].isSelected = 'True';
                this.overal_LimeCsvData[i].isSelected = 'True';
                this.overal_LimeCsvData[i].comments = commentVal;
                break;
            }
        }
        this.downloadFile(this.updateLimeCsv);
    };
    ImageClassifierComponent.prototype.readexperimentsran = function () {
        var _this = this;
        this.http.get(this.experimentsCsvURL)
            .subscribe(function (data) {
            _this.extractexpData(data);
        }, function (err) { console.log(err); });
    };
    ImageClassifierComponent.prototype.extractexpData = function (res) {
        var csvData = res['_body'] || '';
        var allTextLines = csvData.split(/\r\n|\n/);
        var headers = allTextLines[0].split(',');
        var lines = [];
        for (var i = 0; i < allTextLines.length; i++) {
            // split content based on comma
            if (allTextLines[i]) {
                var data = allTextLines[i].split(',');
                if (data.length == headers.length) {
                    var tarr = [];
                    for (var j = 0; j < headers.length; j++) {
                        tarr.push(data[j]);
                    }
                    lines.push(tarr);
                }
            }
        }
        this.experimentsRancsvData = lines;
        for (var i = 0; i < lines[0].length; i++) {
            //this.model[lines[0][i]] = true;
            this.model[lines[0][i]] = JSON.parse(lines[1][i].toLowerCase());
        }
        var myObjStr = JSON.stringify(csvData);
        var jsonObject = JSON.parse(myObjStr);
    };
    ImageClassifierComponent.prototype.adversarialinputSetting = function () {
        var _this = this;
        this.http.get(this.adversarialinputSettingsCsvURL)
            .subscribe(function (data) {
            _this.extractaisData(data);
        }, function (err) { console.log(err); });
    };
    ImageClassifierComponent.prototype.extractaisData = function (res) {
        var csvData = res['_body'] || '';
        var allTextLines = csvData.split(/\r\n|\n/);
        if (allTextLines[0]) {
            this.adversarialtSettingsHeader = allTextLines[0].split(',');
        }
        if (allTextLines[1]) {
            this.adversarialSettingValues = allTextLines[1].split(',');
        }
        if (allTextLines[2]) {
            this.adversarialSettingLabels = allTextLines[2].split(',');
        }
        this.settingDict = {
            settingHeader: this.adversarialtSettingsHeader,
            settingValues: this.adversarialSettingValues,
            settingLabels: this.adversarialSettingLabels
        };
        this.setFlag = true;
    };
    ImageClassifierComponent.prototype.interpretabilitySettingFunc = function () {
        var _this = this;
        this.http.get(this.interpretabilitySettingsCsvURL)
            .subscribe(function (data) {
            _this.extractaipsData(data);
        }, function (err) { console.log(err); });
    };
    ImageClassifierComponent.prototype.extractaipsData = function (res) {
        var csvData = res['_body'] || '';
        var allTextLines = csvData.split(/\r\n|\n/);
        var headers = allTextLines[0].split(',');
        var lines = [];
        for (var i = 0; i < allTextLines.length; i++) {
            // split content based on comma
            if (allTextLines[i]) {
                var data = allTextLines[i].split(',');
                if (data.length == headers.length) {
                    var tarr = [];
                    for (var j = 0; j < headers.length; j++) {
                        tarr.push(data[j]);
                    }
                    lines.push(tarr);
                }
            }
        }
        this.interpretabilitySettingscsvData = lines;
        for (var i = 0; i < lines[0].length; i++) {
            this.ipValue[lines[0][i]] = JSON.parse(lines[1][i].toLowerCase());
        }
        var myObjStr = JSON.stringify(csvData);
        var jsonObject = JSON.parse(myObjStr);
    };
    ImageClassifierComponent.prototype.downloadFile = function (data) {
        var _this = this;
        var replacer = function (key, value) { return value === null ? '' : value; }; // specify how you want to handle null values here
        var header = Object.keys(data[0]);
        var csv = data.map(function (row) { return header.map(function (fieldName) { return JSON.stringify(row[fieldName], replacer); }).join(','); });
        csv.unshift(header.join(','));
        var csvArray = csv.join('\r\n');
        //var a = document.createElement('a');
        // var blob = new Blob([csvArray], {type: 'text/csv;encoding:utf-8' })
        //  var selectedFile = new File([blob], 'limeoutput.csv', {type:'text/csv;encoding:utf-8'});
        //  const formdata = new FormData()
        //  formdata.append('file', data)
        var pname = '';
        if (this.projectName.split('/')[0] == 'Benchmark') {
            pname = this.projectName.split('/')[1];
        }
        else {
            pname = this.projectName;
        }
        this.http.post('http://localhost:5000/file/' + pname, { limeCsv: csvArray })
            .subscribe(function (resp) {
            _this.thankyouMsg = 'Your messege is submitted';
        }, function (err) {
            console.log('some error occuresd in file uploading');
            _this.thankyouMsg = 'some error occured';
        });
        //saveAs(blob,'limeoutput.csv')
        //url = window.URL.createObjectURL(blob);
        //a.href = url;
        //a.download = "myFile.csv";
        //a.click();
        //window.URL.revokeObjectURL(url);
        //a.remove();
    };
    ImageClassifierComponent.prototype.onsubChange = function ($event) {
        if (this.model.adversarialExamplesValue === true || this.model.adversarialPatchesValue === true || this.model.adversarialInputsCWValue === true) {
            this.model.robustnessValue = true;
        }
        else {
            this.model.robustnessValue = false;
        }
    };
    ImageClassifierComponent.prototype.ongensubChange = function ($event) {
        if (this.model.fourierfilteringValue === true || this.model.colortograyscaleValue === true || this.model.contrastValue === true || this.model.additivenoiseValue === true || this.model.eidolonnoiseValue === true || this.model.modelcomplexityValue === true) {
            this.model.generalizaionValue = true;
        }
        else {
            this.model.generalizaionValue = false;
        }
    };
    ImageClassifierComponent.prototype.adversarialSettingsValue = function ($event) {
        this.asValue = $event;
    };
    ImageClassifierComponent.prototype.settingMethod = function ($event) {
        switch ($event.toElement.id) {
            case 'rnts': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/RotationNTranslation/settings.csv';
                break;
            }
            case 'ffs': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/FourierRadialFiltering/settings.csv';
                break;
            }
            case 'gss': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/Object_Recognition/GrayScale/settings.csv';
                break;
            }
            case 'cs': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/Object_Recognition/LowContrast/settings.csv';
                break;
            }
            case 'ans': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/Object_Recognition/Noisy/settings.csv';
                break;
            }
            case 'ens': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/Object_Recognition/Eidolon/settings.csv';
                break;
            }
            case 'mcs': {
                this.adversarialinputSettingsCsvURL = this.tftGenUrl + '/Object_Recognition/ModelComplexity/settings.csv';
                break;
            }
            case 'ais': {
                this.adversarialinputSettingsCsvURL = this.tftRobPath + '/AdversarialInputs/fastGradientSignMethod/settings.csv';
                break;
            }
            case 'aps': {
                this.adversarialinputSettingsCsvURL = this.tftRobPath + '/AdversarialPatches/settings.csv';
                break;
            }
            case 'aiscw': {
                this.adversarialinputSettingsCsvURL = this.tftRobPath + '/AdversarialInputs/carliniWagnerMethod/settings.csv';
                break;
            }
            case 'ipt': {
                this.adversarialinputSettingsCsvURL = this.tftInterPath + '/settings.csv';
                break;
            }
        }
        this.adversarialinputSetting();
    };
    ImageClassifierComponent.prototype.interpretabilitySettingsValue = function ($event) {
        this.ipValue = $event;
    };
    ImageClassifierComponent.prototype.menuclick = function () {
        if (this.menuBurger.nativeElement.classList.contains('open')) {
            this.closeMenu();
        }
        else {
            this.openMenu();
        }
    };
    ImageClassifierComponent.prototype.myMethod = function ($event) {
        var _this = this;
        this.pmodel = { probablitylcValue: 0.5, probablitygcValue: 0.5 };
        //this.clearErr1()
        //this.clearErr2()
        document.getElementById("sampleId1").value = "10";
        document.getElementById("sampleId2").value = "10";
        this.restrictImageDisplay = 10;
        this.restrictImageDisplay1 = 10;
        this.err1 = false;
        this.err2 = false;
        this.clickedID = $event.toElement.id;
        if ($event.toElement.id === 'wrongly_classified') {
            this.misclassifiedClassesWithHighProbability(this.overal_LimeCsvData);
            this.overallExplanation = this.correctlyClassifiedwithHighProbablityExplanation = this.classifiedwithHighProbablityExplanation = false;
            this.thankyouMsg = '';
            this.page = 1;
            this.misclassifiedwithHighProbablityExplanation = true;
        }
        else if ($event.toElement.id === 'Correctly_classified') {
            this.classifiedClassesWithLowProbability(this.overal_LimeCsvData);
            this.overallExplanation = this.misclassifiedwithHighProbablityExplanation = this.classifiedwithHighProbablityExplanation = false;
            this.thankyouMsg = '';
            this.page = 1;
            this.correctlyClassifiedwithHighProbablityExplanation = true;
        }
        else if ($event.toElement.id === 'Correctly_classified_High_Probablity') {
            this.correctlyClassifiedWithHighProbablity(this.overal_LimeCsvData);
            this.overallExplanation = this.misclassifiedwithHighProbablityExplanation = this.correctlyClassifiedwithHighProbablityExplanation = false;
            this.thankyouMsg = '';
            this.page = 1;
            this.classifiedwithHighProbablityExplanation = true;
        }
        else if ($event.toElement.id === 'overall') {
            this.allClassifiedClasses(this.overal_LimeCsvData);
            this.correctlyClassifiedwithHighProbablityExplanation = this.misclassifiedwithHighProbablityExplanation = this.classifiedwithHighProbablityExplanation = false;
            this.thankyouMsg = '';
            this.page = 1;
            this.overallExplanation = true;
        }
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
    };
    ImageClassifierComponent.prototype.setToDefaultLime = function () {
        var _this = this;
        this.restrictImageDisplay = 10;
        this.restrictImageDisplay1 = 10;
        this.pmodel = { probablitylcValue: 0.5, probablitygcValue: 0.5 };
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
    };
    ImageClassifierComponent.prototype.searchClasseswithProbabilityLesser = function (limeCsv) {
        var _this = this;
        var tempLimeCsv = [];
        if (this.clickedID === 'wrongly_classified') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability <= _this.pmodel.probablitylcValue) && (element.Misclassified_classes_with_high_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else if (this.clickedID === 'Correctly_classified') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability <= _this.pmodel.probablitylcValue) && (element.Classified_classes_with_low_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else if (this.clickedID === 'Correctly_classified_High_Probablity') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability <= _this.pmodel.probablitylcValue) && (element.Correctly_classified_with_high_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else {
            limeCsv.forEach(function (element) {
                if (element.search_classes_with_probability <= _this.pmodel.probablitylcValue) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv Probability value
        }
        this.limeCsvData = [];
        this.limeCsvData = tempLimeCsv;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
    };
    ImageClassifierComponent.prototype.searchClasseswithProbabilityGreater = function (limeCsv) {
        var _this = this;
        var tempLimeCsv = [];
        if (this.clickedID === 'wrongly_classified') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability >= _this.pmodel.probablitygcValue) && (element.Misclassified_classes_with_high_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else if (this.clickedID === 'Correctly_classified') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability >= _this.pmodel.probablitygcValue) && (element.Classified_classes_with_low_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else if (this.clickedID === 'Correctly_classified_High_Probablity') {
            limeCsv.forEach(function (element) {
                if ((element.search_classes_with_probability >= _this.pmodel.probablitygcValue) && (element.Correctly_classified_with_high_probability.toUpperCase() == 'TRUE')) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv where Probability value and Misclassified_classes_with_high_probability is TRUE
        }
        else {
            limeCsv.forEach(function (element) {
                if (element.search_classes_with_probability >= _this.pmodel.probablitygcValue) {
                    tempLimeCsv.push(element);
                }
            });
            //checks each json object of the array
            //Add the record to tempLimeCsv Probability value
        }
        this.limeCsvData = [];
        this.limeCsvData = tempLimeCsv;
        this.cmodel.commentValue = tempLimeCsv;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
    };
    ImageClassifierComponent.prototype.misclassifiedClassesWithHighProbability = function (limeCsv) {
        this.activateMisclassified = true;
        this.activateClassified = false;
        this.activateAll = false;
        this.activateCorrectHighProbablity = false;
        var tempLimeCsv = [];
        limeCsv.forEach(function (element) {
            if (element.Misclassified_classes_with_high_probability.toUpperCase() == 'TRUE') {
                tempLimeCsv.push(element);
            }
        });
        //checks each json object of the array
        //Add the record to tempLimeCsv where Misclassified_classes_with_high_probability is TRUE
        this.limeCsvData = [];
        this.limeCsvData = tempLimeCsv;
        this.cmodel.commentValue = tempLimeCsv;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
    };
    ImageClassifierComponent.prototype.classifiedClassesWithLowProbability = function (limeCsv) {
        this.activateClassified = true;
        this.activateMisclassified = false;
        this.activateAll = false;
        this.activateCorrectHighProbablity = false;
        var tempLimeCsv = [];
        limeCsv.forEach(function (element) {
            if (element.Classified_classes_with_low_probability.toUpperCase() == 'TRUE') {
                tempLimeCsv.push(element);
            }
        });
        //checks each json object of the array
        //Add the record to tempLimeCsv where Classified_classes_with_low_probability is TRUE
        this.limeCsvData = [];
        this.limeCsvData = tempLimeCsv;
        this.cmodel.commentValue = tempLimeCsv;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
    };
    ImageClassifierComponent.prototype.correctlyClassifiedWithHighProbablity = function (limeCsv) {
        this.activateCorrectHighProbablity = true;
        this.activateAll = false;
        this.activateClassified = false;
        this.activateMisclassified = false;
        var tempLimeCsv = [];
        limeCsv.forEach(function (element) {
            if (element.Correctly_classified_with_high_probability.toUpperCase() == 'TRUE') {
                tempLimeCsv.push(element);
            }
        });
        //checks each json object of the array
        //Add the record to tempLimeCsv where Correctly_classified_with_high_probability is TRUE
        this.limeCsvData = [];
        this.limeCsvData = tempLimeCsv;
        this.cmodel.commentValue = tempLimeCsv;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
    };
    ImageClassifierComponent.prototype.allClassifiedClasses = function (limeCsv) {
        this.activateAll = true;
        this.activateClassified = false;
        this.activateMisclassified = false;
        this.activateCorrectHighProbablity = false;
        this.limeCsvData = [];
        this.limeCsvData = this.overal_LimeCsvData;
        this.cmodel.commentValue = this.overal_LimeCsvData;
        if (this.limeCsvData.length === 0) {
            this.blankFlag = true;
        }
        else {
            this.blankFlag = false;
        }
    };
    // createProjectForm() {
    //   this.imgClassifierForm = new FormGroup({
    //     projectName: this.projectName,
    //     modelName: this.modelName,
    //     sampleData: this.sampleData
    //   }
    //   );
    // }
    ImageClassifierComponent.prototype.setDefaultClassMatrix = function () {
        return [{ "originalExample": 0, "adversarialExample": 0 }];
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataAdv = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrlAdv)
            .subscribe(function (data) {
            _this.processClassMatrics_Adv(data);
            _this.readImageAdv();
            _this.showInitialFuncAdversarialInputs();
            _this.adversInp = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Adv = _this.setDefaultClassMatrix();
            _this.adversInp = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataRotationTranslation = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_RotationTranslation)
            .subscribe(function (data) {
            _this.processClassMatrics_RotationTranslation(data);
            _this.rotNtrans = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_RotationTranslation = _this.setDefaultClassMatrix();
            _this.rotNtrans = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataFourier = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrlFourier)
            .subscribe(function (data) {
            _this.processClassMatrics_Fourier(data);
            _this.readImageFourierFiltering();
            _this.showInitialFuncFourierFiltering();
            _this.fourierFilter = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Fourier = _this.setDefaultClassMatrix();
            _this.fourierFilter = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataGrayScale = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_GrayScaler)
            .subscribe(function (data) {
            _this.processClassMatrics_GrayScale(data);
            _this.readImageGrayScaler();
            _this.showInitialFuncGrayScale();
            _this.objRecGrayScale = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_GrayScale = _this.setDefaultClassMatrix();
            _this.objRecGrayScale = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataContrast = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_Contrast)
            .subscribe(function (data) {
            _this.processClassMatrics_Contrast(data);
            _this.readImageContrast();
            _this.showInitialFuncContrast();
            _this.objLowContrast = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_Contrast = _this.setDefaultClassMatrix();
            _this.objLowContrast = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataAdditiveNoise = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_AdditiveNoise)
            .subscribe(function (data) {
            _this.processClassMatrics_AdditiveNoise(data);
            _this.readImageAdditiveNoise();
            _this.showInitialFuncAdditiveNoise();
            _this.objAddNoise = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_AdditiveNoise = _this.setDefaultClassMatrix();
            _this.objAddNoise = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataEidolonNoise = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_EidolonNoise)
            .subscribe(function (data) {
            _this.processClassMatrics_EidolonNoise(data);
            _this.readImageEidolonNoise();
            _this.showInitialFuncEidolonNoise();
            _this.objEdNoise = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_EidolonNoise = _this.setDefaultClassMatrix();
            _this.objEdNoise = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataModelComplexity = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrl_Obj_ModelComplexity)
            .subscribe(function (data) {
            _this.processClassMatrics_ModelComplexity(data);
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_Obj_ModelComplexity = _this.setDefaultClassMatrix();
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataAdversarialPatches = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrlAdversarialPatches)
            .subscribe(function (data) {
            _this.processClassMatrics_AdversarialPatches(data);
            _this.readImageAdversarialPatches();
            _this.showInitialFuncAdversarialPatches();
            _this.advPatches = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_AdversarialPatches = _this.setDefaultClassMatrix();
            _this.advPatches = true;
        });
    };
    ImageClassifierComponent.prototype.readClassMatricsCsvDataAdversarialInputsCW = function () {
        var _this = this;
        this.http.get(this.classMatriCsUrlAdversarialInputsCW)
            .subscribe(function (data) {
            _this.processClassMatrics_AdversarialInputsCW(data);
            _this.readImageAdversarialInputsCW();
            _this.showInitialFuncAdversarialInputsCW();
            _this.adversInpCW = false;
        }, function (err) {
            //this.handleError(err)
            _this.filterClassMatricsData_AdversarialInputsCW = _this.setDefaultClassMatrix();
            _this.adversInpCW = true;
        });
    };
    ImageClassifierComponent.prototype.processClassMatrics_Adv = function (data) {
        this.filterClassMatricsData_Adv = [];
        this.filterClassMatricsData_Adv = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_RotationTranslation = function (data) {
        this.filterClassMatricsData_Obj_RotationTranslation = [];
        this.filterClassMatricsData_Obj_RotationTranslation = this.projectServe.extractRNTData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_Fourier = function (data) {
        this.filterClassMatricsData_Fourier = [];
        this.filterClassMatricsData_Fourier = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_GrayScale = function (data) {
        this.filterClassMatricsData_Obj_GrayScale = [];
        this.filterClassMatricsData_Obj_GrayScale = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_Contrast = function (data) {
        this.filterClassMatricsData_Obj_Contrast = [];
        this.filterClassMatricsData_Obj_Contrast = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_AdditiveNoise = function (data) {
        this.filterClassMatricsData_Obj_AdditiveNoise = [];
        this.filterClassMatricsData_Obj_AdditiveNoise = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_EidolonNoise = function (data) {
        this.filterClassMatricsData_Obj_EidolonNoise = [];
        this.filterClassMatricsData_Obj_EidolonNoise = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_ModelComplexity = function (data) {
        this.filterClassMatricsData_Obj_ModelComplexity = [];
        this.filterClassMatricsData_Obj_ModelComplexity = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_AdversarialPatches = function (data) {
        this.filterClassMatricsData_AdversarialPatches = [];
        this.filterClassMatricsData_AdversarialPatches = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.processClassMatrics_AdversarialInputsCW = function (data) {
        this.filterClassMatricsData_AdversarialInputsCW = [];
        this.filterClassMatricsData_AdversarialInputsCW = this.projectServe.extractData(data);
    };
    ImageClassifierComponent.prototype.setToDefaultOverall = function () {
        return [{ "overallMatricsOriginalPrecision": 0, "overallMatricsPrecision": 0 }];
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataAdv = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrlAdv)
            .subscribe(function (data) {
            _this.overallData_Adv(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallAdversarialData = _this.setToDefaultOverall();
            _this.adversInp = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataRotationTranslation = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_RotationTranslation)
            .subscribe(function (data) {
            _this.overallData_RotationTranslation(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecRotationTranslationData = _this.setToDefaultOverall();
            _this.rotNtrans = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataFourier = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrlFourier)
            .subscribe(function (data) {
            _this.overallData_Fourier(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallFourierData = _this.setToDefaultOverall();
            _this.fourierFilter = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataGrayScale = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_GrayScale)
            .subscribe(function (data) {
            _this.overallData_GrayScaler(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecGrayScaleData = _this.setToDefaultOverall();
            _this.objRecGrayScale = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataContrast = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_Contrast)
            .subscribe(function (data) {
            _this.overallData_Contrast(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecContrastData = _this.setToDefaultOverall();
            _this.objLowContrast = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataAdditiveNoise = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_AdditiveNoise)
            .subscribe(function (data) {
            _this.overallData_AdditiveNoise(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecAdditiveNoiseData = _this.setToDefaultOverall();
            _this.objAddNoise = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataEidolonNoise = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_EidolonNoise)
            .subscribe(function (data) {
            _this.overallData_EidolonNoise(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecEidolonNoiseData = _this.setToDefaultOverall();
            _this.objEdNoise = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataModelComplexity = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrl_Obj_ModelComplexity)
            .subscribe(function (data) {
            _this.overallData_ModelComplexity(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallObjRecModelComplexityData = _this.setToDefaultOverall();
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataAdversarialPatches = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrlAdversarialPatches)
            .subscribe(function (data) {
            _this.overallData_AdversarialPatches(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallAdversarialPatchesData = _this.setToDefaultOverall();
            _this.advPatches = true;
        });
    };
    ImageClassifierComponent.prototype.readoverallMatricsCsvDataAdversarialInputsCW = function () {
        var _this = this;
        this.http.get(this.overallMatriCsUrlAdversarialInputsCW)
            .subscribe(function (data) {
            _this.overallData_AdversarialInputsCW(data);
        }, function (err) {
            //this.handleError(err)
            _this.overallAdversarialInputsCWData = _this.setToDefaultOverall();
            _this.adversInpCW = true;
        });
    };
    ImageClassifierComponent.prototype.overallData_Adv = function (data) {
        this.overallAdversarialData = [];
        this.overallAdversarialData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_RotationTranslation = function (data) {
        this.overallObjRecRotationTranslationData = [];
        this.overallObjRecRotationTranslationData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_Fourier = function (data) {
        this.overallFourierData = [];
        this.overallFourierData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_GrayScaler = function (data) {
        this.overallObjRecGrayScaleData = [];
        this.overallObjRecGrayScaleData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_Contrast = function (data) {
        this.overallObjRecContrastData = [];
        this.overallObjRecContrastData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_AdditiveNoise = function (data) {
        this.overallObjRecAdditiveNoiseData = [];
        this.overallObjRecAdditiveNoiseData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_EidolonNoise = function (data) {
        this.overallObjRecEidolonNoiseData = [];
        this.overallObjRecEidolonNoiseData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_ModelComplexity = function (data) {
        this.overallObjRecModelComplexityData = [];
        this.overallObjRecModelComplexityData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_AdversarialPatches = function (data) {
        this.overallAdversarialPatchesData = [];
        this.overallAdversarialPatchesData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.overallData_AdversarialInputsCW = function (data) {
        this.overallAdversarialInputsCWData = [];
        this.overallAdversarialInputsCWData = this.extractoverallData(data);
    };
    ImageClassifierComponent.prototype.extractoverallData = function (res) {
        var tempoverallAdversarialData = [];
        var tempoverallMatricsData = this.projectServe.extractCsvData(res);
        var tempoverallMatricsOriginalPrecision = Math.round((Math.round((tempoverallMatricsData[0][1] * 1 + 0.00001) * 100) / 100) * 100);
        var tempoverallMatricsPrecision = Math.round((Math.round((tempoverallMatricsData[0][2] * 1 + 0.00001) * 100) / 100) * 100);
        var tempoverallMatricsDiff;
        if (tempoverallMatricsData[0][3].toUpperCase() == 'TRUE') {
            tempoverallMatricsDiff = 'red';
        }
        else {
            tempoverallMatricsDiff = 'green';
        }
        var overallData = {
            overallMatricsOriginalPrecision: tempoverallMatricsOriginalPrecision,
            overallMatricsPrecision: tempoverallMatricsPrecision,
            overallMatricsDiff: tempoverallMatricsDiff
        };
        tempoverallAdversarialData.push(overallData);
        return tempoverallAdversarialData;
        //sessionStorage.setItem('overallData', JSON.stringify(overallData));
    };
    ImageClassifierComponent.prototype.handleError = function (error) {
        // In a real world app, we might use a remote logging infrastructure
        var errMsg = (error.message) ? error.message :
            error.status ? error.status + " - " + error.statusText : 'Server error';
        console.error(errMsg); // log to console instead
        return errMsg;
    };
    // createProjectFormControll() {
    //   this.projectName = new FormControl('', Validators.required);
    //   this.modelName = new FormControl('', Validators.required);
    //   this.sampleData = new FormControl('', Validators.required);
    // }
    ImageClassifierComponent.prototype.adversarialImgClass = function () {
        this.readoverallMatricsCsvDataAdv();
        this.readClassMatricsCsvDataAdv();
    };
    ImageClassifierComponent.prototype.fourier = function () {
        this.readoverallMatricsCsvDataFourier();
        this.readClassMatricsCsvDataFourier();
    };
    ImageClassifierComponent.prototype.objectRecognition_WeakSignals = function () {
        this.grayScale();
        this.contrast();
        this.additivenoise();
        this.eidolonnoise();
        this.modelcomplexity();
        this.rotationtranslation();
        this.showInitialFuncGrayScale();
    };
    ImageClassifierComponent.prototype.rotationtranslation = function () {
        this.readoverallMatricsCsvDataRotationTranslation();
        this.readClassMatricsCsvDataRotationTranslation();
        this.readImageRotationTranslation();
        this.showInitialFuncRotationTranslation();
        // this.showInitialTableRotationTranslation = true;
    };
    ImageClassifierComponent.prototype.grayScale = function () {
        this.readoverallMatricsCsvDataGrayScale();
        this.readClassMatricsCsvDataGrayScale();
    };
    ImageClassifierComponent.prototype.contrast = function () {
        this.readoverallMatricsCsvDataContrast();
        this.readClassMatricsCsvDataContrast();
    };
    ImageClassifierComponent.prototype.additivenoise = function () {
        this.readoverallMatricsCsvDataAdditiveNoise();
        this.readClassMatricsCsvDataAdditiveNoise();
    };
    ImageClassifierComponent.prototype.eidolonnoise = function () {
        this.readoverallMatricsCsvDataEidolonNoise();
        this.readClassMatricsCsvDataEidolonNoise();
    };
    ImageClassifierComponent.prototype.modelcomplexity = function () {
        // this.readoverallMatricsCsvDataModelComplexity();
        // this.readClassMatricsCsvDataModelComplexity();
        // this.readImageModelComplexity();
        // this.showInitialFuncModelComplexity();
    };
    ImageClassifierComponent.prototype.adversarialpatchesImgClass = function () {
        this.readoverallMatricsCsvDataAdversarialPatches();
        this.readClassMatricsCsvDataAdversarialPatches();
        // this.readImageAdversarialPatches();
        // this.showInitialFuncAdversarialPatches();
    };
    ImageClassifierComponent.prototype.adversarialInputsCWImgClass = function () {
        this.readoverallMatricsCsvDataAdversarialInputsCW();
        this.readClassMatricsCsvDataAdversarialInputsCW();
        // this.readImageAdversarialPatches();
        // this.showInitialFuncAdversarialPatches();
    };
    ImageClassifierComponent.prototype.openMenu = function () {
        $('div.burger').addClass('open');
        $('div.y').fadeOut(100);
        $('div.screen').addClass('animate');
        setTimeout(function () {
            $('div.x').addClass('rotate30');
            $('div.z').addClass('rotate150');
            $('.menu').addClass('animate');
            setTimeout(function () {
                $('div.x').addClass('rotate45');
                $('div.z').addClass('rotate135');
            }, 100);
        }, 10);
    };
    ImageClassifierComponent.prototype.closeMenu = function () {
        $('div.screen, .menu').removeClass('animate');
        $('div.y').fadeIn(150);
        $('div.burger').removeClass('open');
        $('div.x').removeClass('rotate45').addClass('rotate30');
        $('div.z').removeClass('rotate135').addClass('rotate150');
        setTimeout(function () {
            $('div.x').removeClass('rotate30');
            $('div.z').removeClass('rotate150');
        }, 50);
        setTimeout(function () {
            $('div.x, div.z').removeClass('collapse');
        }, 70);
    };
    ImageClassifierComponent.prototype.readImageAdv = function () {
        var _this = this;
        this.http.get(this.outputCsvUrlAdv)
            .subscribe(function (data) {
            _this.imageDisplay_Adv(data);
        }, function (err) { return console.log("readImageAdv Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageRotationTranslation = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_RotationTranslation)
            .subscribe(function (data) {
            _this.imageDisplay_RotationTranslation(data);
        }, function (err) { return console.log("readImageRotationTranslation Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageFourierFiltering = function () {
        var _this = this;
        this.http.get(this.outputCsvUrlFourier)
            .subscribe(function (data) {
            _this.imageDisplay_FourierFiltering(data);
        }, function (err) { return console.log("readImageFourierFiltering Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageGrayScaler = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_GrayScale)
            .subscribe(function (data) {
            _this.imageDisplay_GrayScale(data);
        }, function (err) { return console.log("readImageGrayScaler Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageContrast = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_Contrast)
            .subscribe(function (data) {
            _this.imageDisplay_Contrast(data);
        }, function (err) { return console.log("readImageContrast Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageAdditiveNoise = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_AdditiveNoise)
            .subscribe(function (data) {
            _this.imageDisplay_AdditiveNoise(data);
        }, function (err) { return console.log("readImageAdditiveNoise Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageEidolonNoise = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_EidolonNoise)
            .subscribe(function (data) {
            _this.imageDisplay_EidolonNoise(data);
        }, function (err) { return console.log("readImageEidolonNoise Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageModelComplexity = function () {
        var _this = this;
        this.http.get(this.outputCsvUrl_Obj_ModelComplexity)
            .subscribe(function (data) {
            _this.imageDisplay_ModelComplexity(data);
        }, function (err) { return console.log("readImageModelComplexity Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageAdversarialPatches = function () {
        var _this = this;
        this.http.get(this.outputCsvUrlAdversarialPatches)
            .subscribe(function (data) {
            _this.imageDisplay_AdversarialPatches(data);
        }, function (err) { return console.log("readImageAdversarialPatches Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.readImageAdversarialInputsCW = function () {
        var _this = this;
        this.http.get(this.outputCsvUrlAdversarialInputsCW)
            .subscribe(function (data) {
            _this.imageDisplay_AdversarialInputsCW(data);
        }, function (err) { return console.log("readImageAdversarialInputsCW Error"); } //alert("error please check")
        );
    };
    ImageClassifierComponent.prototype.imageDisplay_Adv = function (data) {
        this.csvImgData_Adversarial = [];
        this.csvImgData_Adversarial = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_RotationTranslation = function (data) {
        this.csvImgData_Obj_RotationTranslation = [];
        this.csvImgData_Obj_RotationTranslation = this.showImage(data);
        // console.log()
    };
    ImageClassifierComponent.prototype.imageDisplay_FourierFiltering = function (data) {
        this.csvImgData_FourierFiltering = [];
        this.csvImgData_FourierFiltering = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_GrayScale = function (data) {
        this.csvImgData_Obj_GrayScale = [];
        this.csvImgData_Obj_GrayScale = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_Contrast = function (data) {
        this.csvImgData_Obj_Contrast = [];
        this.csvImgData_Obj_Contrast = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_AdditiveNoise = function (data) {
        this.csvImgData_Obj_AdditiveNoise = [];
        this.csvImgData_Obj_AdditiveNoise = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_EidolonNoise = function (data) {
        this.csvImgData_Obj_EidolonNoise = [];
        this.csvImgData_Obj_EidolonNoise = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_ModelComplexity = function (data) {
        this.csvImgData_Obj_ModelComplexity = [];
        this.csvImgData_Obj_ModelComplexity = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_AdversarialPatches = function (data) {
        this.csvImgData_AdversarialPatches = [];
        this.csvImgData_AdversarialPatches = this.showImage(data);
    };
    ImageClassifierComponent.prototype.imageDisplay_AdversarialInputsCW = function (data) {
        this.csvImgData_AdversarialInputsCW = [];
        this.csvImgData_AdversarialInputsCW = this.showImage(data);
    };
    ImageClassifierComponent.prototype.readLimeData = function () {
        var _this = this;
        this.http2.get(this.interpretablityCsvUrl, { responseType: 'text' })
            .subscribe(function (data) {
            _this.extractInterpretablityCsvData(data);
            _this.interPret = false;
            _this.setToDefaultLime();
        }, function (err) {
            console.log("readLimeData Error");
            _this.extractInterpretablityCsvData('');
            _this.interPret = true;
            //alert("No lime output found!!")
        });
    };
    ImageClassifierComponent.prototype.extractInterpretablityCsvData = function (res) {
        if (res.length > 0) {
            var allTextLines = res.split(/\r\n/);
            var limeJson = void 0;
            var search_classes_with_probability = void 0;
            var Misclassified_classes_with_high_probability = void 0;
            var Classified_classes_with_low_probability = void 0;
            var Correctly_classified_with_high_probability = void 0;
            var outerFolder = void 0;
            var imgFolder = void 0;
            var originalImage = void 0;
            var className = void 0;
            var classNameToSearch = void 0;
            var firstPrediction = void 0;
            var len = allTextLines.length - 1;
            this.limeCsvData = [];
            this.overal_LimeCsvData = [];
            this.imageNetLimeCsvData = [];
            if (allTextLines[0].split(',').length == 10) {
                for (var i = 1; i < allTextLines.length - 1; i++) {
                    var predict = [];
                    var explain = [];
                    var prob = [];
                    // split content based on comma
                    limeJson = {};
                    if (allTextLines[i]) {
                        var records = allTextLines[i].split(',');
                        predict.push(records[2].replace(/["'\]\[' ']/g, ''));
                        predict.push(records[3].replace(/["'\]\[' ']/g, ''));
                        explain.push(records[5].replace(/["'\]\[' ']/g, ''));
                        explain.push(records[6].replace(/["'\]\[' ']/g, ''));
                        prob.push(records[10].replace(/["'\]\[' ']/g, ''));
                        prob.push(records[11].replace(/["'\]\[' ']/g, ''));
                        for (var i_1 = 0; i_1 < prob.length; i_1++) {
                            if (!isNaN(prob[i_1])) {
                                prob[i_1] = parseFloat(prob[i_1]).toFixed(3);
                            }
                        }
                        imgFolder = records[0].substring(0, records[0].indexOf("."));
                        originalImage = records[0];
                        className = records[1];
                        //Replace the underscore in className with space to make it ready for google image search
                        classNameToSearch = className.replace(/_/g, ' ');
                        Misclassified_classes_with_high_probability = records[13];
                        //First prediction out of top three predictions
                        firstPrediction = predict[0].replace(/_/g, ' ');
                        search_classes_with_probability = records[9];
                        Classified_classes_with_low_probability = records[14];
                        Correctly_classified_with_high_probability = records[15];
                        limeJson = {
                            limeImgFolder: imgFolder,
                            limeOriginalImage: originalImage,
                            limeOriginalClassName: className,
                            classNameToSearch: classNameToSearch,
                            firstPrediction: firstPrediction,
                            predictions: predict,
                            explaination: explain,
                            probablity: prob,
                            search_classes_with_probability: search_classes_with_probability,
                            Misclassified_classes_with_high_probability: Misclassified_classes_with_high_probability,
                            Classified_classes_with_low_probability: Classified_classes_with_low_probability,
                            Correctly_classified_with_high_probability: Correctly_classified_with_high_probability,
                            isSelected: 'False',
                            comments: ''
                        };
                        this.limeCsvData.push(limeJson);
                        if (className in this.imageNetLimeCsvData) {
                            var temp = this.imageNetLimeCsvData[className];
                            temp.push(className + '/' + imgFolder + '/' + originalImage);
                            this.imageNetLimeCsvData[className] = temp;
                        }
                        else {
                            var images = [];
                            images.push(className + '/' + imgFolder + '/' + originalImage);
                            this.imageNetLimeCsvData[className] = images;
                        }
                    }
                }
            }
            else {
                for (var i = 1; i < allTextLines.length - 1; i++) {
                    var predict = [];
                    var explain = [];
                    var prob = [];
                    // split content based on comma
                    limeJson = {};
                    if (allTextLines[i]) {
                        var records = allTextLines[i].split(',');
                        predict.push(records[2].replace(/["'\]\[' ']/g, ''));
                        predict.push(records[3].replace(/["'\]\[' ']/g, ''));
                        explain.push(records[5].replace(/["'\]\[' ']/g, ''));
                        explain.push(records[6].replace(/["'\]\[' ']/g, ''));
                        prob.push(records[10].replace(/["'\]\[' ']/g, ''));
                        prob.push(records[11].replace(/["'\]\[' ']/g, ''));
                        for (var i_2 = 0; i_2 < prob.length; i_2++) {
                            if (!isNaN(prob[i_2])) {
                                prob[i_2] = parseFloat(prob[i_2]).toFixed(3);
                            }
                        }
                        imgFolder = records[0].substring(0, records[0].indexOf("."));
                        originalImage = records[0];
                        className = records[1];
                        //Replace the underscore in className with space to make it ready for google image search
                        classNameToSearch = className.replace(/_/g, ' ');
                        Misclassified_classes_with_high_probability = records[13];
                        //First prediction out of top three predictions
                        firstPrediction = predict[0].replace(/_/g, ' ');
                        search_classes_with_probability = records[9];
                        Classified_classes_with_low_probability = records[14];
                        Correctly_classified_with_high_probability = records[15];
                        limeJson = {
                            limeImgFolder: imgFolder,
                            limeOriginalImage: originalImage,
                            limeOriginalClassName: className,
                            classNameToSearch: classNameToSearch,
                            firstPrediction: firstPrediction,
                            predictions: predict,
                            explaination: explain,
                            probablity: prob,
                            search_classes_with_probability: search_classes_with_probability,
                            Misclassified_classes_with_high_probability: Misclassified_classes_with_high_probability,
                            Classified_classes_with_low_probability: Classified_classes_with_low_probability,
                            Correctly_classified_with_high_probability: Correctly_classified_with_high_probability,
                            isSelected: records[16],
                            comments: records[17].replace(/;/g, ',')
                        };
                        this.limeCsvData.push(limeJson);
                        if (className in this.imageNetLimeCsvData) {
                            var temp = this.imageNetLimeCsvData[className];
                            temp.push(className + '/' + imgFolder + '/' + originalImage);
                            this.imageNetLimeCsvData[className] = temp;
                        }
                        else {
                            var images = [];
                            images.push(className + '/' + imgFolder + '/' + originalImage);
                            this.imageNetLimeCsvData[className] = images;
                        }
                    }
                }
            }
            this.overal_LimeCsvData = this.limeCsvData;
            this.prepareCsvToSave(allTextLines);
            this.cmodel.commentValue = this.limeCsvData;
            this.blankFlag = false;
        }
        else {
            this.overal_LimeCsvData = [];
            this.limeCsvData = [];
            this.prepareCsvToSave('');
            this.cmodel = { commentValue: '' };
            this.blankFlag = true;
        }
    };
    ImageClassifierComponent.prototype.prepareCsvToSave = function (input) {
        if (input.length > 0) {
            var header = [];
            var limeJson = void 0;
            this.updateLimeCsv = [];
            if (input[0].split(',').length === 10) {
                for (var i = 1; i < input.length - 1; i++) {
                    // split content based on comma
                    var predict = void 0;
                    var explain = void 0;
                    var prob = void 0;
                    limeJson = {};
                    if (input[i]) {
                        var records = input[i].split(',');
                        predict = records[2].replace(/["'\]\[' ']/g, '') + ";" + records[3].replace(/["'\]\[' ']/g, '') + ";" + records[4].replace(/["'\]\[' ']/g, '');
                        // predict.push(records[2].replace(/["'\]\[' ']/g, ''))
                        // predict.push(records[3].replace(/["'\]\[' ']/g, ''))
                        // predict.push(records[4].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[5].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[6].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[7].replace(/["'\]\[' ']/g, ''))
                        explain = records[5].replace(/["'\]\[' ']/g, '') + ";" + records[6].replace(/["'\]\[' ']/g, '') + ";" + records[7].replace(/["'\]\[' ']/g, '');
                        // prob.push(records[10].replace(/["'\]\[' ']/g, ''))
                        // prob.push(records[11].replace(/["'\]\[' ']/g, ''))
                        // prob.push(records[12].replace(/["'\]\[' ']/g, ''))
                        prob = records[10].replace(/["'\]\[' ']/g, '') + ";" + records[11].replace(/["'\]\[' ']/g, '') + ";" + records[12].replace(/["'\]\[' ']/g, '');
                        limeJson = {
                            IMAGE: records[0],
                            ORIGINAL_LABEL: records[1],
                            Top_n_Predictions: predict,
                            Explanations: explain,
                            OriginalPredicted: records[8],
                            Probability_Of_Top_Most_Prediction: records[9],
                            Probability_Of_Top_n_Predictions: prob,
                            Misclassified_classes_with_high_probability: records[13],
                            Classified_classes_with_low_probability: records[14],
                            Correctly_classified_with_high_probability: records[15],
                            isSelected: 'False',
                            comments: ''
                        };
                        this.updateLimeCsv.push(limeJson);
                    }
                }
            } //header of length 10
            else {
                for (var i = 1; i < input.length - 1; i++) {
                    // split content based on comma
                    var predict = void 0;
                    var explain = void 0;
                    var prob = void 0;
                    limeJson = {};
                    if (input[i]) {
                        var records = input[i].replace(/["']/g, '').split(',');
                        //let predArr = records[2].split(';')
                        predict = records[2].replace(/["'\]\[' ']/g, '') + ";" + records[3].replace(/["'\]\[' ']/g, '') + ";" + records[4].replace(/["'\]\[' ']/g, '');
                        // predict.push(records[2].replace(/["'\]\[' ']/g, ''))
                        // predict.push(records[3].replace(/["'\]\[' ']/g, ''))
                        // predict.push(records[4].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[5].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[6].replace(/["'\]\[' ']/g, ''))
                        // explain.push(records[7].replace(/["'\]\[' ']/g, ''))
                        //let expArr = records[3].split(';')
                        explain = records[5].replace(/["'\]\[' ']/g, '') + ";" + records[6].replace(/["'\]\[' ']/g, '') + ";" + records[7].replace(/["'\]\[' ']/g, '');
                        // prob.push(records[10].replace(/["'\]\[' ']/g, ''))
                        // prob.push(records[11].replace(/["'\]\[' ']/g, ''))
                        // prob.push(records[12].replace(/["'\]\[' ']/g, ''))
                        //let probArr = records[6].split(';')
                        prob = records[10].replace(/["'\]\[' ']/g, '') + ";" + records[11].replace(/["'\]\[' ']/g, '') + ";" + records[12].replace(/["'\]\[' ']/g, '');
                        limeJson = {
                            IMAGE: records[0],
                            ORIGINAL_LABEL: records[1],
                            Top_n_Predictions: predict,
                            Explanations: explain,
                            OriginalPredicted: records[8],
                            Probability_Of_Top_Most_Prediction: records[9],
                            Probability_Of_Top_n_Predictions: prob,
                            Misclassified_classes_with_high_probability: records[13],
                            Classified_classes_with_low_probability: records[14],
                            Correctly_classified_with_high_probability: records[15],
                            isSelected: records[16],
                            comments: records[17].replace(/;/g, ',')
                        };
                        this.updateLimeCsv.push(limeJson);
                    }
                }
            }
            //this.downloadFile(this.updateLimeCsv)
        }
        else {
            this.updateLimeCsv = [];
        }
    };
    ImageClassifierComponent.prototype.showImage = function (res) {
        var tempcsvImgData = [];
        tempcsvImgData = this.projectServe.extractCsvData(res);
        return tempcsvImgData;
        //sessionStorage.setItem('csvImgData', JSON.stringify(this.csvImgData));
    };
    ImageClassifierComponent.prototype.selectedClassItems_AdversarialInputs = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.advImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Adversarial.length; i++) {
            if (this.csvImgData_Adversarial[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Adversarial[i][0],
                    orgName: this.csvImgData_Adversarial[i][2],
                    perName: this.csvImgData_Adversarial[i][3],
                    className: this.csvImgData_Adversarial[i][1]
                };
                this.advImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index8 = 0;
    };
    ImageClassifierComponent.prototype.rotationtranslationClassClick = function () {
        this.rotationtranslationshowPara = false;
        this.rotationtranslationshowSlider = true;
    };
    ImageClassifierComponent.prototype.fourierfilteringClassClick = function () {
        this.fourierfilteringshowPara = false;
        this.fourierfilteringshowSlider = true;
    };
    ImageClassifierComponent.prototype.grayscaleClassClick = function () {
        this.grayscaleshowPara = false;
        this.grayscaleshowSlider = true;
    };
    ImageClassifierComponent.prototype.contrastClassClick = function () {
        this.contrastshowPara = false;
        this.contrastshowSlider = true;
    };
    ImageClassifierComponent.prototype.addtivenoiseClassClick = function () {
        this.additivenoiseshowPara = false;
        this.additivenoiseshowSlider = true;
    };
    ImageClassifierComponent.prototype.eidolonnoiseClassClick = function () {
        this.eidolonnoiseshowPara = false;
        this.eidolonnoiseshowSlider = true;
    };
    ImageClassifierComponent.prototype.modelcomplexityClassClick = function () {
        this.modelcomplexityshowPara = false;
        this.modelcomplexityshowSlider = true;
    };
    ImageClassifierComponent.prototype.adversarialInputsClassClick = function () {
        this.adversarialInputsshowPara = false;
        this.adversarialInputsshowSlider = true;
    };
    ImageClassifierComponent.prototype.adversarialpatchesClassClick = function () {
        this.adversarialpatchesshowPara = false;
        this.adversarialpatchesshowSlider = true;
        this.showViewPatch = true;
    };
    ImageClassifierComponent.prototype.adversarialInputsCWClassClick = function () {
        this.adversarialInputsCWshowPara = false;
        this.adversarialInputsCWshowSlider = true;
    };
    ImageClassifierComponent.prototype.selectedClassItems_RotationTranslation = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecRotationTranslationImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_RotationTranslation.length; i++) {
            if (this.csvImgData_Obj_RotationTranslation[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_RotationTranslation[i][0],
                    orgName: this.csvImgData_Obj_RotationTranslation[i][2],
                    perName: this.csvImgData_Obj_RotationTranslation[i][3],
                    className: this.csvImgData_Obj_RotationTranslation[i][1],
                    rotationtranslationClassTextName: this.csvImgData_Obj_RotationTranslation[i][0].split("."),
                };
                var array = record.rotationtranslationClassTextName[0].split("_");
                var arrayLength = array.length;
                record["rotationDegree"] = array[array.length - 2];
                record["translationPixel"] = array[array.length - 1];
                this.objectRecRotationTranslationImages.push(record);
            }
        }
        this.index1 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_Fourier = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.fourierFilteredImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_FourierFiltering.length; i++) {
            if (this.csvImgData_FourierFiltering[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_FourierFiltering[i][0],
                    orgName: this.csvImgData_FourierFiltering[i][2],
                    perName: this.csvImgData_FourierFiltering[i][3],
                    className: this.csvImgData_FourierFiltering[i][1]
                };
                this.fourierFilteredImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index2 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_GrayScale = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecGrayScaleImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_GrayScale.length; i++) {
            //console.log("clicked class -- ", this.csvImgData_Obj_GrayScale[i][1])
            if (this.csvImgData_Obj_GrayScale[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_GrayScale[i][0],
                    orgName: this.csvImgData_Obj_GrayScale[i][2],
                    perName: this.csvImgData_Obj_GrayScale[i][3],
                    className: this.csvImgData_Obj_GrayScale[i][1]
                };
                this.objectRecGrayScaleImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index3 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_Contrast = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecContrastImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_Contrast.length; i++) {
            //console.log("clicked class -- ", this.csvImgData_Obj_Contrast[i][1])
            if (this.csvImgData_Obj_Contrast[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_Contrast[i][0],
                    orgName: this.csvImgData_Obj_Contrast[i][2],
                    perName: this.csvImgData_Obj_Contrast[i][3],
                    className: this.csvImgData_Obj_Contrast[i][1]
                };
                this.objectRecContrastImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index4 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_AdditiveNoise = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecAdditiveNoiseImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_AdditiveNoise.length; i++) {
            //console.log("clicked class -- ", this.csvImgData_Obj_AdditiveNoise[i][1])
            if (this.csvImgData_Obj_AdditiveNoise[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_AdditiveNoise[i][0],
                    orgName: this.csvImgData_Obj_AdditiveNoise[i][2],
                    perName: this.csvImgData_Obj_AdditiveNoise[i][3],
                    className: this.csvImgData_Obj_AdditiveNoise[i][1]
                };
                this.objectRecAdditiveNoiseImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index5 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_EidolonNoise = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecEidolonNoiseImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_EidolonNoise.length; i++) {
            //console.log("clicked class -- ", this.csvImgData_Obj_EidolonNoise[i][1])
            if (this.csvImgData_Obj_EidolonNoise[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_EidolonNoise[i][0],
                    orgName: this.csvImgData_Obj_EidolonNoise[i][2],
                    perName: this.csvImgData_Obj_EidolonNoise[i][3],
                    className: this.csvImgData_Obj_EidolonNoise[i][1]
                };
                this.objectRecEidolonNoiseImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index6 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_ModelComplexity = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.objectRecModelComplexityImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_Obj_ModelComplexity.length; i++) {
            //console.log("clicked class -- ", this.csvImgData_Obj_ModelComplexity[i][1])
            if (this.csvImgData_Obj_ModelComplexity[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_Obj_ModelComplexity[i][0],
                    orgName: this.csvImgData_Obj_ModelComplexity[i][2],
                    perName: this.csvImgData_Obj_ModelComplexity[i][3],
                    className: this.csvImgData_Obj_ModelComplexity[i][1]
                };
                this.objectRecModelComplexityImages.push(record);
            }
        }
        // this.showSlider = true;
    };
    ImageClassifierComponent.prototype.selectedClassItems_AdversarialPatches = function ($event) {
        // this.showPara = false;
        this.hideAdversarialPatches();
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.adversarialPatchesImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_AdversarialPatches.length; i++) {
            if (this.csvImgData_AdversarialPatches[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_AdversarialPatches[i][0],
                    orgName: this.csvImgData_AdversarialPatches[i][2],
                    perName: this.csvImgData_AdversarialPatches[i][3],
                    className: this.csvImgData_AdversarialPatches[i][1]
                };
                this.adversarialPatchesImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index9 = 0;
    };
    ImageClassifierComponent.prototype.selectedClassItems_AdversarialInputsCW = function ($event) {
        // this.showPara = false;
        var col = $event.target.dataset.index;
        this.clickedClass = $event.target.textContent;
        this.adversarialInputsCWImages = [];
        var x = 0;
        for (var i = 0; i < this.csvImgData_AdversarialInputsCW.length; i++) {
            if (this.csvImgData_AdversarialInputsCW[i][1] == this.clickedClass) {
                var record = {
                    image: this.csvImgData_AdversarialInputsCW[i][0],
                    orgName: this.csvImgData_AdversarialInputsCW[i][2],
                    perName: this.csvImgData_AdversarialInputsCW[i][3],
                    className: this.csvImgData_AdversarialInputsCW[i][1]
                };
                this.adversarialInputsCWImages.push(record);
            }
        }
        // this.showSlider = true;
        this.index10 = 0;
    };
    ImageClassifierComponent.prototype.showDetailFuncRotationTranslation = function () {
        this.showInitialTableRotationTranslation = false;
        this.showDetailTableRotationTranslation = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncFourierFiltering = function () {
        this.showInitialTableFourierFiltering = false;
        this.showDetailTableFourierFiltering = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncGrayScale = function () {
        this.showInitialTableGrayScale = false;
        this.showDetailTableGrayScale = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncContrast = function () {
        this.showInitialTableContrast = false;
        this.showDetailTableContrast = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncAdditiveNoise = function () {
        this.showInitialTableAdditiveNoise = false;
        this.showDetailTableAdditiveNoise = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncEidolonNoise = function () {
        this.showInitialTableEidolonNoise = false;
        this.showDetailTableEidolonNoise = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncModelComplexity = function () {
        this.showInitialTableModelComplexity = false;
        this.showDetailTableModelComplexity = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncAdversarialInputs = function () {
        this.showInitialTableAdversarialInputs = false;
        this.showDetailTableAdversarialInputs = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncAdversarialInputsCW = function () {
        this.showInitialTableAdversarialInputsCW = false;
        this.showDetailTableAdversarialInputsCW = true;
    };
    ImageClassifierComponent.prototype.showDetailFuncAdversarialPatches = function () {
        this.showInitialTableAdversarialPatches = false;
        this.showDetailTableAdversarialPatches = true;
    };
    ImageClassifierComponent.prototype.showInitialFuncRotationTranslation = function () {
        this.showInitialTableRotationTranslation = true;
        this.showDetailTableRotationTranslation = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncFourierFiltering = function () {
        this.showInitialTableFourierFiltering = true;
        this.showDetailTableFourierFiltering = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncGrayScale = function () {
        this.showInitialTableGrayScale = true;
        this.showDetailTableGrayScale = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncContrast = function () {
        this.showInitialTableContrast = true;
        this.showDetailTableContrast = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncAdditiveNoise = function () {
        this.showInitialTableAdditiveNoise = true;
        this.showDetailTableAdditiveNoise = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncEidolonNoise = function () {
        this.showInitialTableEidolonNoise = true;
        this.showDetailTableEidolonNoise = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncModelComplexity = function () {
        this.showInitialTableModelComplexity = true;
        this.showDetailTableModelComplexity = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncAdversarialInputs = function () {
        this.showInitialTableAdversarialInputs = true;
        this.showDetailTableAdversarialInputs = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncAdversarialInputsCW = function () {
        this.showInitialTableAdversarialInputsCW = true;
        this.showDetailTableAdversarialInputsCW = false;
    };
    ImageClassifierComponent.prototype.showInitialFuncAdversarialPatches = function () {
        this.showInitialTableAdversarialPatches = true;
        this.showDetailTableAdversarialPatches = false;
    };
    ImageClassifierComponent.prototype.showAdversarialPatches = function () {
        //console.log("showAdversarialPatches showViewPatch")
        this.adversarialpatchesshowPatch = true;
        this.adversarialpatchesshowSlider = false;
        this.showViewPatch = false;
        this.showHidePatch = true;
    };
    ImageClassifierComponent.prototype.hideAdversarialPatches = function () {
        //console.log("hideAdversarialPatches showViewPatch")
        this.adversarialpatchesshowPatch = false;
        this.adversarialpatchesshowSlider = true;
        this.showViewPatch = true;
        this.showHidePatch = false;
    };
    ImageClassifierComponent.prototype.onIndexChange = function (index) {
        console.log('Swiper index: ', index);
    };
    ImageClassifierComponent.prototype.onSwiperEvent = function (event) {
        console.log('Swiper event: ', event);
    };
    ImageClassifierComponent.prototype.followUpSelect = function ($event, Mindex) {
        // this.showCommentBox = true;
        // console.log($event.target.parentElement.parentElement.parentElement.querySelectorAll('.commentbox-wrap'));
        var commentboxarray = $event.target.parentElement.parentElement.parentElement.getElementsByClassName("commentbox-wrap");
        // var checkboxarray = $event.target.parentElement.getElementsByClassName("checkbox");
        for (var i = 0; i < commentboxarray.length; i++) {
            commentboxarray[i].classList.toggle("active");
            // $event.target.checked = true;
        }
        // $event.target.checked = true;
        //console.log("current index -- ",Mindex)
        this.mIndex = Mindex;
        this.cmodel.commentValue = this.limeCsvData;
        //console.log("limeCsvData -- ", this.limeCsvData[this.mIndex])
        // for(var j = 0; j < checkboxarray.length; j++)
        // {
        //     // checkboxarray[j].className += " active";
        //     checkboxarray[j].checked = true;
        // }
        // $event.target.parentElement.parentElement.parentElement.getElementsByClassName('checkbox').checked = true;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Number)
    ], ImageClassifierComponent.prototype, "selectedIndex", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('menuBurger'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"])
    ], ImageClassifierComponent.prototype, "menuBurger", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperComponent"]),
        __metadata("design:type", ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperComponent"])
    ], ImageClassifierComponent.prototype, "componentRef", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperDirective"]),
        __metadata("design:type", ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperDirective"])
    ], ImageClassifierComponent.prototype, "directiveRef", void 0);
    ImageClassifierComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-image-classifier',
            template: __webpack_require__(/*! ./image-classifier.component.html */ "./src/app/image-classifier/image-classifier.component.html"),
            styles: [__webpack_require__(/*! ./image-classifier.component.css */ "./src/app/image-classifier/image-classifier.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"],
            _services_project_creation_service__WEBPACK_IMPORTED_MODULE_1__["ProjectCreationService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"], _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"], ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_5__["MalihuScrollbarService"]])
    ], ImageClassifierComponent);
    return ImageClassifierComponent;
}());



/***/ }),

/***/ "./src/app/interpretability-settings/interpretability-settings.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/interpretability-settings/interpretability-settings.component.css ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.interpretabilitysetting-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -165px 0px 0px -175px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.interpretabilitysetting-header{\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  text-align: center;\r\n  margin: 10px 0px 20px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n.interpretabilitysetting-option-wrap{\r\n  margin: 0px 0px 10px 0px;\r\n  text-align: left;\r\n}\r\n\r\n.interpretabilitysetting-option-wrap label{\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  width: 130px;\r\n  display: inline-block;\r\n  text-align: left;\r\n}\r\n\r\n.interpretabilitysetting-option-wrap input{\r\n  width: 240px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n.interpretabilitysetting-option-wrap p{\r\n  width: 240px;\r\n  float: right;\r\n  font-size: 11px;\r\n  text-align: left;\r\n  margin: 5px 0px\r\n}\r\n\r\n.interpretabilitysetting-option-wrap  title{\r\n  font-size: 11px;\r\n  text-align: left;\r\n}\r\n\r\n.interpretabilitysetting-option-wrap select {\r\n    width: 240px;\r\n    height: 28px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    font-family: 'Arial';\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n.interpretabilitysetting-option-wrap button{\r\n  display: inline-block;\r\n  font-size: 15px;\r\n  padding: 5px 20px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.96);\r\n  border: none;\r\n  margin: 15px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n.tooltip {\r\n    position: relative;\r\n\r\n}\r\n\r\n.tooltip .tooltiptext {\r\n    visibility: hidden;\r\n    width: 340px;\r\n    background: rgba(10, 10, 10, 1);\r\n    color: #fff;\r\n    text-align: left;\r\n    border-radius: 6px;\r\n    padding: 5px;\r\n    font-size: 12px;\r\n    line-height: 14px;\r\n    font-weight: 400;\r\n\r\n    /* Position the tooltip */\r\n    position: absolute;\r\n    bottom: 150%;\r\n    left: 50%;\r\n    margin-left: -170px;\r\n    z-index: 1;\r\n}\r\n\r\n.tooltip:hover .tooltiptext {\r\n    visibility: visible;\r\n}\r\n\r\n.tooltip .tooltiptext::after {\r\n    content: \" \";\r\n    position: absolute;\r\n    top: 100%; /* At the bottom of the tooltip */\r\n    left: 50%;\r\n    margin-left: -5px;\r\n    border-width: 5px;\r\n    border-style: solid;\r\n    border-color: black transparent transparent transparent;\r\n}\r\n\r\n.checkbox_wrap {\r\n  width: 25px !important;\r\n    display: block;\r\n    position: relative;\r\n    padding: 5px;\r\n    margin: 0px 5px 5px 0px;\r\n    cursor: pointer;\r\n    font-size: 22px;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n}\r\n\r\n/* Hide the browser's default checkbox */\r\n\r\n.checkbox_wrap input {\r\n    position: absolute;\r\n    opacity: 0;\r\n    cursor: pointer;\r\n}\r\n\r\n/* Create a custom checkbox */\r\n\r\n.checkmark {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    height: 20px;\r\n    width: 20px;\r\n    background-color: #eee;\r\n}\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n.checkbox_wrap:hover input ~ .checkmark {\r\n    background-color: #ccc;\r\n}\r\n\r\n/* When the checkbox is checked, add a blue background */\r\n\r\n.checkbox_wrap input:checked ~ .checkmark {\r\n    background-color: #2196F3;\r\n}\r\n\r\n/* Create the checkmark/indicator (hidden when not checked) */\r\n\r\n.checkmark:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    display: none;\r\n}\r\n\r\n/* Show the checkmark when checked */\r\n\r\n.checkbox_wrap input:checked ~ .checkmark:after {\r\n    display: block;\r\n}\r\n\r\n/* Style the checkmark/indicator */\r\n\r\n.checkbox_wrap .checkmark:after {\r\n    left: 6px;\r\n    top: 2px;\r\n    width: 5px;\r\n    height: 10px;\r\n    border: solid white;\r\n    border-width: 0 3px 3px 0;\r\n    -webkit-transform: rotate(45deg);\r\n    transform: rotate(45deg);\r\n}\r\n\r\n.btn-wrap{\r\n  text-align: center;\r\n}\r\n"

/***/ }),

/***/ "./src/app/interpretability-settings/interpretability-settings.component.html":
/*!************************************************************************************!*\
  !*** ./src/app/interpretability-settings/interpretability-settings.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog interpretabilitysetting-bg\">\r\n    <div class=\"interpretabilitysetting-wrap\">\r\n      <div class=\"interpretabilitysetting-header\">Interpretability Settings</div>\r\n      <form name=\"form\" (ngSubmit)=\"onSubmit()\" #f=\"ngForm\" novalidate>\r\n      <div class=\"interpretabilitysetting-cont-wrap\">\r\n        <div class=\"interpretabilitysetting-option-wrap form-group\">\r\n          <label for=\"\" class=\"tooltip\">num_features <i class=\"fa fa-info-circle\"></i>\r\n            <span class=\"tooltiptext\">\r\n            number of superpixels to include in explanation (By Default 5)\r\n            </span>\r\n          </label>\r\n          <input disabled type=\"text\" name=\"num_features\" [(ngModel)]=\"model.num_features\" #num_features=\"ngModel\" class=\"form-control\" />\r\n        </div>\r\n        <div class=\"clearfix\"></div>\r\n        <div class=\"interpretabilitysetting-option-wrap form-group\">\r\n          <label for=\"\" class=\"tooltip\">num_samples <i class=\"fa fa-info-circle\"></i>\r\n            <span class=\"tooltiptext\">\r\n            size of the neighborhood to learn the linear model (By Default 200)\r\n            </span>\r\n          </label>\r\n          <input disabled type=\"text\" name=\"num_samples\" [(ngModel)]=\"model.num_samples\" #num_samples=\"ngModel\" class=\"form-control\">\r\n        </div>\r\n        <!-- <div class=\"interpretabilitysetting-option-wrap form-group\">\r\n          <label for=\"\" class=\"tooltip\">hide_rest <i class=\"fa fa-info-circle\"></i>\r\n            <span class=\"tooltiptext\">\r\n            if True, make the non-explanation part of the return image gray\r\n            </span>\r\n          </label>\r\n          <label class=\"checkbox_wrap\">\r\n            <input type=\"checkbox\" name=\"hide_rest\" [(ngModel)]=\"model.hide_rest\" #hide_rest=\"ngModel\">\r\n            <span class=\"checkmark\"></span>\r\n          </label>\r\n        </div>\r\n        <div class=\"interpretabilitysetting-option-wrap form-group btn-wrap\">\r\n          <button>Submit</button>\r\n        </div> -->\r\n      </div>\r\n      </form>\r\n\r\n    </div>\r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/interpretability-settings/interpretability-settings.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/interpretability-settings/interpretability-settings.component.ts ***!
  \**********************************************************************************/
/*! exports provided: InterpretabilitySettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterpretabilitySettingsComponent", function() { return InterpretabilitySettingsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InterpretabilitySettingsComponent = /** @class */ (function () {
    function InterpretabilitySettingsComponent() {
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.interpretabilitySettingsValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.model = { num_features: "5", num_samples: "200", hide_rest: true };
    }
    InterpretabilitySettingsComponent.prototype.ngOnInit = function () {
        //this.interpretabilitySettingsValue.emit(this.model);
    };
    InterpretabilitySettingsComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    InterpretabilitySettingsComponent.prototype.onSubmit = function () {
        // console.log(JSON.stringify(this.model));
        //this.interpretabilitySettingsValue.emit(this.model);
        this.close();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], InterpretabilitySettingsComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], InterpretabilitySettingsComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], InterpretabilitySettingsComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], InterpretabilitySettingsComponent.prototype, "interpretabilitySettingsValue", void 0);
    InterpretabilitySettingsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-interpretability-settings',
            template: __webpack_require__(/*! ./interpretability-settings.component.html */ "./src/app/interpretability-settings/interpretability-settings.component.html"),
            styles: [__webpack_require__(/*! ./interpretability-settings.component.css */ "./src/app/interpretability-settings/interpretability-settings.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [])
    ], InterpretabilitySettingsComponent);
    return InterpretabilitySettingsComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.login-bg{\r\n  background: url('login_bg.jpg') #000000  no-repeat center center;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -165px 0px 0px -175px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(255, 255, 255, 0.95);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.form-group{\r\n  min-height: 70px;\r\n}\r\n\r\n.useremail-wrap label, .userpassword-wrap label, .registername-wrap label, .registeremail-wrap label, .registerpassword-wrap label, .registerrepeatpassword-wrap label{\r\n  color: rgb(255, 255, 255);\r\n  font-size: 14px;\r\n  margin: 0px 0px 0px 0px;\r\n  display: block;\r\n}\r\n\r\n.useremail-wrap input, .userpassword-wrap input, .registername-wrap input, .registeremail-wrap input, .registerpassword-wrap input, .registerrepeatpassword-wrap input{\r\n  width: 100%;\r\n  background: transparent;\r\n  border: none;\r\n  color: rgb(255, 255, 255);\r\n  font-size: 14px;\r\n  padding: 5px 0px;\r\n  border-bottom: rgb(255, 255, 255) solid 1px;\r\n}\r\n\r\n.form-horizontal{\r\n  width: 100%;\r\n  min-height: 240px;\r\n}\r\n\r\n.btn-login, .btn-register{\r\n  padding: 10px 0px;\r\n  width: 100%;\r\n  text-align: center;\r\n  background: #ff3366;\r\n  color: rgb(255, 255, 255);\r\n  border: none;\r\n  font-size: 14px;\r\n}\r\n\r\n.btn-login:disabled, .btn-register:disabled{\r\n  background: rgba(88, 88, 88, 0.74);\r\n}\r\n\r\n.btn-login{\r\n  margin: 80px 0px 20px 0px;\r\n}\r\n\r\n.btn-register{\r\n  margin: 20px 0px;\r\n}\r\n\r\n/* .ng-dirty.ng-invalid label{\r\n  color: rgba(186, 9, 6, 1);\r\n} */\r\n\r\ninput.ng-dirty.ng-invalid{\r\n  border-bottom: rgba(186, 9, 6, 1) solid 1px;\r\n}\r\n\r\n.form-control-feedback p{\r\n  color: rgba(186, 9, 6, 1);\r\n  font-size: 14px;\r\n  padding: 5px 0px;\r\n}\r\n"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<div [@dialog] *ngIf=\"visible\" class=\"dialog login-bg\">\r\n\t<!-- <ng-content></ng-content> -->\r\n\r\n  <mat-tab-group>\r\n  <mat-tab label=\"Login\">\r\n    <form class=\"form-horizontal\" [formGroup]=\"loginForm\" novalidate (ngSubmit)=\"login()\">\r\n        <div class=\"form-group useremail-wrap\"\r\n             [ngClass]=\"{\r\n              'has-danger': userEmail.invalid && (userEmail.dirty || userEmail.touched),\r\n              'has-success': userEmail.valid && (userEmail.dirty || userEmail.touched)\r\n         }\">\r\n      <label for=\"userEmail\" class=\"control-label\">Username</label>\r\n      <!-- <input type=\"email\" class=\"form-control\" id=\"userName\" name=\"userName\" required/> -->\r\n      <input type=\"email\"\r\n           class=\"form-control\"\r\n           formControlName=\"userEmail\"\r\n           required\r\n           (input)=\"clearLoginEmail()\"\r\n           >\r\n    <div class=\"form-control-feedback\"\r\n         *ngIf=\"userEmail.errors && (userEmail.dirty || userEmail.touched)\">\r\n\r\n      <p *ngIf=\"userEmail.errors.required\">Email is required</p>\r\n      <p *ngIf=\"userEmail.errors.email\">Enter correct Email ID</p>\r\n\r\n      <!-- <p *ngIf=\"userEmail.errors.pattern\">The email address must contain at least the @ character</p> -->\r\n    </div>\r\n\r\n\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"form-group userpassword-wrap\"\r\n        [ngClass]=\"{\r\n        'has-danger': userPassword.invalid && (userPassword.dirty || userPassword.touched),\r\n        'has-success': userPassword.valid && (userPassword.dirty || userPassword.touched)\r\n       }\">\r\n      <label for=\"userPassword\" class=\"control-label\">Password</label>\r\n      <!-- <input type=\"password\" class=\"form-control\" id=\"userPassword\" name=\"userPassword\" required/> -->\r\n      <input type=\"password\"\r\n           class=\"form-control\"\r\n           formControlName=\"userPassword\"\r\n           required\r\n           (input)=\"clearLoginPassword()\"\r\n           >\r\n    <div class=\"form-control-feedback\"\r\n         *ngIf=\"userPassword.errors && (userPassword.dirty || userPassword.touched)\">\r\n      <p *ngIf=\"userPassword.errors.required\">Password is required</p>\r\n      <p *ngIf=\"userPassword.errors.minlength\">Password is Weak</p>\r\n      <!-- <p *ngIf=\"userPassword.errors.minlength\">Password must be 8 characters long, we need another {{password.errors.minlength.requiredLength - password.errors.minlength.actualLength}} characters </p> -->\r\n    </div>\r\n      </div>\r\n      <div class=\"db-error\" style=\"color: red\">\r\n          <p>{{ loginEmailCheck }}</p>\r\n          <p>{{ loginPasswordCheck }}</p>\r\n        </div>\r\n      <button type=\"submit\" class=\"btn-login\" [disabled]=\"!loginForm.valid\">Login</button>\r\n      <!-- <input class=\"btn btn-primary\"  type=\"submit\" value=\"Submit\" /> -->\r\n    </form>\r\n  </mat-tab>\r\n  <mat-tab label=\"Register\">\r\n    <form class=\"form-horizontal\" [formGroup]=\"registerForm\" novalidate (ngSubmit)=\"register()\">\r\n      <div class=\"form-group registername-wrap\"\r\n        [ngClass]=\"{\r\n          'has-danger': registerName.invalid && (registerName.dirty || registerName.touched),\r\n          'has-success': registerName.valid && (registerName.dirty || registerName.touched)\r\n      }\">\r\n        <label for=\"registerName\" class=\"control-label\">Name</label>\r\n        <input type=\"text\"\r\n             class=\"form-control\"\r\n             formControlName=\"registerName\"\r\n             required\r\n             (input)=\"clearRegisterName()\"\r\n             >\r\n            <p class=\"text text-danger\" style=\"color: red\">{{ registerNameCheck }}</p>\r\n      <div class=\"form-control-feedback\"\r\n           *ngIf=\"registerName.errors && (registerName.dirty || registerName.touched)\">\r\n        <p *ngIf=\"registerName.errors.required\">Name is required</p>\r\n      </div>\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"form-group registeremail-wrap\"\r\n          [ngClass]=\"{\r\n            'has-danger': registerEmail.invalid && (registerEmail.dirty || registerEmail.touched),\r\n            'has-success': registerEmail.valid && (registerEmail.dirty || registerEmail.touched)\r\n       }\">\r\n        <label for=\"registerEmail\" class=\"control-label\">Username</label>\r\n        <input type=\"email\"\r\n           class=\"form-control\"\r\n           formControlName=\"registerEmail\"\r\n           required\r\n           (input)=\"clearRegisterEmail()\"\r\n           >\r\n          <p class=\"text text-danger\" style=\"color: red\">{{ registerEmailCheck }}</p>\r\n        <div class=\"form-control-feedback\"\r\n             *ngIf=\"registerEmail.errors && (registerEmail.dirty || registerEmail.touched)\">\r\n          <p *ngIf=\"registerEmail.errors.required\">Email is required</p>\r\n          <p *ngIf=\"registerEmail.errors.email\">Enter correct Email ID</p>\r\n        </div>\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"form-group registerpassword-wrap\"\r\n          [ngClass]=\"{\r\n            'has-danger': registerPassword.invalid && (registerPassword.dirty || registerPassword.touched),\r\n            'has-success': registerPassword.valid && (registerPassword.dirty || registerPassword.touched)\r\n       }\">\r\n        <label for=\"registerPassword\" class=\"control-label\">Password</label>\r\n        <input type=\"password\"\r\n           class=\"form-control\"\r\n           formControlName=\"registerPassword\"\r\n           required>\r\n        <div class=\"form-control-feedback\"\r\n             *ngIf=\"registerPassword.errors && (registerPassword.dirty || registerPassword.touched)\">\r\n          <p *ngIf=\"registerPassword.errors.required\">Password is required</p>\r\n          <p *ngIf=\"registerPassword.errors.minlength\">Password is Weak</p>\r\n        </div>\r\n      </div>\r\n      <div class=\"clearfix\"></div>\r\n      <div class=\"form-group registerrepeatpassword-wrap\"\r\n          [ngClass]=\"{\r\n            'has-danger': registerRepeatPassword.invalid && (registerRepeatPassword.dirty || registerRepeatPassword.touched),\r\n            'has-success': registerRepeatPassword.valid && (registerRepeatPassword.dirty || registerRepeatPassword.touched)\r\n       }\">\r\n        <label for=\"registerRepeatPassword\" class=\"control-label\">Repeat Password</label>\r\n        <input type=\"password\"\r\n           class=\"form-control\"\r\n           formControlName=\"registerRepeatPassword\"\r\n           required\r\n           (input)=\"clearRegisterPassword()\"\r\n           >\r\n           <p class=\"text text-danger\" style=\"color: red\">{{ registerPasswordCheck }}</p>\r\n        <div class=\"form-control-feedback\"\r\n             *ngIf=\"(registerRepeatPassword.errors && (registerRepeatPassword.dirty || registerRepeatPassword.touched) || registerForm .errors?.mismatch)\">\r\n          <!-- <p *ngIf=\"registerRepeatPassword.errors.required\">Password is required</p> -->\r\n          <!-- <p *ngIf=\"registerRepeatPassword.errors.minlength\">Password Weak</p> -->\r\n          <p *ngIf=\"registerRepeatPassword.errors || registerForm .errors?.mismatch\">Password doesn't match</p>\r\n        </div>\r\n\r\n      </div>\r\n      <div class=\"db-error\">\r\n        <!--<p>{{ bderrorInput.email }}</p>\r\n        <p>{{ bderrorInput.password }}</p>\r\n        <p>{{ bderrorInput.name }}</p>\r\n      -->\r\n      </div>\r\n      <button type=\"submit\" class=\"btn-register\" [disabled]=\"!registerForm.valid\">\r\n        Register\r\n      </button>\r\n\r\n    </form>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n\t<button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./user.service */ "./src/app/login/user.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var LoginComponent = /** @class */ (function () {
    //constructor(private formBuilder: FormBuilder) { },
    function LoginComponent(userService, router) {
        this.userService = userService;
        this.router = router;
        this.registerRepeatPasswordtxt = '';
        // @Input() loginCheck : boolean = true;
        // @Input() logoutCheck : boolean = false;
        // userName = 'Harsha';
        // userPassword = '';
        this.loginerrorInput = '';
        this.registererrorInput = '';
        this.registerNameCheck = '';
        this.registerEmailCheck = '';
        this.registerPasswordCheck = '';
        this.registerUnexpectedError = '';
        this.loginEmailCheck = '';
        this.loginPasswordCheck = '';
        //config ='';
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.loginValueCheck = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ;
    LoginComponent.prototype.ngOnInit = function () {
        this.createLoginFormControls();
        this.createLoginForm();
        this.createRegisterFormControls();
        this.createRegisterForm();
        //this.loginCheck
        // alert("Hi");
    };
    LoginComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    LoginComponent.prototype.createLoginFormControls = function () {
        this.userEmail = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
        ]);
        this.userPassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(8)
        ]);
    };
    LoginComponent.prototype.createRegisterFormControls = function () {
        this.registerName = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required);
        this.registerEmail = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
        ]);
        this.registerPassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(8)
        ]);
        this.registerRepeatPassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(8),
        ]);
    };
    LoginComponent.prototype.createLoginForm = function () {
        this.loginForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            userEmail: this.userEmail,
            userPassword: this.userPassword
        });
    };
    LoginComponent.prototype.createRegisterForm = function () {
        this.registerForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            registerName: this.registerName,
            registerEmail: this.registerEmail,
            registerPassword: this.registerPassword,
            registerRepeatPassword: this.registerRepeatPassword
        }, this.passwordMatchValidator);
    };
    // ,[this.passwordMatchValidator]
    LoginComponent.prototype.passwordMatchValidator = function (g) {
        return g.get('registerPassword').value === g.get('registerRepeatPassword').value
            ? null : { 'mismatch': true };
    };
    LoginComponent.prototype.login = function () {
        var _this = this;
        this.userService.loginUser(this.loginForm.value).subscribe(function (resposne) {
            // alert("Welcome "+resposne.name),
            // console.log(resposne);
            _this.logoutCheck = true;
            _this.loginCheck = false;
            //localStorage.setItem('Token', JSON.stringify(resposne)),
            //window.sessionStorage.setItem('user',"true");
            // this.router.navigate(['\image-classifier']);
            if (resposne.token) {
                //alert("logincheck: "+this.loginCheck+" logoutcheck: "+this.logoutCheck);
                sessionStorage.setItem('currentUser', JSON.stringify(resposne));
                sessionStorage.setItem('userToken', JSON.stringify(resposne.token));
                _this.loginValueCheck.emit(true);
                _this.loginForm.setValue({ userEmail: '', userPassword: '' });
                _this.close();
            }
            //const keys = resposne.keys();
            //this.headers = keys.map(key => '${key}: ${response.headers.get(key)}')
        }, function (err) {
            console.log(err);
            if (err.error.email) {
                alert(err.error.email);
                _this.loginEmailCheck = err.error.email;
            }
            else if (err.error.password) {
                alert(err.error.password);
                _this.loginPasswordCheck = err.error.password;
            }
            else
                alert("Unexpected Error. Please try again!!");
            /*
            this.loginerrorInput=err.error;
            switch(err.error){
              case err.error.email:
                  this.loginEmailCheck = err.error.email;
                  break;
              case err.error.password:
                  this.loginPasswordCheck = err.error.password;
                  break;
              default:
                  alert("Unexpected Error Please Try Again !!!");
                  this.loginPasswordCheck = "wrong passworddddd !!!";
            }
            */
        });
        //console.log(this.loginForm.value);
        //this.close();
    };
    LoginComponent.prototype.register = function () {
        var _this = this;
        //console.log(this.registerForm.value);
        this.userService.registerUser(this.registerForm.value).subscribe(function (resposne) {
            alert("Welcome " + resposne.name),
                console.log(resposne);
            _this.logoutCheck = true;
            _this.loginCheck = false;
            // this.router.navigate(['\image-classifier']);
            if (resposne.token) {
                //alert("logincheck: "+this.loginCheck+" logoutcheck: "+this.logoutCheck);
                sessionStorage.setItem('currentUser', JSON.stringify(resposne));
                window.sessionStorage.setItem('userToken', JSON.stringify(resposne.token));
                _this.loginValueCheck.emit(true);
                //this.loginForm.setValue({userEmail:'', userPassword:''});
                _this.close();
            }
            //alert("User "+resposne.name+" is createda")
        }, function (err) {
            console.log(err);
            if (err.error.name) {
                alert(err.error.name);
                _this.registerNameCheck = err.error.name;
            }
            if (err.error.email) {
                alert(err.error.email);
                //this.registerEmailCheck = err.error.email;
                _this.registerEmailCheck = "Email must be unique";
            }
            if (err.error.password) {
                alert(err.error.password);
                _this.registerPasswordCheck = err.error.password;
            }
            /*
            this.registererrorInput=err.error;
            switch(err.error){
              case err.error.email:
                  this.registerEmailCheck = "Email must be unique";
                  break;
              case err.error.password:
                  this.registerPasswordCheck = err.error.password;
                  break;
              case err.error.name:
                  this.registerNameCheck = err.error.name;
                  break;
              default:
                  //this.registerUnexpectedError = "Unexpected Error. Please Try Again..";
                  alert("Unexpected Error Please Try Again !!!");
            }
            */
            //this.arr=err.error,
            //alert(err.error)
            /*
            if (err.error.email) {
              // we never seem to get here
              //alert("email: "+err.error.email)
              this.bderrorInput=err.error.email
              //console.log(err.error.email);
            }
            else if (err.error.password) {
              //alert(err.error.password)
              this.bderrorInput=err.error.password
              //console.log(err.error.email);
            }
            else if (err.error.username) {
              //alert("Username: "+err.error.username)
              //this.bderrorInput=err.error.username
              //console.log(err.error.email);
            }
            else if (err.error.name) {
              //alert("Username: "+err.error.first_name)
              this.bderrorInput=err.error.name
              //console.log(err.error.email);
            }
            else {
              // no network connection, HTTP404, HTTP500, HTTP200 & invalid JSON
              alert("Something is wrong. Please Try again!!")
              //console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
            }
            */
        });
        //console.log(this.registerPassword.value);
        //this.close();
    };
    LoginComponent.prototype.clearLoginPassword = function () {
        console.log("input password Touched");
        this.loginPasswordCheck = '';
    };
    LoginComponent.prototype.clearLoginEmail = function () {
        console.log("input email Touched");
        this.loginEmailCheck = '';
    };
    LoginComponent.prototype.clearRegisterEmail = function () {
        console.log("input email Touched");
        this.registerEmailCheck = '';
    };
    LoginComponent.prototype.clearRegisterPassword = function () {
        console.log("input email Touched");
        this.registerPasswordCheck = '';
    };
    LoginComponent.prototype.clearRegisterName = function () {
        console.log("input email Touched");
        this.registerNameCheck = '';
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], LoginComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], LoginComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])('loginValueCheck'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], LoginComponent.prototype, "loginValueCheck", void 0);
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")],
            providers: [_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        })
        // @Injectable()
        ,
        __metadata("design:paramtypes", [_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/login/user.service.ts":
/*!***************************************!*\
  !*** ./src/app/login/user.service.ts ***!
  \***************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
        this.address = 'http://127.0.0.1:8081';
    }
    UserService.prototype.registerUser = function (userData) {
        return this.http.post(this.address + '/accounts/register/', userData);
        //.pipe(catchError(this.handleError));
    };
    UserService.prototype.loginUser = function (userData) {
        return this.http.post(this.address + '/accounts/user/login/', userData);
        //.pipe(catchError(this.handleError));
    };
    UserService.prototype.logoutUser = function () {
        //let headers = new HttpHeaders();
        //headers.set('Authorization', "token "+JSON.parse(sessionStorage.getItem('user')).token);
        //headers.append('token', JSON.parse(sessionStorage.getItem('user')).token);
        //alert(JSON.parse(sessionStorage.getItem('currentUser')).token)
        //alert(headers);
        return this.http.get(this.address + '/accounts/user/logout/', { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().set('Authorization', "token " + JSON.parse(sessionStorage.getItem('currentUser')).token) });
        //return this.http.get('http://127.0.0.1:8080/accounts/user/logout/', {headers});
    };
    UserService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/performance-comparison-graph/performance-comparison-graph.component.css":
/*!*****************************************************************************************!*\
  !*** ./src/app/performance-comparison-graph/performance-comparison-graph.component.css ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.performance-comparisongraph-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -285px 0px 0px -550px;\r\n  /* min-height: 200px; */\r\n  /* width: 90%; */\r\n  min-width: 350px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.performancegraphcomp-wrap{\r\n  width: 1100px;\r\n}\r\n\r\ncanvas{\r\n\t\t\t-moz-user-select: none;\r\n\t\t\t-webkit-user-select: none;\r\n\t\t\t-ms-user-select: none;\r\n\t\t}\r\n\r\n.chartjs-tooltip {\r\n\t\t\topacity: 1;\r\n\t\t\tposition: absolute;\r\n\t\t\tbackground: rgba(0, 0, 0, .7);\r\n\t\t\tcolor: white;\r\n\t\t\tborder-radius: 3px;\r\n\t\t\ttransition: all .1s ease;\r\n\t\t\tpointer-events: none;\r\n\t\t\t-webkit-transform: translate(-50%, 0);\r\n\t\t\ttransform: translate(-50%, 0);\r\n\t\t\tpadding: 4px;\r\n\t\t}\r\n\r\n.chartjs-tooltip-key {\r\n\t\t\tdisplay: inline-block;\r\n\t\t\twidth: 10px;\r\n\t\t\theight: 10px;\r\n\t\t}"

/***/ }),

/***/ "./src/app/performance-comparison-graph/performance-comparison-graph.component.html":
/*!******************************************************************************************!*\
  !*** ./src/app/performance-comparison-graph/performance-comparison-graph.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog performance-comparisongraph-bg\">\r\n  <div class=\"performancegraphcomp-wrap\" >\r\n    <!-- <div class=\"interpretabilitysetting-header\">Interpretability Settings</div> -->\r\n    <div class=\"modelinference-graph\">\r\n      <canvas baseChart\r\n        [datasets]=\"mInferData\"\r\n        [labels]=\"mInferLabel\"\r\n        [chartType]=\"doughnutChartType\"\r\n        [options]=\"ChartOptions\"\r\n        [plugins]=\"doughnutChartPlugins\"\r\n        [legend]=\"barChartLegend\"\r\n        >\r\n      </canvas>\r\n      <!-- <div class=\"chartjs-tooltip\" id=\"tooltip-0\"></div>\r\n\t\t<div class=\"chartjs-tooltip\" id=\"tooltip-1\"></div> -->\r\n</div>\r\n\r\n  </div>\r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>"

/***/ }),

/***/ "./src/app/performance-comparison-graph/performance-comparison-graph.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/performance-comparison-graph/performance-comparison-graph.component.ts ***!
  \****************************************************************************************/
/*! exports provided: PerformanceComparisonGraphComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerformanceComparisonGraphComponent", function() { return PerformanceComparisonGraphComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.piecelabel.js */ "./node_modules/chart.piecelabel.js/src/Chart.PieceLabel.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! chartjs-plugin-datalabels */ "./node_modules/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.js");
/* harmony import */ var chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var PerformanceComparisonGraphComponent = /** @class */ (function () {
    function PerformanceComparisonGraphComponent() {
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.mInferLabel = [];
        this.mInferData = [];
        //@Input() public mInferLabel = []
        // @Input() chartData: any[];  
        //public mInferLabel = ['Load the model', 'Pre_process a batch of 64 images', 'Predict a batch of 64 images'];
        //   public doughnutChartData = [
        //   { data: [1, 2, 3], label: 'Project 1' },
        //   { data: [4, 5, 6], label: 'Incetionv3' },
        //   { data: [7, 8, 9], label: 'TrafficSign' },
        // ];
        this.doughnutChartType = 'bar';
        this.ChartOptions = {
            responsive: true,
            scaleShowValues: true,
            //    tooltips: {
            //            callbacks: {
            //                label: function(tooltipItem, data) {
            //                    var label = data.datasets[tooltipItem.datasetIndex].label || '';
            //
            //                    if (label) {
            //                        label += ': ';
            //                    }
            //                    //label += Math.round(tooltipItem.yLabel * 100) / 100;
            //                    return label;
            //                }
            //            }
            //        },
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    font: {
                        size: 12,
                    }
                }
            },
            //         tooltips: {
            // 					mode: 'index',
            // 					callbacks: {
            // 						// Use the footer callback to display the sum of the items showing in the tooltip
            //             label: function(tooltipItem, data) {
            //                     var label = data.datasets[tooltipItem.datasetIndex].label || '';
            //                     if (label) {
            //                         label += ': ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
            //                     }
            //                     //label += Math.round(tooltipItem.yLabel * 100) / 100;
            //                     return label;
            //                 },
            // //						footer: function(tooltipItems, data) {
            // //							var sum = 0;
            // //
            // //							tooltipItems.forEach(function(tooltipItem) {
            // //								sum += data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
            // //							});
            // //							return 'Sum: ' + sum;
            // //						},
            // 					},
            // //					footerFontStyle: 'normal'
            // 				},
            scales: {
                yAxes: [{
                        ticks: {
                            beginAtZero: true
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Time taken (in sec)'
                        }
                    }],
                xAxes: [{
                        ticks: {
                            autoSkip: false
                        },
                        scaleLabel: {
                            display: true,
                            labelString: ''
                        }
                    }]
            }
        };
        this.barChartLegend = true;
        this.doughnutChartPlugins = [chartjs_plugin_datalabels__WEBPACK_IMPORTED_MODULE_3__];
    }
    PerformanceComparisonGraphComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    PerformanceComparisonGraphComponent.prototype.ngOnInit = function () {
    };
    PerformanceComparisonGraphComponent.prototype.ngOnChanges = function (changes) {
        // console.log("mInferData ----- ",this.mInferData)
        // console.log("mInferLabel ----- ",this.mInferLabel)
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceComparisonGraphComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], PerformanceComparisonGraphComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], PerformanceComparisonGraphComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceComparisonGraphComponent.prototype, "mInferLabel", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceComparisonGraphComponent.prototype, "mInferData", void 0);
    PerformanceComparisonGraphComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-performance-comparison-graph',
            template: __webpack_require__(/*! ./performance-comparison-graph.component.html */ "./src/app/performance-comparison-graph/performance-comparison-graph.component.html"),
            styles: [__webpack_require__(/*! ./performance-comparison-graph.component.css */ "./src/app/performance-comparison-graph/performance-comparison-graph.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [])
    ], PerformanceComparisonGraphComponent);
    return PerformanceComparisonGraphComponent;
}());



/***/ }),

/***/ "./src/app/performance-graph/performance-graph.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/performance-graph/performance-graph.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: rgba(0, 0, 0, 0.5);\r\n  z-index: 999;\r\n}\r\n\r\n.performancegraph-bg{\r\n  background: #fff;\r\n  background-size: cover;\r\n  font-family: 'Rubik', sans-serif;\r\n  color: rgba(0,0,0,.87);\r\n  position:relative;\r\n}\r\n\r\n.dialog {\r\n  z-index: 1000;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -285px 0px 0px -550px;\r\n   min-height: 570px; \r\n  /* width: 90%; */\r\n  min-width: 1100px;\r\n  padding: 10px;\r\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\r\n}\r\n\r\n/* @media (min-width: 768px) {\r\n  .dialog {\r\n    top: 40px;\r\n  }\r\n} */\r\n\r\n.dialog__close-btn {\r\n  border: 0;\r\n  background: none;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: absolute;\r\n  top: 8px;\r\n  right: 8px;\r\n  font-size: 1.2em;\r\n  z-index: 999;\r\n  cursor: pointer;\r\n}\r\n\r\n.performancegraph-wrap-modelinference{\r\n  width: 1100px;\r\n}\r\n\r\n.performancegraph-wrap-layersoutput{\r\n  width: 1100px;\r\n}\r\n\r\n.performancegraph-wrap-modelinference a, .performancegraph-wrap-layersoutput a{\r\n  font-size: 12px;\r\n  display:inline-block;\r\n  float: right;\r\n  cursor: pointer;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.9);\r\n  padding: 5px 10px;\r\n}\r\n\r\n.download-detailed-info{\r\n    float: left;\r\n    margin: 2px 0px 0px 0px;\r\n    \r\n}\r\n\r\n.download-detailed-info a{\r\n     text-decoration: none; \r\n    color: rgba(255, 255, 255, 0.9);\r\n}\r\n\r\ninput[type=number]::-webkit-inner-spin-button,\r\ninput[type=number]::-webkit-outer-spin-button {\r\n  -webkit-appearance: none;\r\n  margin: 0;\r\n}\r\n\r\n.search-hero {\r\n  max-width: 640px;\r\n  padding-bottom: 50px;\r\n  margin:auto;\r\n}\r\n\r\n.form-control {\r\n  box-shadow: 0 10px 40px 0 #B0C1D9;\r\n  width: 100%;\r\n  height: 34px;\r\n  font-family: 'Rubik', sans-serif;\r\n  font-size: 14px;\r\n  padding: 6px 12px;\r\n  background: #FFF;\r\n  border: 1px solid #CCC;\r\n  border-radius: 4px;\r\n}\r\n\r\n.form-control::-webkit-input-placeholder  {\r\n  font-family: FontAwesome;\r\n}\r\n\r\n.form-control:-ms-input-placeholder  {\r\n  font-family: FontAwesome;\r\n}\r\n\r\n.form-control::-ms-input-placeholder  {\r\n  font-family: FontAwesome;\r\n}\r\n\r\n.form-control::placeholder  {\r\n  font-family: FontAwesome;\r\n}\r\n\r\n.performance-header-text{\r\n     width: 100%;\r\n    text-align: center;\r\n    font-size: 15px;\r\n    font-weight: 600;\r\n    margin: 0px 0px 10px 0px;\r\n}\r\n\r\n.table-wrap{\r\n/*  padding: 80px 10px 50px 0px;*/\r\n  height:455px;\r\n  overflow: auto;\r\n  margin: 0px 0px 10px 0px;\r\n}\r\n\r\n.table {\r\n    width: 100%;\r\n    max-width: 100%;\r\n    margin-bottom: 20px;\r\n}\r\n\r\n.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th{\r\n border-top: 0px;  \r\nfont-size: 14px; \r\n}\r\n\r\n.table>thead>tr>th{\r\n    vertical-align: bottom;\r\n    border-bottom: 2px solid #ddd;\r\n    text-align: left;\r\n}\r\n\r\n.table-striped>tbody>tr:nth-of-type(odd){\r\n       background-color: #f9f9f9; \r\n}\r\n\r\n.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th{\r\n       padding: 8px;\r\n    line-height: 1.42857143;\r\n    vertical-align: top;\r\n    border-top: 1px solid #ddd; \r\n    font-size: 12px;\r\n}\r\n\r\n.layersoutput-graph{\r\n     position: relative;\r\n}\r\n\r\n.total-time-wrap{\r\n    position: absolute;\r\n    font-size: 14px;\r\n    top: 45px;\r\n    left: 36%;\r\n}\r\n\r\n/* Structure */\r\n\r\ntable {\r\n  width: 100%;\r\n}\r\n\r\ntr.mat-header-row{\r\n     height: auto;   \r\n}\r\n\r\ntable thead tr th{\r\n     padding: 5px;\r\n    font-size: 13px;\r\n}\r\n\r\ntr.mat-footer-row, tr.mat-row{\r\n     height: auto;\r\n}\r\n\r\ntd.mat-cell, td.mat-footer-cell, th.mat-header-cell{\r\n     padding: 10px 5px !important;\r\n    \r\n}\r\n\r\ntd.mat-cell{\r\n     font-size: 12px;   \r\n}\r\n\r\nth.mat-header-cell{\r\n    font-size: 12px;\r\n    padding: 15px 5px !important;\r\n    font-weight: 500;\r\n    background: rgba(0, 0, 0, 0.3);\r\n}\r\n\r\n.mat-form-field {\r\n  font-size: 12px;\r\n  width: 100%;\r\n}\r\n\r\n.performancegraph-wrap-emptmodinference{\r\n text-align: center;\r\n font-size: 16px;\r\n font-weight: 500;\r\n line-height: 570px;\r\n}\r\n"

/***/ }),

/***/ "./src/app/performance-graph/performance-graph.component.html":
/*!********************************************************************!*\
  !*** ./src/app/performance-graph/performance-graph.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog performancegraph-bg\">\r\n  <div *ngIf=\"chartMIData.length>0\">\r\n    <div class=\"performance-header-text\">{{performPNmae}}</div>  \r\n    <div class=\"performancegraph-wrap-modelinference\" *ngIf=\"modelInferenceVisisble\">\r\n      <!-- <div class=\"interpretabilitysetting-header\">Interpretability Settings</div> -->\r\n      <div class=\"modelinference-graph\">\r\n        <canvas baseChart\r\n          [chartType]=\"chartTypeMI\"\r\n          [labels]=\"chartMILabels\"\r\n          [data]=\"chartMIData\"\r\n          [colors]=\"chartMIColors\"\r\n          [options]=\"chartMIOptions\"\r\n          >\r\n  </canvas>\r\n</div>\r\n    <a (click)=\"viewLO()\">View Layers Output</a>\r\n    </div>\r\n  </div>\r\n  <div class=\"performancegraph-wrap-emptmodinference\" *ngIf=\"!chartMIData.length>0\">\r\n      <h1>No information available for Model Inference</h1>\r\n  </div>\r\n\r\n    <div class=\"performancegraph-wrap-layersoutput\" *ngIf=\"layersOutputVisible\">\r\n      <!-- <div class=\"interpretabilitysetting-header\">Interpretability Settings</div> -->\r\n      <div class=\"layersoutput-graph\">\r\n        <div class=\"search-hero\">\r\n      <input class=\"form-control\" type=\"text\" name=\"search\" [(ngModel)]=\"searchText\" autocomplete=\"off\" placeholder=\"&#61442;  Words indicative of a layer in the model (computation graph). For Ex: conv2d_1a_3x3, BatchNorm etc\"  (keyup)=\"applyFilter($event)\">\r\n    </div>\r\n    <div class=\"total-time-wrap\" *ngIf=\"displayTime\">Total time taken: {{ totalTime }} seconds</div>\r\n    <div class=\"table-wrap\">\r\n        <table mat-table [dataSource]=\"dataSource\" class=\"mat-elevation-z8\" matSort>\r\n            <!-- Position Column -->\r\n            <ng-container matColumnDef=\"name\">\r\n              <th mat-header-cell *matHeaderCellDef mat-sort-header title=\"Click to Sort\"> Sub-string in Operation Name </th>\r\n              <td mat-cell *matCellDef=\"let element\"> {{element.name}} </td>\r\n            </ng-container>\r\n          \r\n            <!-- Name Column -->\r\n            <ng-container matColumnDef=\"time\">\r\n              <th mat-header-cell *matHeaderCellDef mat-sort-header title=\"Click to Sort\"> Average Time (in sec) taken by operations starting with Sub-string </th>\r\n              <td mat-cell *matCellDef=\"let element\" class=\"time-wrap\"> {{element.time}} </td>\r\n            </ng-container>\r\n            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\r\n            <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\r\n          </table>    \r\n    </div>\r\n</div>\r\n   <div class=\"download-detailed-info\"><a href=\"{{ detailedinfoCSVlink }}\" download>Download Detailed Info CSV</a></div>\r\n    <a (click)=\"viewMI()\">View Model inference</a>\r\n    </div>\r\n    \r\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\"><i class=\"fa fa-times\"></i></button>\r\n</div>\r\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\r\n"

/***/ }),

/***/ "./src/app/performance-graph/performance-graph.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/performance-graph/performance-graph.component.ts ***!
  \******************************************************************/
/*! exports provided: PerformanceGraphComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerformanceGraphComponent", function() { return PerformanceGraphComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-malihu-scrollbar */ "./node_modules/ngx-malihu-scrollbar/fesm5/ngx-malihu-scrollbar.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! chart.piecelabel.js */ "./node_modules/chart.piecelabel.js/src/Chart.PieceLabel.js");
/* harmony import */ var chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(chart_piecelabel_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var PerformanceGraphComponent = /** @class */ (function () {
    function PerformanceGraphComponent(elRef, mScrollbarService) {
        var _this = this;
        this.elRef = elRef;
        this.mScrollbarService = mScrollbarService;
        this.modelInferenceVisisble = true;
        this.layersOutputVisible = false;
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.chartTypeMI = 'doughnut';
        this.chartMIData = [];
        this.chartMILabels = [];
        this.chartMIColors = [{
                backgroundColor: [
                    'rgba(107, 202, 226, 0.98)', 'rgba(65, 147, 75, 0.98)', 'rgba(254, 132, 3, 0.98)'
                ]
            }];
        this.chartMIOptions = {
            responsive: true,
            tooltips: {
                displayColors: false,
                callbacks: {
                    label: (function (tooltipItem) {
                        var index = tooltipItem.index;
                        var label = _this.chartMILabels[index];
                        return label;
                    })
                }
            },
        };
        this.chartTypeLO = 'bar';
        this.chartLOLabels = [];
        this.chartLOlabelsAfterChange = [];
        this.chartLODataAfterChange = [];
        this.reportNotFound = '';
        this.displayTime = false;
        this.chartLOData = [];
        this.displayedColumns = ['name', 'time'];
        elRef.nativeElement.ownerDocument.body.style.overflowY = 'scroll';
    }
    PerformanceGraphComponent.prototype.ngOnInit = function () {
        //this.dataSource.sort = this.sort;
    };
    PerformanceGraphComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        $(".table-wrap").mCustomScrollbar({
            scrollButtons: { enable: false },
            theme: "dark-thin",
            autoHideScrollbar: true,
            scrollbarPosition: "inside"
        });
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.table-wrap', { axis: 'y', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 2);
        //this.dataSource.sort = this.sort;
    };
    PerformanceGraphComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
        this.viewMI();
        this.searchText = '';
    };
    PerformanceGraphComponent.prototype.viewLO = function () {
        var _this = this;
        //this.getTotal();
        this.modelInferenceVisisble = false;
        this.layersOutputVisible = true;
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.table-wrap', { axis: 'y', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
            _this.dataSource.sort = _this.sort;
        }, 2);
    };
    // selected_layers(timeInSeconds: NgModel){
    //   console.log("time in seconds -- ", timeInSeconds.value)
    //   this.timeinSec = timeInSeconds.value
    //   this.minTimeRangeInSec = ""
    //   this.maxTimeRangeInSec = ""
    //   this.chartLOLabels = [];
    //   this.chartLOData = []
    //   let chartData = []
    //   for(let k=0; k<this.chartLODataAfterChange.length; k++){
    //       if(this.chartLODataAfterChange[k]<= timeInSeconds.value){
    //         this.chartLOLabels.push(this.chartLOlabelsAfterChange[k])
    //         chartData.push(this.chartLODataAfterChange[k])
    //     }
    //   }
    //   this.chartLOData = [{data: chartData, label:'Model Layers (time in sec)'}]
    //   //this.chart.chart.config.data.labels = this.chartLOLabels
    //   //this.chart.chart.config.data.datasets = this.chartLOData
    //   //this.chart.chart.update()
    //     setTimeout(() => {
    //         this.chart.refresh()
    //     }, 10);
    // }
    // downloadAsCsv(){
    //   //this.chartLOData=[{data:[]}]
    //   if(this.chartLOData[0].data.length>0){
    //   let tempData = []
    //   let jsonArray = {}
    //   for(let i=0; i<this.chartLOData[0].data.length; i++){
    //     jsonArray = {
    //       "OpName": this.chartLOLabels[i],
    //       "Average time in seconds": this.chartLOData[0].data[i]
    //     }
    //     tempData.push(jsonArray)
    //   }
    //   const replacer = (key, value) => value === null ? '' : value; // specify how you want to handle null values here
    //   const header = Object.keys(tempData[0]);
    //   let csv = tempData.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','));
    //   csv.unshift(header.join(','));
    //   let csvArray = csv.join('\r\n');
    //   var blob = new Blob([csvArray], {type: 'text/csv' })
    //   saveAs(blob, "myFile.csv");
    // }
    // else{
    //   this.reportNotFound = "No results found!!"
    // }
    // }
    // clearError(){
    //   this.reportNotFound=''
    // }
    // selectLayersInRange(min: NgModel, max: NgModel){
    //   this.chartLOLabels = [];
    //   this.chartLOData = []
    //   let chartData = []
    //   this.minTimeRangeInSec = min.value
    //   this.maxTimeRangeInSec = max.value
    //   this.timeinSec = ""
    //   for(let i=0; i<this.chartLODataAfterChange.length; i++){
    //     if(this.chartLODataAfterChange[i]>=min.value && this.chartLODataAfterChange[i]<max.value){
    //       this.chartLOLabels.push(this.chartLOlabelsAfterChange[i])
    //       chartData.push(this.chartLODataAfterChange[i])
    //     }
    //   }
    //   this.chartLOData = [{data:chartData, label:'Model Layers (time in sec)'}]
    //   setTimeout(() => {
    //     this.chart.refresh()
    // }, 10);
    // }
    //dataSource = new MatTableDataSource(this.cData);
    //private dataSource
    // ngDoCheck() {
    //   const change = this.differ.diff(this);
    //   if (change) {
    //     change.forEachChangedItem(item => {
    //       // console.log('item key', item.key);
    //       console.log("item value --- ",item)
    //       if((item.key=='searchText' || item.key=='totalTime') && String(item.currentValue).includes('/')){
    //         setTimeout(()=>{    //<<<---    using ()=> syntax
    //           var total = 0; 
    //           let elements = [];
    //           elements = this.elRef.nativeElement.querySelectorAll('.time-wrap');
    //       for (var i = 0; i < elements.length; i++) {
    //           total += parseFloat(elements[i].innerText);
    //       }
    //       this.totalTime = total; 
    //       this.displayTime = true;
    //        }, 2); 
    //         console.log("total time --- ", this.totalTime)
    //       }
    //       else if(item.key=='searchText' && !item.currentValue.includes('/')){
    //         this.displayTime = false;
    //       }
    //     });
    //   }
    // }
    PerformanceGraphComponent.prototype.ngOnChanges = function (changes) {
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_6__["MatTableDataSource"](this.chartLOData);
        //console.log("searchText --- ",this.searchText)
        // this.dataSource.sort = this.sort;
        // //this.chartMILabels = []
        // //this.chartLOLabels = []
        // console.log("change is happened----")
        // this.chartLOData = []
        // //this.chartLOlabelsAfterChange = []
        // //this.chartLODataAfterChange = []
        // let splitCData = []
        // // for (let i=0; i<this.chartMIData.length; i++){
        // //   this.chartMILabels[i] = this.chartMILabels[i]+this.chartMIData[i]
        // //   console.log('chartMILabels -- ', this.chartMILabels)
        // // }
        // for(let j=1; j<this.wholeChartData.length; j++){
        //   if(this.wholeChartData){
        //     splitCData = this.wholeChartData[j].split(',')
        //     // this.chartLOLabels.push(splitCData[0])
        //     // chartData.push(splitCData[1])
        //     // this.chartLOlabelsAfterChange.push(splitCData[0])
        //     // this.chartLODataAfterChange.push(splitCData[1])
        //     this.chartLOData.push({name:splitCData[0], time: splitCData[1]})
        //   }
        // }
        // //this.chartLOData = [{data: chartData, label:'Model Layers (time in sec)'}]
        // console.log("chart Data -- ", this.chartLOData)
    };
    PerformanceGraphComponent.prototype.viewMI = function () {
        //this.dataSource.sort = this.sort;
        this.layersOutputVisible = false;
        this.modelInferenceVisisble = true;
    };
    PerformanceGraphComponent.prototype.applyFilter = function ($event) {
        var _this = this;
        this.dataSource.filter = $event.target.value.trim().toLowerCase();
        this.displayTime = false;
        if ($event.target.value.includes("/")) {
            //console.log("Event key is ........",$event)
            setTimeout(function () {
                var total = 0;
                var elements = [];
                elements = _this.elRef.nativeElement.querySelectorAll('.time-wrap');
                for (var i = 0; i < elements.length; i++) {
                    total += parseFloat(elements[i].innerText);
                }
                _this.totalTime = total;
            }, 2);
            this.displayTime = true;
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(ng2_charts__WEBPACK_IMPORTED_MODULE_2__["BaseChartDirective"]),
        __metadata("design:type", Object)
    ], PerformanceGraphComponent.prototype, "chart", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceGraphComponent.prototype, "closable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], PerformanceGraphComponent.prototype, "visible", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], PerformanceGraphComponent.prototype, "visibleChange", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceGraphComponent.prototype, "chartMIData", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], PerformanceGraphComponent.prototype, "chartMILabels", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], PerformanceGraphComponent.prototype, "performPNmae", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceGraphComponent.prototype, "chartLOData", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"]),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"])
    ], PerformanceGraphComponent.prototype, "sort", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PerformanceGraphComponent.prototype, "detailedinfoCSVlink", void 0);
    PerformanceGraphComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-performance-graph',
            template: __webpack_require__(/*! ./performance-graph.component.html */ "./src/app/performance-graph/performance-graph.component.html"),
            styles: [__webpack_require__(/*! ./performance-graph.component.css */ "./src/app/performance-graph/performance-graph.component.css")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_3__["MalihuScrollbarService"]])
    ], PerformanceGraphComponent);
    return PerformanceGraphComponent;
}());



/***/ }),

/***/ "./src/app/text-classifier/text-classifier.component.css":
/*!***************************************************************!*\
  !*** ./src/app/text-classifier/text-classifier.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ::ng-deep .fp-enabled{\r\n  height: auto !important;\r\n  overflow-y: scroll !important;\r\n}\r\n\r\n\r\n/*\r\n body.fp-viewing-1{\r\n  height: auto !important;\r\n  overflow-y: scroll !important;\r\n} \r\n*/\r\n\r\n\r\n.insidepage-container{\r\n  margin: 0px 0px 0px 0px;\r\n  padding: 40px 0px 12px 0px;\r\n}\r\n\r\n\r\n.insidepage-container {\r\n  width: 100%;\r\n  height: 100%;\r\n  /* border: 1px solid rgba(0, 0, 0, 0.5); */\r\n\r\n}\r\n\r\n\r\n.insidepage-sidenav-content {\r\n  width: 100%;\r\n  display: flex;\r\n  height: 100%;\r\n  align-items: center;\r\n  /* justify-content: center; */\r\n}\r\n\r\n\r\n.insidepage-sidenav {\r\n  padding: 80px 10px 50px 0px;\r\n  height:100vh;\r\n  position: fixed;\r\n  background: rgba(255, 255, 255, 0.8);\r\n  /* border-right: rgba(20, 157, 204, 0.98) solid 1px; */\r\n}\r\n\r\n\r\n.img-classifier-wrap{\r\n  background: rgba(255, 255, 255, 0.96);\r\n}\r\n\r\n\r\n.btn-menu{\r\n  /* position: absolute; */\r\n  position: static;\r\n  min-width: 40px;\r\n  padding: 0 10px;\r\n}\r\n\r\n\r\n.sidenav-cont-header span{\r\n  display: block;\r\n  margin: 10px 0px 15px 10px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 20px;\r\n  font-weight: 500;\r\n  float: left;\r\n}\r\n\r\n\r\n.sidenav-cont-header a{\r\n  display: block;\r\n  margin: 15px 10px 30px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 25px;\r\n  float: right;\r\n}\r\n\r\n\r\n.sidenav-select-project a{\r\n  display: block;\r\n  margin: 8px 0px 2px 10px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  float: right;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.sidenav-cont-header a i{\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.sidenav-cont-wrap{\r\n  margin: 0px 0px 0px 10px;\r\n  position: relative;\r\n}\r\n\r\n\r\n/* .sidenav-cont-wrap span{\r\n  display: block;\r\n  margin: 10px 0px 10px 0px;\r\n  color: rgb(0, 0, 0);\r\n  font-size: 14px;\r\n} */\r\n\r\n\r\n.sidenav-cont-wrap input{\r\n  width: 200px;\r\n  font-size: 14px;\r\n  font-weight: 400;\r\n  padding: 5px 2px;\r\n}\r\n\r\n\r\n/* .sidenav-cont-wrap i{\r\n  position: absolute;\r\n  top: 30px;\r\n  left: 180px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  cursor: pointer;\r\n} */\r\n\r\n\r\n.sidenav-cont-input{\r\n  position: relative;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n/* .sidenav-cont-input input{\r\n  width: 290px;\r\n  font-size: 14px;\r\n  font-weight: 400;\r\n  padding: 5px 2px;\r\n\r\n} */\r\n\r\n\r\n.form-control-validation{\r\n  font-size: 12px;\r\n  color: rgba(204, 7, 5, 0.98);\r\n  position: absolute;\r\n  left: 0px;\r\n  bottom: -2px;\r\n}\r\n\r\n\r\n.custom-upload-btn{\r\n\r\n}\r\n\r\n\r\ndiv.custom-upload-btn{\r\n  width: auto;\r\n  display: inline-flex;\r\n  margin: 0px 0px 0px 5px;\r\n}\r\n\r\n\r\ndiv .custom-upload-btn label{\r\n  width: auto;\r\n}\r\n\r\n\r\n.custom-upload-btn label{\r\n    padding: 7px 15px;\r\n    background: rgba(20, 157, 204, 0.98);\r\n    display: table;\r\n    color: #fff;\r\n\r\n}\r\n\r\n\r\n.custom-upload-btn input[type=\"file\"] {\r\n    display: none;\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap{\r\n\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap button{\r\n    display: inline-block;\r\n    color: #fff;\r\n    padding: 7px 15px;\r\n    background: rgba(20, 157, 204, 0.98);\r\n    margin: 0px 5px 0px 0px;\r\n    font-size: 14px;\r\n    font-weight: 400;\r\n    border: none;\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap button:disabled{\r\n    background: rgba(20, 157, 204, 0.5);\r\n}\r\n\r\n\r\n.sidenav-cont-settings-wrap i{\r\n    color: #fff;\r\n    font-size: 18px;\r\n}\r\n\r\n\r\n.sidenav-select-project, .sidenav-select-benchmark{\r\n  margin: 0px 0px 10px 10px;\r\n}\r\n\r\n\r\n.sidenav-select-project span, .sidenav-select-benchmark span{\r\n  display: inline-block;\r\n  margin: 0px 0px 5px 0px;\r\n  font-size: 13px;\r\n}\r\n\r\n\r\n.sidenav-select-project select, .sidenav-select-benchmark select {\r\n    width: 240px;\r\n    height: 28px;\r\n    font-size: 13px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n\r\n.sidenav-select-project select option{\r\n  margin: 2px 0px 2px 0px;\r\n}\r\n\r\n\r\n.sidenav-select-project select option span{\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.sidenav-comparewrap-header{\r\n  margin: 5px 0px 10px 10px;\r\n}\r\n\r\n\r\n.sidenav-comparewrap-header span{\r\n  font-size: 16px;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.compare-proj-wrap{\r\n  width: 230px;\r\n  margin: 0px 0px 0px 10px;\r\n}\r\n\r\n\r\n/* Compare check box */\r\n\r\n\r\n.container-radiobtn {\r\n  display: block;\r\n  position: relative;\r\n  padding:2px 0px 0px 23px;\r\n  margin:0px 10px 15px 0px;\r\n  cursor: pointer;\r\n  font-size: 13px;\r\n  -webkit-user-select: none;\r\n  -moz-user-select: none;\r\n  -ms-user-select: none;\r\n  user-select: none;\r\n  display: inline-block;\r\n  width: 100px;\r\n}\r\n\r\n\r\n/* Hide the browser's default radio button */\r\n\r\n\r\n.container-radiobtn input {\r\n  position: absolute;\r\n  opacity: 0;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n/* Create a custom radio button */\r\n\r\n\r\n.checkmark-radiobtn {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  height: 20px;\r\n  width: 20px;\r\n  background-color: #eee;\r\n  border-radius: 50%;\r\n}\r\n\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n\r\n.container-radiobtn:hover input ~ .checkmark-radiobtn {\r\n  background-color: #ccc;\r\n}\r\n\r\n\r\n/* When the radio button is checked, add a blue background */\r\n\r\n\r\n.container-radiobtn input:checked ~ .checkmark-radiobtn {\r\n  background-color: #2196F3;\r\n}\r\n\r\n\r\n/* Create the indicator (the dot/circle - hidden when not checked) */\r\n\r\n\r\n.checkmark-radiobtn:after {\r\n  content: \"\";\r\n  position: absolute;\r\n  display: none;\r\n}\r\n\r\n\r\n/* Show the indicator (dot/circle) when checked */\r\n\r\n\r\n.container-radiobtn input:checked ~ .checkmark-radiobtn:after {\r\n  display: block;\r\n}\r\n\r\n\r\n/* Style the indicator (dot/circle) */\r\n\r\n\r\n.container-radiobtn .checkmark-radiobtn:after {\r\n \ttop: 6px;\r\n\tleft: 6px;\r\n\twidth: 8px;\r\n\theight: 8px;\r\n\tborder-radius: 50%;\r\n\tbackground: white;\r\n}\r\n\r\n\r\n.compare-submitbtn{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.compare-submitbtn button{\r\n  padding: 7px 15px;\r\n  border:none;\r\n  margin: 0px 0px 0px 10px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.98);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.compare-submitbtn button:disabled{\r\n  background: rgba(204, 204, 204, 0.98);\r\n  color: rgba(130, 130, 130, 0.98);\r\n}\r\n\r\n\r\ninput[type=number]::-webkit-inner-spin-button,\r\ninput[type=number]::-webkit-outer-spin-button {\r\n  -webkit-appearance: none;\r\n  margin: 0;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap{\r\n  margin: 0px 0px 10px 0px;\r\n  /* text-align: center; */\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap label{\r\n  font-size: 13px;\r\n  /* font-weight: 500; */\r\n  width: auto;\r\n  display: inline-block;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap input{\r\n  width: 240px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap p{\r\n  width: 240px;\r\n  float: right;\r\n  font-size: 11px;\r\n  text-align: left;\r\n  margin: 5px 0px\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap  title{\r\n  font-size: 11px;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap select {\r\n    width: 240px;\r\n    height: 28px;\r\n    margin: 0px 0;\r\n    border: 0;\r\n    border: rgba(205, 205, 205, 0.6) solid 1px;\r\n    /* border-top: 4px solid black; */\r\n    background: #fff url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_keyboard_arrow_down_48px-128.png') no-repeat;\r\n    background-size: 20px;\r\n    background-position:  right 5px center;\r\n    font-family: 'Arial';\r\n    padding-left: 5px;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    border-radius: 0px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting{\r\n  margin: 0px 0px 10px 30px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting label{\r\n  font-size: 13px;\r\n  width: auto;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting input{\r\n  width: 150px;\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  padding: 6px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-subsetting select{\r\n  width: 150px;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap button{\r\n  display: inline-block;\r\n  font-size: 15px;\r\n  padding: 5px 20px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  color: rgba(255, 255, 255, 0.96);\r\n  border: none;\r\n  margin: 15px 0px 0px 0px;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.imageclassifiersetting-option-wrap button:disabled{\r\n    background: rgba(20, 157, 204, 0.5);\r\n}\r\n\r\n\r\n.tooltip {\r\n    position: relative;\r\n\r\n}\r\n\r\n\r\n.tooltip .tooltiptext {\r\n    visibility: hidden;\r\n    width: 250px;\r\n    background: rgba(10, 10, 10, 1);\r\n    color: #fff;\r\n    text-align: left;\r\n    border-radius: 6px;\r\n    padding: 5px;\r\n    font-size: 12px;\r\n    line-height: 14px;\r\n    font-weight: 400;\r\n\r\n    /* Position the tooltip */\r\n    position: absolute;\r\n    bottom: 150%;\r\n    left: 50%;\r\n    margin-left: -95px;\r\n    z-index: 1;\r\n    overflow: visible !important;\r\n}\r\n\r\n\r\n.tooltip:hover .tooltiptext {\r\n    visibility: visible;\r\n}\r\n\r\n\r\n.tooltip .tooltiptext::after {\r\n    content: \" \";\r\n    position: absolute;\r\n    top: 100%; /* At the bottom of the tooltip */\r\n    left: 50%;\r\n    margin-left: -5px;\r\n    border-width: 5px;\r\n    border-style: solid;\r\n    border-color: black transparent transparent transparent;\r\n}\r\n\r\n\r\n.checkbox_wrap {\r\n  width: 25px !important;\r\n    display: block;\r\n    position: relative;\r\n    padding: 5px;\r\n    margin: 0px 5px 5px 0px;\r\n    cursor: pointer;\r\n    font-size: 22px;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n}\r\n\r\n\r\n/* Hide the browser's default checkbox */\r\n\r\n\r\n.checkbox_wrap input {\r\n    position: absolute;\r\n    opacity: 0;\r\n    cursor: pointer;\r\n}\r\n\r\n\r\n/* Create a custom checkbox */\r\n\r\n\r\n.checkmark {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    height: 20px;\r\n    width: 20px;\r\n    background-color: #eee;\r\n}\r\n\r\n\r\n/* On mouse-over, add a grey background color */\r\n\r\n\r\n.checkbox_wrap:hover input ~ .checkmark {\r\n    background-color: #ccc;\r\n}\r\n\r\n\r\n/* When the checkbox is checked, add a blue background */\r\n\r\n\r\n.checkbox_wrap input:checked ~ .checkmark {\r\n    background-color: #2196F3;\r\n}\r\n\r\n\r\n/* Create the checkmark/indicator (hidden when not checked) */\r\n\r\n\r\n.checkmark:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    display: none;\r\n}\r\n\r\n\r\n/* Show the checkmark when checked */\r\n\r\n\r\n.checkbox_wrap input:checked ~ .checkmark:after {\r\n    display: block;\r\n}\r\n\r\n\r\n/* Style the checkmark/indicator */\r\n\r\n\r\n.checkbox_wrap .checkmark:after {\r\n    left: 6px;\r\n    top: 2px;\r\n    width: 5px;\r\n    height: 10px;\r\n    border: solid white;\r\n    border-width: 0 3px 3px 0;\r\n    -webkit-transform: rotate(45deg);\r\n    transform: rotate(45deg);\r\n}\r\n\r\n\r\n.info-container {\r\n  padding: 12px 16px;\r\n\r\n  line-height: 24px;\r\n}\r\n\r\n\r\n.action-container,\r\n.content-container {\r\n  position: relative;\r\n\r\n  overflow: auto;\r\n  height: 300px;\r\n  min-height: 0;\r\n  margin: 8px 16px;\r\n  border-radius: 4px;\r\n\r\n  background-color: #fff;\r\n}\r\n\r\n\r\n.action-container {\r\n  padding: 16px;\r\n}\r\n\r\n\r\n.vertical-container,\r\n.horizontal-container {\r\n  min-height: 0 !important;\r\n}\r\n\r\n\r\n.action-button {\r\n  box-sizing: border-box;\r\n  width: calc(100% - 16px);\r\n  min-height: 35px;\r\n  padding: 4px 16px;\r\n  margin: 8px;\r\n  border: 1px solid #555;\r\n  border-radius: 4px;\r\n\r\n  cursor: pointer;\r\n  font-size: 14px;\r\n  font-weight: bold;\r\n  line-height: 14px;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.action-button:hover {\r\n  color: #fff;\r\n  background-color: #555;\r\n}\r\n\r\n\r\n.innerpage-wrap{\r\n  padding: 10px 10px;\r\n  width: 970px;\r\n  margin: 0 auto;\r\n}\r\n\r\n\r\n.innerpage-row{\r\n  padding: 0px 0px 0px 0px;\r\n  background: rgba(205, 205, 205, 0.05);\r\n  border: rgba(205, 205, 205, 0.6) solid 1px;\r\n  text-align: center;\r\n  width: 100%;\r\n  margin: 0px 0px 10px 0px;\r\n}\r\n\r\n\r\n.innerpage-row-col{\r\n  display:inline-block;\r\n  padding: 10px;\r\n  margin: 0.5% 0.5% 0.5% 0.5%;\r\n  float: left;\r\n  background: rgba(255, 255, 255, 0.99);\r\n  border: rgba(205, 205, 205, 0.3) solid 1px;\r\n  min-height: 275px;\r\n  position: relative;\r\n  /* width: 31%; */\r\n  /* -webkit-box-shadow: 0px 0px 112px -8px rgba(0,0,0,1);\r\n  -moz-box-shadow: 0px 0px 112px -8px rgba(0,0,0,1);\r\n  box-shadow: 0px 0px 112px -8px rgba(0,0,0,1); */\r\n}\r\n\r\n\r\n.row-col-left{\r\n  /* background: -webkit-linear-gradient(bottom left, #7fd9fc, #6576aa);\r\n  background: -o-linear-gradient(bottom left, #7fd9fc, #6576aa);\r\n  background: linear-gradient(to top right, #7fd9fc, #6576aa); */\r\n  border: none;\r\n  background: transparent;\r\n  display: table;\r\n  height: 100%;\r\n  width: 100%;\r\n\r\n}\r\n\r\n\r\n.row-col-header{\r\n  width: 100%;\r\n  position: relative;\r\n  margin: 0px 0px 10px 0px;\r\n}\r\n\r\n\r\n.row-col-header span{\r\n  display: block;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 15px;\r\n  font-size: 500;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.row-col-header span.row-col-header-sub{\r\n  display: block;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 12px;\r\n  font-size: 500;\r\n  text-align: left;\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.row-col-header a{\r\n  position: absolute;\r\n  right: 0px;\r\n  top: 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  font-size: 16px;\r\n}\r\n\r\n\r\n.row-col-header a i{\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.row-col-content{\r\n  margin: 20px 0px 0px 0px;\r\n  padding: 10px 0px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  font-size: 14px;\r\n  line-height: 18px;\r\n  border-top: rgba(20, 157, 204, 0.98) solid 1px;\r\n  border-bottom: rgba(20, 157, 204, 0.98) solid 1px;\r\n}\r\n\r\n\r\n.row-col-left{\r\n  width: 21%;\r\n  /* margin: 170px 0px 0px 0px; */\r\n}\r\n\r\n\r\n.row-col-mid{\r\n  /* background: -webkit-linear-gradient(bottom left, #6576aa, #7fd9fc);\r\n  background: -o-linear-gradient(bottom left, #6576aa, #7fd9fc);\r\n  background: linear-gradient(to top right, #6576aa, #7fd9fc); */\r\n  width: 31%;\r\n  /* float: right; */\r\n  /* min-height: 240px; */\r\n\r\n}\r\n\r\n\r\n.row-col-right{\r\n  width: 78%;\r\n  /* float: right; */\r\n  max-height: 275px;\r\n\r\n\r\n}\r\n\r\n\r\n.col-mid-left{\r\n  width: 33.33%;\r\n  float: left;\r\n}\r\n\r\n\r\n.col-mid-img-cont-wrap{\r\n  /* float: left; */\r\n}\r\n\r\n\r\n.col-mid-left{\r\n  width: 40%;\r\n}\r\n\r\n\r\n.col-mid-mid{\r\n  width: 20%;\r\n  font-size: 30px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  position: relative;\r\n  min-height: 215px;\r\n  float: left;\r\n}\r\n\r\n\r\n.col-mid-mid i{\r\n  position: absolute;\r\n  top: 70%;\r\n  left: 50%;\r\n  margin: -15px 0 0 -15px;\r\n}\r\n\r\n\r\n.col-mid-right{\r\n  width: 40%;\r\n  float: right;\r\n}\r\n\r\n\r\n.col-mid-img-wrap{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.col-mid-img-cont-wrap p{\r\n  font-size: 12px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  min-height: 90px;\r\n  text-align: left;\r\n}\r\n\r\n\r\n.col-mid-img-wrap img{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-matrix-content{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-matrix-content img{\r\n  width: 100%;\r\n}\r\n\r\n\r\n.row-col-right{\r\n  /* padding: 0px; */\r\n/*  overflow-y: scroll;*/\r\n    position: relative;\r\n}\r\n\r\n\r\n.col-right-table-wrap{\r\n  width: 100%;\r\n  color: rgba(84, 84, 84, 0.95);\r\n}\r\n\r\n\r\n.col-right-table-wrap table{\r\n  table-layout:fixed;\r\n}\r\n\r\n\r\n.col-right-table-wrap th{\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  padding: 5px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  text-align: center;\r\n  white-space:nowrap;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap th:first-child{\r\n  text-align: left;\r\n}\r\n\r\n\r\n.col-right-table-wrap th{\r\n  cursor:default;\r\n}\r\n\r\n\r\n.col-right-table-wrap td{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  padding: 5px;\r\n  word-wrap:break-word;\r\n  white-space:nowrap;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap td:first-child{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  white-space:nowrap;\r\n  text-align: left;\r\n  font-weight: 600;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap{\r\n  margin: 20px 0px 0px 0px;\r\n  color: rgba(84, 84, 84, 0.95);\r\n}\r\n\r\n\r\n.col-right-table-header-wrap table{\r\n  table-layout:fixed;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap th{\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  padding: 5px;\r\n  text-align: left;\r\n  word-wrap:break-word;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-header-wrap th:first-child{\r\n  color: rgba(20, 157, 204, 0.98);\r\n}\r\n\r\n\r\n.col-right-table-header-wrap td{\r\n  font-size: 12px;\r\n  padding: 5px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  text-align: left;\r\n  font-weight: 600;\r\n  border: rgba(205, 205, 205, 0.4) solid 1px;\r\n}\r\n\r\n\r\n.col-right-table-wrap td:first-child{\r\n  font-size: 12px;\r\n  font-weight: 400;\r\n  word-wrap:break-word;\r\n  text-align: left;\r\n  font-weight: 600;\r\n}\r\n\r\n\r\n.col-right-table-header{\r\n  font-size: 16px;\r\n  line-height: 20px;\r\n}\r\n\r\n\r\n.viewbtn-wrap{\r\n  position: absolute;\r\n  bottom: 10px;\r\n  width: 100%;\r\n}\r\n\r\n\r\n.viewbtn-wrap span{\r\n  display: inline-block;\r\n  color: #fff;\r\n  padding: 7px 15px;\r\n  background: rgba(20, 157, 204, 0.98);\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  text-decoration: none;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.slider-wrap{\r\n  position: relative;\r\n}\r\n\r\n\r\n.slider-wrap img{\r\n  width: 100%;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.adversarialpatche-display{\r\n  position: relative;\r\n  width: 75%;\r\n  margin: 0 auto;\r\n  padding: 8% 0 0 0;\r\n}\r\n\r\n\r\n.adversarialpatche-display img{\r\n  width: 100%;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.adversarialpatche-display a{\r\n  position: absolute;\r\n  font-size: 12px;\r\n  text-decoration: none;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  display: inline-block;\r\n  top: -5px;\r\n  left: -25px;\r\n\r\n}\r\n\r\n\r\n.btn-prev{\r\n\r\n}\r\n\r\n\r\n.item {\r\n  padding: 0;\r\n  width: 272px;\r\n  height: auto;\r\n  color: #fff;\r\n  font-size: 50px;\r\n  text-align: center;\r\n  background-color: black;\r\n  overflow: visible;\r\n}\r\n\r\n\r\n.item-inside{\r\n  /* background-color: crimson; */\r\n  display:inline-block;\r\n  width: 40%;\r\n  height: auto;\r\n  float: left;\r\n\r\n}\r\n\r\n\r\n.item-inside p{\r\n  font-size: 12px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.95);\r\n  min-height: 95px;\r\n  text-align: center;\r\n  word-wrap: break-word;\r\n  overflow: hidden;\r\n}\r\n\r\n\r\n.item-inside-01{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.item-inside-02{\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.innerpage-row-01 .row-col-left{\r\n  margin: 40px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-02 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-03 .row-col-left{\r\n  margin: 55px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-04 .row-col-left{\r\n  margin: 60px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-05 .row-col-left{\r\n  margin: 60px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-06 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-07 .row-col-left{\r\n  margin: 75px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-08 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-09 .row-col-left{\r\n  margin: 55px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.innerpage-row-10 .row-col-left{\r\n  margin: 45px 0px 0px 0px;\r\n  min-height: 0px;\r\n}\r\n\r\n\r\n.slider-txt-display p{\r\n  font-size: 16px;\r\n  line-height: 22px;\r\n  text-align: center;\r\n  margin: 90px 20px 0px 20px;\r\n\r\n}\r\n\r\n\r\n.row-col-loader{\r\n  width: 78%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.loader-fixedwidth{\r\n  width: 60%;\r\n  margin: 50px auto 0px auto;\r\n}\r\n\r\n\r\n.row-col-loader-header{\r\n  display: block;\r\n  font-size: 16px;\r\n  line-height: 16px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.row-col-loader-txt{\r\n  display: block;\r\n  font-size: 12px;\r\n  line-height: 14px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n  margin: 0px 0px 0px 0px;\r\n}\r\n\r\n\r\n.row-col-initial{\r\n  width: 78%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.row-noresult-wrap{\r\n  font-size: 16px;\r\n  line-height: 250px;\r\n}\r\n\r\n\r\n.row-col-initial-header{\r\n  display: block;\r\n  font-size: 16px;\r\n  line-height: 20px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  text-align: center;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.initial-circle-wrap{\r\n  margin: 30px 0px 0px 0px;\r\n  text-align: center;\r\n}\r\n\r\n\r\n.initial-circle-content{\r\n  display: inline-block;\r\n  margin: 0 40px;\r\n  width: 200px; \r\n    vertical-align: top;\r\n}\r\n\r\n\r\n.circle-header{\r\n  clear: both;\r\n  font-size: 16px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 10px 0px 0px 0px;\r\n}\r\n\r\n\r\n.circle-btn{\r\n  position: absolute;\r\n  bottom: 2px;\r\n  right: 2px;\r\n  font-size: 11px;\r\n  color: rgba(0, 0, 0, 0.6);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.initial-table-content{\r\n     margin: 60px 0px 0px 0px;\r\n    text-align: left;\r\n    color: rgba(0, 0, 0, 0.6);\r\n}\r\n\r\n\r\n.initial-table-content div{\r\n    font-size: 16px;\r\n    font-weight: 500;\r\n    margin: 5px 0px 10px 0px;\r\n}\r\n\r\n\r\n.initial-table-content div span{\r\n    font-size: 16px;\r\n    font-weight: 400;\r\n}\r\n\r\n\r\n.detailExample-wrap{\r\n  margin: 5px 0px 0px 0px;\r\n    overflow-y: scroll;\r\n    height: 220px;\r\n}\r\n\r\n\r\n.detailExample-cont{\r\n  margin: 10px auto 10px auto;\r\n  padding: 10px;\r\n  text-align: center;\r\n  box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  clear: both;\r\n  width: 98%;\r\n}\r\n\r\n\r\n.green-shadow{\r\n  box-shadow: 0px 0px 10px 0px rgba(77, 181, 60, 0.5);\r\n}\r\n\r\n\r\n.red-shadow{\r\n  box-shadow: 0px 0px 10px 0px rgba(214, 32, 4, 0.5);\r\n}\r\n\r\n\r\n.detailExample-cont-left{\r\n  /* display: inline-block; */\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  color: rgba(0, 0, 0, 0.98);\r\n  text-align: left;\r\n  width: 49%;\r\n  float: left;\r\n  padding: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.detailExample-cont-right{\r\n  /* display: inline-block; */\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  color: rgba(0, 0, 0, 0.98);\r\n  text-align: left;\r\n  width: 49%;\r\n  float: right;\r\n  padding: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.detailExample-cont-left div, .detailExample-cont-right div{\r\n    margin: 0px 0px 3px 0px;\r\n}\r\n\r\n\r\n.detailExample-cont-fullwidth{\r\n  /* display: inline-block; */\r\n  font-size: 13px;\r\n  font-weight: 400;\r\n  color: rgba(0, 0, 0, 0.98);\r\n  text-align: left;\r\n  width: 100%;\r\n  padding: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.detailExample-cont-fullwidth div span{\r\n   font-size: 13px;\r\n  font-weight: 500; \r\n}\r\n\r\n\r\n.predicted-class-wrap{\r\n   font-size: 13px;\r\n  font-weight: 400;\r\n  color: rgba(0, 0, 0, 0.98); \r\n    margin: 5px 0px 0px 0px;\r\n    text-align: left;\r\n}\r\n\r\n\r\n.predicted-class-wrap span{\r\n    font-size: 13px;\r\n  font-weight: 500;\r\n}\r\n\r\n\r\n.red-text{\r\n   color: #d62004; \r\n}\r\n\r\n\r\n.green-text{\r\n   color: #4db53c; \r\n}\r\n\r\n\r\n.details-back-btn{\r\n  position: absolute;\r\n  right: 2px;\r\n  bottom: 2px;\r\n  font-size: 11px;\r\n  /* color: rgba(20, 157, 204, 0.98); */\r\n  color: rgba(0, 0, 0, 0.5);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.details-right-btn{\r\n  position: absolute;\r\n  left: 2px;\r\n  bottom: 2px;\r\n  font-size: 11px;\r\n  /* color: rgba(20, 157, 204, 0.98); */\r\n  color: rgba(0, 0, 0, 0.5);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.details-mid-btn{\r\n  position: absolute;\r\n  left: 120px;\r\n  bottom: 2px;\r\n  font-size: 10px;\r\n  font-weight: bold;\r\n  /* color: rgba(20, 157, 204, 0.98); */\r\n  color: rgba(0, 0, 0, 0.5);\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.detailExample-cont-circle{\r\n  /* display: inline-block; */\r\n  margin: 0px 0px;\r\n  width: 30%;\r\n  float: left;\r\n}\r\n\r\n\r\n.detailExample-cont-header{\r\n  font-size: 12px;\r\n  text-align: center;\r\n  clear: both;\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.synonyms-subtext{\r\n    margin: 5px 0px 0px 10px;\r\n}\r\n\r\n\r\n.ip-row{\r\n  width: 100%;\r\n  border: rgba(205, 205, 205, 0.9) solid 1px;\r\n  border-bottom: none;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n.list{\r\n  border: rgba(205, 205, 205, 0.9) solid 1px;\r\n  border-top: none;\r\n  padding: 0px 0px 5px 0px;\r\n}\r\n\r\n\r\n.emptylist{\r\n  color: rgba(0, 0, 0, 0.95);\r\n  font-size: 15px;\r\n  padding: 30px 20px;\r\n}\r\n\r\n\r\n.ip-header{\r\n  font-size: 20px;\r\n  font-weight: 600px;\r\n  margin: 10px 0px 20px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-setting-btn-wrap{\r\n  font-size: 26px;\r\n  font-weight: 600px;\r\n  margin: 5px 10px 0px 0px;\r\n  color: rgba(20, 157, 204, 0.98);\r\n  float: right;\r\n  cursor: pointer;\r\n}\r\n\r\n\r\n.ip-result-header-01{\r\n  width: 20%;\r\n  float: left;\r\n  font-size: 14px;\r\n  text-align: center;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.ip-result-header-02{\r\n  width: 80%;\r\n  float: left;\r\n  font-size: 14px;\r\n  text-align: center;\r\n  margin: 0px 0px 20px 0px;\r\n}\r\n\r\n\r\n.ip-result-wrap{\r\n  /* -webkit-box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  -moz-box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15);\r\n  box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.15); */\r\n  padding: 5px;\r\n  margin: 0px auto 15px auto;\r\n  border: rgba(205, 205, 205, 0.7) solid 1px;\r\n  width: 99%;\r\n  position: relative;\r\n}\r\n\r\n\r\n.ip-result-col-left{\r\n  width: 20%;\r\n  float: left;\r\n  margin: 0 0.5% 0 0;\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-right{\r\n  width: 39.5%;\r\n  float: left;\r\n  margin: 0 0.5% 0 0;\r\n  border: 1px solid rgba(205, 205, 205, 0.6);\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt{\r\n  width: 39.5%;\r\n  float: left;\r\n  border: 1px solid rgba(205, 205, 205, 0.6);\r\n  min-height: 245px;\r\n}\r\n\r\n\r\n.ip-result-col-left span{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 14px;\r\n  color: rgba(0, 0, 0, 0.9);\r\n  margin: 5px 0px 2px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right span, .ip-result-col-right-alt span{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 14px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 2px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-left-01{\r\n  width: 100%;\r\n  padding: 5px;\r\n\r\n}\r\n\r\n\r\n.ip-result-col-right-gen{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-01{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-02{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-03{\r\n  width: 33%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-01{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-02{\r\n  width: 50%;\r\n  padding: 5px;\r\n  float: left;\r\n}\r\n\r\n\r\n.ip-result-col-left-01 img, .ip-result-col-right-01 img, .ip-result-col-right-02 img, .ip-result-col-right-03 img, .ip-result-col-right-gen img{\r\n  width:100%;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt-01 img, .ip-result-col-right-alt-02 img{\r\n  width:100%;\r\n}\r\n\r\n\r\n.ip-result-col-left p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.9);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n\r\n\r\n.ip-result-col-right-alt p{\r\n  display: block;\r\n  text-align: center;\r\n  font-size: 12px;\r\n  color: rgba(0, 0, 0, 0.5);\r\n  margin: 5px 0px 0px 0px;\r\n}\r\n"

/***/ }),

/***/ "./src/app/text-classifier/text-classifier.component.html":
/*!****************************************************************!*\
  !*** ./src/app/text-classifier/text-classifier.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"txt-classifier-wrap\">\r\n<mat-drawer-container class=\"insidepage-container\" autosize>\r\n<mat-drawer #drawer class=\"insidepage-sidenav content\" mode=\"side\">\r\n<div class=\"sidenav-cont-header\">\r\n<span>Project & Benchmark</span> <!-- <a (click)=\"showMainSetting = !showMainSetting\" ><i class=\"fa fa-cogs\"></i></a> -->\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"sidenav-select-project\">\r\n  <span>Project / Benchmark Models</span>\r\n  <form name=\"form\" #spf=\"ngForm\" novalidate>\r\n   <select name=\"projectName\" [(ngModel)]=\"projectName\" #projectname=\"ngModel\" (ngModelChange)=\"projectNameChange($event)\">\r\n      <option *ngFor=\"let pName of projectList; let i = index\" value={{pName}} [selected]=\"i == 0\">{{pName}}</option>\r\n      <option disabled><span>Benchmark</span></option>\r\n      <option value=\"Benchmark/Word2Vec_100d\">Word2Vec_100d </option>\r\n      <option value=\"Benchmark/Word2Vec_200d\">Word2Vec_200d</option>\r\n      <option value=\"Benchmark/Word2Vec_300d\">Word2Vec_300d</option>\r\n      <option value=\"Benchmark/GloVe_100d\">GloVe_100d</option>\r\n      <option value=\"Benchmark/GloVe_200d\">GloVe_200d</option>\r\n      <option value=\"Benchmark/GloVe_300d\">GloVe_300d</option>\r\n    </select>\r\n  </form>\r\n</div>\r\n\r\n<div class=\"sidenav-cont-header\">\r\n<span>{{projectName}} ran for</span>\r\n<div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<form name=\"form\" #f=\"ngForm\" novalidate>\r\n<div class=\"sidenav-form-wrap\">\r\n<div class=\"sidenav-cont-wrap sidenav-cont-input\">\r\n<div class=\"imageclassifiersetting-cont-wrap\">\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\"  type=\"checkbox\" name=\"robustnessValue\" [(ngModel)]=\"experimentsRan.robustnessValue\" #robustnessValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Robustness <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Measures the ability of the algorithm to be not susceptible to maliciously crafted inputs to specifically fool the algorithm.\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"clusteringValue\" [(ngModel)]=\"experimentsRan.clusteringValue\" #clusteringValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Clustering <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This tests the impact of the classifier when a specially crafted adversarial patch is introduced.\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"synonymsValue\" [(ngModel)]=\"experimentsRan.synonymsValue\" #synonymsValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Analogy <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"outlierValue\" [(ngModel)]=\"experimentsRan.outlierValue\" #outlierValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Outlier <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n<div class=\"imageclassifiersetting-option-wrap imageclassifiersetting-subsetting form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"analogyValue\" [(ngModel)]=\"experimentsRan.analogyValue\" #analogyValue=\"ngModel\" (ngModelChange)=\"onsubChange($event)\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Synonyms <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      This test checks Model Inputs on adversarial inputs (i.e. those that may not occur naturally but can be mis-used by a malicious party).\r\n    </span>\r\n  </label>\r\n</div>\r\n<div class=\"clearfix\"></div>\r\n\r\n<!-- <div class=\"imageclassifiersetting-option-wrap form-group\">\r\n  <label class=\"checkbox_wrap\">\r\n    <input [disabled]=\"true\" type=\"checkbox\" name=\"explainabilityValue\" [(ngModel)]=\"experimentsRan.explainabilityValue\" #explainabilityValue=\"ngModel\">\r\n    <span class=\"checkmark\"></span>\r\n  </label>\r\n  <label for=\"\" class=\"tooltip\">Interpretability <i class=\"fa fa-info-circle\"></i>\r\n    <span class=\"tooltiptext\">\r\n      Provides clue to interpret the decision of the algorithm.\r\n    </span>\r\n  </label>\r\n\r\n</div> -->\r\n<div class=\"clearfix\"></div>\r\n\r\n</div>\r\n\r\n</div>\r\n</div>\r\n</form>\r\n\r\n</mat-drawer>\r\n\r\n<div class=\"insidepage-sidenav-content\">\r\n<button class=\"btn-menu\" type=\"button\" mat-button (click)=\"drawer.toggle()\">\r\n<div #menuBurger class=\"burger\" (click)=\"menuclick()\" id=\"menuBurger\">\r\n<div class=\"x\"></div>\r\n<div class=\"y\"></div>\r\n<div class=\"z\"></div>\r\n</div>\r\n</button>\r\n\r\n<mat-tab-group class=\"full-width-wrap\" md-no-pagination=\"true\" (selectedTabChange)=\"forceScrollUpdate($event)\" animationDuration=\"2000ms\" [selectedIndex]=\"selectedActiveIndex\">    \r\n<mat-tab label=\"Robustness\">\r\n<ng-template matTabContent>\r\n\r\n<div class=\"innerpage-wrap\">\r\n<div class=\"innerpage-row innerpage-row-01\" >\r\n  <div class=\"innerpage-row-col row-col-left\">\r\n    <div class=\"row-col-header\">\r\n      <span>Clustering</span>\r\n<!--      <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"rnts\" class=\"fa fa-cogs\"></i></a>-->\r\n    </div>\r\n    <div class=\"row-col-content\">\r\n        This tests how well the learned embedding model is able to cluster the words based on their conceptual categories.\r\n    </div>\r\n  </div>\r\n\r\n<!--\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"rotNtrans\">\r\n      Clustering Results Not Available.\r\n  </div>\r\n-->\r\n  <div >\r\n\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"checkEmptyForClustering\">\r\n      Clustring Results Are Not Available.\r\n  </div>\r\n<div *ngIf=\"!checkEmptyForClustering\">\r\n  <div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableClustering\">\r\n    <div class=\"row-col-initial-header\">Accuracy and Data Classified by the Model</div>\r\n    <div class=\"clearfix\"></div>\r\n    <div class=\"initial-circle-wrap\">\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{textClassifierClusterOverallScore}} blue\">\r\n          <span>{{textClassifierClusterOverallScore}}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">Accuracy</div>\r\n      </div>\r\n      \r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"initial-table-content\">\r\n            <div>Total: <span>{{textClassifierClusterTotal}}</span></div>\r\n            <div>Correct: <span>{{textClassifierClusterCorrect}}</span></div>\r\n        </div>\r\n      </div> \r\n    </div>\r\n    <div class=\"circle-btn\" (click)=\"showDetailFuncClustering()\">View Further Details</div>\r\n  </div>\r\n</div>\r\n  </div>\r\n  <div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableClustering\">\r\n    <div class=\"row-col-matrix-content\">\r\n      <div class=\"col-right-table-wrap\">\r\n        <div class=\"col-right-table-header\">Examples</div>\r\n        <div class=\"detailExample-wrap\" >\r\n        <div *ngFor=\"let subArray of clusteringOriginalDataArrayOrg; let orgIndex=index\">\r\n\r\n          <div class=\"detailExample-cont\" [ngClass]=\"{'red-shadow': setBgColor[orgIndex]=='0', 'green-shadow':setBgColor[orgIndex]=='1' }\">\r\n            <div *ngFor=\"let item of subArray; let subIndex=index\">\r\n            <div class=\"detailExample-cont-left\" title=\"\">\r\n            <div>\r\n              <div [ngClass]=\"setBgColor[orgIndex]\">\r\n              <div>{{item}}</div>\r\n<!--              setBgColor[orgIndex] -- {{setBgColor[orgIndex]}}-->\r\n            </div>\r\n            </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-right\" title=\"\" >\r\n            <div>\r\n              <div [ngClass]=\"setBgColor[orgIndex]\">\r\n              <div>{{clusteringPredictedDataArrayOrg[orgIndex][subIndex]}}</div>\r\n<!--              setBgColor[orgIndex] -- {{setBgColor[orgIndex]}}-->\r\n            </div>\r\n            </div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div>\r\n        </div>\r\n          <!-- <div class=\"detailExample-cont\">\r\n            <div class=\"detailExample-cont-left\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringOriginalDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-right\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringPredictedDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div> -->\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n        <div *ngIf=\"(showDetailTableClustering) && (clusteringOriginalDataArray.length === 0)\">\r\n            <div class=\"detailExample-cont-left\" title=\"\">\r\n                No Information Available. \r\n            </div>\r\n        </div>\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"details-back-btn\" (click)=\"showInitialFuncClustering()\">View Overall Metrics.</div>\r\n    <div class=\"details-right-btn\" (click)=\"getNextClusterSet(50)\">Load next set results</div>\r\n    <div class=\"details-mid-btn\">{{emsgCluster}}</div>\r\n    <!-- <div class=\"details-mid-btn\" (click)=\"getPrevClusterData(3)\">click prev</div> -->\r\n  </div>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-02\" >\r\n  <div class=\"innerpage-row-col row-col-left\">\r\n    <div class=\"row-col-header\">\r\n      <span>Analogy</span>\r\n<!--      <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"rnts\" class=\"fa fa-cogs\"></i></a>-->\r\n    </div>\r\n    <div class=\"row-col-content\">\r\n        This tests how well the learned embedding model is able to perform on analogy task.\r\n    </div>\r\n  </div>\r\n\r\n<!--\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"rotNtrans\">\r\n      Clustering Results Not Available.\r\n  </div>\r\n-->\r\n  <div >\r\n\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"checkEmptyForAnalogy\">\r\n      Analogy Results Are Not Available.\r\n  </div>\r\n<div *ngIf=\"!checkEmptyForAnalogy\">\r\n  <div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableAnalogy\">\r\n    <div class=\"row-col-initial-header\">Accuracy and Data Classified by the Model</div>\r\n    <div class=\"clearfix\"></div>\r\n    <div class=\"initial-circle-wrap\">\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{textClassifierAnalogyOverallScore}} blue\">\r\n          <span>{{textClassifierAnalogyOverallScore}}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">Accuracy</div>\r\n      </div>\r\n      \r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"initial-table-content\">\r\n            <div>Total: <span>{{textClassifierAnalogyTotal}}</span></div>\r\n            <div>Correct: <span>{{textClassifierAnalogyCorrect}}</span></div>\r\n        </div>\r\n      </div> \r\n    </div>\r\n    <div class=\"circle-btn\" (click)=\"showDetailFuncAnalogy()\">View Further Details</div>\r\n  </div>\r\n</div>\r\n  </div>\r\n  <div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableAnalogy\">\r\n    <div class=\"row-col-matrix-content\">\r\n      <div class=\"col-right-table-wrap\">\r\n        <div class=\"col-right-table-header\">Examples</div>\r\n        <div class=\"detailExample-wrap\" >\r\n        <div *ngFor=\"let record of analogyPredictionResultsOrg\">\r\n          <div class=\"detailExample-cont\" >\r\n            <div >\r\n            <div class=\"detailExample-cont-fullwidth\" title=\"\">            \r\n              <div><span>{{record.word1}}</span> is to <span>{{record.word2}}</span> : <span>{{record.word3}}</span> is to <span [ngClass]=\"{'red-text': record.analogyPredictor==0, 'green-text':record.analogyPredictor==1}\">{{record.word4}}</span></div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n            <div class=\"predicted-class-wrap\" *ngIf=\"!record.analogyPredictor\">Predicted Class is <span>{{record.predWord}}</span></div>\r\n          </div>\r\n        </div>\r\n          <!-- <div class=\"detailExample-cont\">\r\n            <div class=\"detailExample-cont-left\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringOriginalDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-right\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringPredictedDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div> -->\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n\r\n        <div *ngIf=\"(showDetailTableAnalogy) && (analogyPredictionResults.length === 0)\">\r\n            <div class=\"detailExample-cont-left\" title=\"\">\r\n                No Information Available. \r\n            </div>\r\n        </div>\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"details-back-btn\" (click)=\"showInitialFuncAnalogy()\">View Overall Metrics.</div>\r\n    <div class=\"details-right-btn\" (click)=\"getNextAnalogySet(50)\">Load next set results</div>\r\n    <div class=\"details-mid-btn\">{{emsgAnalogy}}</div>\r\n  </div>\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-03\" >\r\n  <div class=\"innerpage-row-col row-col-left\">\r\n    <div class=\"row-col-header\">\r\n      <span>Outlier</span>\r\n<!--      <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"rnts\" class=\"fa fa-cogs\"></i></a>-->\r\n    </div>\r\n    <div class=\"row-col-content\">\r\n        This tests how well the learned embedding model is able to predict the outlier word in a given set of words.\r\n    </div>\r\n  </div>\r\n\r\n<!--\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"rotNtrans\">\r\n      Clustering Results Not Available.\r\n  </div>\r\n-->\r\n  <div >\r\n\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"checkEmptyForOutlier\">\r\n      Outlier Results Are Not Available.\r\n  </div>\r\n<div *ngIf=\"!checkEmptyForOutlier\">\r\n  <div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableOutlier\">\r\n    <div class=\"row-col-initial-header\">Accuracy and Data Classified by the Model</div>\r\n    <div class=\"clearfix\"></div>\r\n    <div class=\"initial-circle-wrap\">\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{textClassifierOutlierOverallScore}} blue\">\r\n          <span>{{textClassifierOutlierOverallScore}}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">Accuracy</div>\r\n      </div>\r\n      \r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"initial-table-content\">\r\n            <div>Total: <span>{{textClassifierOutlierTotal}}</span></div>\r\n            <div>Correct: <span>{{textClassifierOutlierCorrect}}</span></div>\r\n        </div>\r\n      </div> \r\n    </div>\r\n    <div class=\"circle-btn\" (click)=\"showDetailFuncOutlier()\">View Further Details</div>\r\n  </div>\r\n</div>\r\n  </div>\r\n\r\n  <div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableOutlier\">\r\n      <div class=\"row-col-matrix-content\">\r\n          <div class=\"col-right-table-wrap\">\r\n            <div class=\"col-right-table-header\">Examples</div>\r\n            <div class=\"detailExample-wrap\" >\r\n            <div *ngFor=\"let record of outlierPredictionResults\">\r\n              <div class=\"detailExample-cont\" >\r\n                <div class=\"detailExample-cont-fullwidth\" title=\"\">            \r\n                  <div><span>{{record.inlier1}}</span> : <span>{{record.inlier2}}</span> : <span>{{record.inlier3}}</span> : <span>{{record.inlier4}}</span> : <span>{{record.inlier5}}</span> : <span>{{record.inlier6}}</span>\r\n                    : <span>{{record.inlier7}}</span> : <span>{{record.inlier8}}</span> : <span>{{record.predicted}}</span>\r\n                    <div class=\"predicted-class-wrap\">Predicted Outlier is <span [ngClass]=\"{'red-text': record.outlierPredictor==0, 'green-text':record.outlierPredictor==1}\">\r\n                      {{record.outlier}}</span></div></div>\r\n                </div>\r\n                <div class=\"clearfix\"></div>\r\n                <div class=\"predicted-class-wrap\" *ngIf=\"!record.outlierPredictor\">Correct Outlier is <span>{{record.predicted}}</span></div>\r\n            </div>\r\n              <!-- <div class=\"detailExample-cont\">\r\n                <div class=\"detailExample-cont-left\" title=\"\" >\r\n                <div *ngFor=\"let item of clusteringOriginalDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n                </div>\r\n                <div class=\"detailExample-cont-right\" title=\"\" >\r\n                <div *ngFor=\"let item of clusteringPredictedDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n                </div>\r\n                <div class=\"clearfix\"></div>\r\n              </div> -->\r\n              <div class=\"clearfix\"></div>\r\n            </div>\r\n            \r\n            <div *ngIf=\"(showDetailTableOutlier) && (outlierPredictionResults.length === 0)\">\r\n                <div class=\"detailExample-cont-left\" title=\"\">\r\n                    No Information Available. \r\n                </div>\r\n            </div>\r\n\r\n            </div>\r\n          </div>\r\n        </div>\r\n    <div class=\"details-back-btn\" (click)=\"showInitialFuncOutlier()\">View Overall Metrics.</div>\r\n  </div>\r\n\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n\r\n<div class=\"innerpage-row innerpage-row-04\" >\r\n  <div class=\"innerpage-row-col row-col-left\">\r\n    <div class=\"row-col-header\">\r\n      <span>Synonyms</span>\r\n<!--      <a><i (click)=\"adversarialSetting = !adversarialSetting; settingMethod($event)\" id=\"rnts\" class=\"fa fa-cogs\"></i></a>-->\r\n    </div>\r\n    <div class=\"row-col-content\">\r\n      This tests how well the learned embedding model is able to predict the synonym of a given word.\r\n    </div>\r\n  </div>\r\n\r\n<!--\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"rotNtrans\">\r\n      Clustering Results Not Available.\r\n  </div>\r\n-->\r\n  <div >\r\n\r\n  <div class=\"innerpage-row-col row-col-initial row-noresult-wrap\" *ngIf=\"checkEmptyForSynonyms\">\r\n      Sysnonyms Results Are Not Available.\r\n  </div>\r\n  \r\n<div *ngIf=\"!checkEmptyForSynonyms\">\r\n  <div class=\"innerpage-row-col row-col-initial\" *ngIf=\"showInitialTableSynonyms\">\r\n    <div class=\"row-col-initial-header\">Accuracy and Data Classified by the Model</div>\r\n    <div class=\"clearfix\"></div>\r\n    <div class=\"initial-circle-wrap\">\r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"c100 p{{textClassifierSynonymsOverallScore}} blue\">\r\n          <span>{{textClassifierSynonymsOverallScore}}%</span>\r\n          <div class=\"slice\">\r\n            <div class=\"bar\"></div>\r\n            <div class=\"fill\"></div>\r\n          </div>\r\n        </div>\r\n        <div class=\"circle-header\">Accuracy</div>\r\n      </div>\r\n      \r\n      <div class=\"initial-circle-content\">\r\n        <div class=\"initial-table-content\">\r\n            <div>Total: <span>{{textClassifierSynonymsTotal}}</span></div>\r\n            <div>Correct: <span>{{textClassifierSynonymsCorrect}}</span></div>\r\n        </div>\r\n      </div> \r\n    </div>\r\n    <div class=\"circle-btn\" (click)=\"showDetailFuncSynonyms()\">View Further Details</div>\r\n  </div>\r\n</div>\r\n  </div>\r\n  <div class=\"innerpage-row-col row-col-right\" *ngIf=\"showDetailTableSynonyms\">\r\n    <div class=\"row-col-matrix-content\">\r\n      <div class=\"col-right-table-wrap\">\r\n        <div class=\"col-right-table-header\">Examples</div>\r\n        <div class=\"detailExample-wrap\" >\r\n          <div *ngFor=\"let record of synonymsPredictionResults\">\r\n            <div class=\"detailExample-cont\" >\r\n              <div class=\"detailExample-cont-fullwidth\" title=\"\">            \r\n                <div>\r\n                 <div><span>{{record.quest}}</span></div>\r\n                 <div class=\"synonyms-subtext\"><span [ngClass]=\"{'green-text': record.choice1==record.pred_Choice && record.choice_Predictor==1, 'red-text': record.choice1==record.pred_Choice && record.choice_Predictor==0 }\">{{record.choice1}}</span></div>\r\n                 <div class=\"synonyms-subtext\"><span [ngClass]=\"{'green-text': record.choice2==record.pred_Choice && record.choice_Predictor==1, 'red-text': record.choice2==record.pred_Choice && record.choice_Predictor==0}\">{{record.choice2}}</span></div>\r\n                 <div class=\"synonyms-subtext\"><span [ngClass]=\"{'green-text': record.choice3==record.pred_Choice && record.choice_Predictor==1, 'red-text': record.choice3==record.pred_Choice && record.choice_Predictor==0 }\">{{record.choice3}}</span></div>\r\n                 <div class=\"synonyms-subtext\"><span [ngClass]=\"{'green-text': record.choice4==record.pred_Choice && record.choice_Predictor==1, 'red-text': record.choice4==record.pred_Choice && record.choice_Predictor==0 }\">{{record.choice4}}</span></div>\r\n<!--                  <span>correct choice -- {{record.correct_Choice}}</span>-->\r\n<!--\r\n                  <div class=\"predicted-class-wrap\">Correct Answer is <span [ngClass]=\"{'red-text': record.choice_Predictor==0, 'green-text':record.choice_Predictor==1}\">\r\n                    {{record.pred_Choice}}</span></div>\r\n-->\r\n                </div>\r\n              </div>\r\n              <div class=\"clearfix\"></div>\r\n              <div class=\"predicted-class-wrap\" *ngIf=\"!record.choice_Predictor\">Correct Answer is <span>{{record.correct_Choice}}</span></div>\r\n          </div>\r\n          <!-- <div class=\"detailExample-cont\">\r\n            <div class=\"detailExample-cont-left\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringOriginalDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"detailExample-cont-right\" title=\"\" >\r\n            <div *ngFor=\"let item of clusteringPredictedDataArray | keyvalue\">{{item.key}} : {{item.value}} </div>\r\n            </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div> -->\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n        \r\n        <div *ngIf=\"(showDetailTableSynonyms) && (synonymsPredictionResults.length === 0)\">\r\n            <div class=\"detailExample-cont-left\" title=\"\">\r\n                No Information Available. \r\n            </div>\r\n        </div>\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"details-back-btn\" (click)=\"showInitialFuncSynonyms()\">View Overall Metrics.</div>\r\n  </div>\r\n\r\n  <div class=\"clearfix\"></div>\r\n</div>\r\n</div>\r\n\r\n</ng-template>\r\n</mat-tab>\r\n <mat-tab label=\" \" [disabled]=\"true\">\r\n</mat-tab>\r\n<mat-tab label=\" \" [disabled]=\"true\">\r\n</mat-tab> \r\n</mat-tab-group>\r\n</div>\r\n\r\n</mat-drawer-container>\r\n\r\n\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/text-classifier/text-classifier.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/text-classifier/text-classifier.component.ts ***!
  \**************************************************************/
/*! exports provided: TextClassifierComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TextClassifierComponent", function() { return TextClassifierComponent; });
/* harmony import */ var _services_text_class_serve_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../_services/text-class-serve.service */ "./src/app/_services/text-class-serve.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-malihu-scrollbar */ "./node_modules/ngx-malihu-scrollbar/fesm5/ngx-malihu-scrollbar.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var TextClassifierComponent = /** @class */ (function () {
    function TextClassifierComponent(textServe, mScrollbarService, elRef) {
        this.textServe = textServe;
        this.mScrollbarService = mScrollbarService;
        this.elRef = elRef;
        this.showInitialTableClustering = true;
        this.showDetailTableClustering = false;
        this.showInitialTableAnalogy = true;
        this.showDetailTableAnalogy = false;
        this.showInitialTableOutlier = true;
        this.showDetailTableOutlier = false;
        this.showInitialTableSynonyms = true;
        this.showDetailTableSynonyms = false;
        this.checkEmptyForClustering = false;
        this.checkEmptyForAnalogy = false;
        this.checkEmptyForOutlier = false;
        this.checkEmptyForSynonyms = false;
        this.projectList = [];
        this.nextSetCluster = 0;
        this.clusterLimit = 0;
        this.emsgCluster = '';
        this.nextSetAnalogy = 0;
        this.analogyLimit = 0;
        this.emsgAnalogy = '';
        // clusteringOriginalDataArray =  {
        //   'solid': '[cuboid, droop, octahedron]',
        //   'district': '[borough, shire, caliphate]',
        //   'social_unit': '[legion, divan, committee]'
        // };
        // clusteringPredictedDataArray = {
        //   '1': '[cuboid, droop, octahedron]',
        //   '2': '[borough, shire, caliphate, committee]',
        //   '3': '[legion, divan]'
        // };
        this.clusteringOriginalDataArray = [];
        this.clusteringPredictedDataArray = [];
        this.clusteringOriginalDataArrayOrg = [];
        this.clusteringPredictedDataArrayOrg = [];
        this.setBgColor = [];
        this.analogyPredictionResults = [];
        this.analogyPredictionResultsOrg = [];
        this.outlierPredictionResults = [];
        this.synonymsPredictionResults = [];
        this.experimentsRan = { robustnessValue: false, clusteringValue: false, synonymsValue: false, outlierValue: false, analogyValue: false, explainabilityValue: false };
        elRef.nativeElement.ownerDocument.body.style.overflowY = 'scroll';
    }
    TextClassifierComponent.prototype.ngOnInit = function () {
        this.listProjects();
        //this.loadLatestBenchmark()
    };
    TextClassifierComponent.prototype.menuclick = function () {
        if (this.menuBurger.nativeElement.classList.contains('open')) {
            this.closeMenu();
        }
        else {
            this.openMenu();
        }
    };
    TextClassifierComponent.prototype.openMenu = function () {
        $('div.burger').addClass('open');
        $('div.y').fadeOut(100);
        $('div.screen').addClass('animate');
        setTimeout(function () {
            $('div.x').addClass('rotate30');
            $('div.z').addClass('rotate150');
            $('.menu').addClass('animate');
            setTimeout(function () {
                $('div.x').addClass('rotate45');
                $('div.z').addClass('rotate135');
            }, 100);
        }, 10);
    };
    TextClassifierComponent.prototype.closeMenu = function () {
        $('div.screen, .menu').removeClass('animate');
        $('div.y').fadeIn(150);
        $('div.burger').removeClass('open');
        $('div.x').removeClass('rotate45').addClass('rotate30');
        $('div.z').removeClass('rotate135').addClass('rotate150');
        setTimeout(function () {
            $('div.x').removeClass('rotate30');
            $('div.z').removeClass('rotate150');
        }, 50);
        setTimeout(function () {
            $('div.x, div.z').removeClass('collapse');
        }, 70);
    };
    TextClassifierComponent.prototype.showDetailFuncClustering = function () {
        this.showInitialTableClustering = false;
        this.showDetailTableClustering = true;
        this.getNextClusterSet(50);
    };
    TextClassifierComponent.prototype.showInitialFuncClustering = function () {
        this.showInitialTableClustering = true;
        this.showDetailTableClustering = false;
        this.nextSetCluster = 0;
    };
    TextClassifierComponent.prototype.showDetailFuncAnalogy = function () {
        this.showInitialTableAnalogy = false;
        this.showDetailTableAnalogy = true;
        this.getNextAnalogySet(50);
    };
    TextClassifierComponent.prototype.showInitialFuncAnalogy = function () {
        this.showInitialTableAnalogy = true;
        this.showDetailTableAnalogy = false;
        this.nextSetAnalogy = 0;
    };
    TextClassifierComponent.prototype.showDetailFuncOutlier = function () {
        this.showInitialTableOutlier = false;
        this.showDetailTableOutlier = true;
    };
    TextClassifierComponent.prototype.showInitialFuncOutlier = function () {
        this.showInitialTableOutlier = true;
        this.showDetailTableOutlier = false;
    };
    TextClassifierComponent.prototype.showDetailFuncSynonyms = function () {
        this.showInitialTableSynonyms = false;
        this.showDetailTableSynonyms = true;
    };
    TextClassifierComponent.prototype.showInitialFuncSynonyms = function () {
        this.showInitialTableSynonyms = true;
        this.showDetailTableSynonyms = false;
    };
    TextClassifierComponent.prototype.resetAllMethods = function () {
        this.showInitialFuncClustering();
        this.showInitialFuncAnalogy();
        this.showInitialFuncOutlier();
        this.showInitialFuncSynonyms();
    };
    TextClassifierComponent.prototype.listProjects = function () {
        var _this = this;
        this.textServe.getHttpResponse('http://localhost:5000/projectDirs/textClassifier').subscribe(function (resp) {
            _this.projectList = JSON.parse(resp['_body']);
            if (_this.projectList.length > 0) {
                // console.log("this.projectList.length --- ",this.projectList.length)
                // console.log("calling project")
                _this.loadLatestProject();
            }
            else {
                // console.log("this.projectList.length --- ",this.projectList.length)
                // console.log("calling Benchmark")
                _this.loadLatestBenchmark();
            }
        }, function (err) {
            console.log('some error occuresd in file uploading');
            _this.loadLatestBenchmark();
        });
    };
    TextClassifierComponent.prototype.loadLatestProject = function () {
        this.projectName = this.projectList[0];
        this.setFilePaths(this.projectList[0]);
        this.loadTextClassifiers();
    };
    TextClassifierComponent.prototype.loadLatestBenchmark = function () {
        this.projectName = 'GloVe_100d';
        this.setFilePaths('Benchmark/GloVe_100d');
        this.loadTextClassifiers();
    };
    TextClassifierComponent.prototype.loadExperiments = function (experimentsPath) {
        var _this = this;
        this.textServe.getHttpResponse(experimentsPath).subscribe(function (resp) {
            var allLinesExperimentsCsv = _this.textServe.extractCsvData(resp);
            var splitexperimentsData = allLinesExperimentsCsv[0].split(',');
            if (splitexperimentsData[0] === "TRUE")
                _this.experimentsRan.robustnessValue = true;
            else
                _this.experimentsRan.robustnessValue = false;
            if (splitexperimentsData[1] === "TRUE")
                _this.experimentsRan.clusteringValue = true;
            else
                _this.experimentsRan.clusteringValue = false;
            if (splitexperimentsData[2] === "TRUE")
                _this.experimentsRan.synonymsValue = true;
            else
                _this.experimentsRan.synonymsValue = false;
            if (splitexperimentsData[3] === "TRUE")
                _this.experimentsRan.outlierValue = true;
            else
                _this.experimentsRan.outlierValue = false;
            if (splitexperimentsData[4] === "TRUE")
                _this.experimentsRan.analogyValue = true;
            else
                _this.experimentsRan.analogyValue = false;
            //console.log("overall text classifier data -- ", this.experimentsRan)
        }, function (err) {
            //console.log("overall text classifier data -- ", err)
            _this.experimentsRan.robustnessValue = false;
            _this.experimentsRan.clusteringValue = false;
            _this.experimentsRan.synonymsValue = false;
            _this.experimentsRan.outlierValue = false;
            _this.experimentsRan.analogyValue = false;
            _this.experimentsRan.explainabilityValue = false;
        });
    };
    TextClassifierComponent.prototype.loadTextClassifiers = function () {
        this.readTextClassClusterOverallMetricesData();
        this.readTextClassClusterResultData();
        this.readTextClassAnalogyOverallMetricesData();
        this.readTextClassAnalogyResultsMetricesData();
        this.readTextClassOutlierOverallMetricesData();
        this.readTextClassOutlierResultsMetricesData();
        this.readTextClassSynonymsOverallMetricesData();
        this.readTextClassSynonymsResultsMetricesData();
    };
    TextClassifierComponent.prototype.setFilePaths = function (projName) {
        this.projectName = projName;
        this.textClassResPath = './assets/textClassifierResults/' + this.projectName;
        this.textClassRobPath = this.textClassResPath + '/Robustness';
        this.textClassResClusterPath = this.textClassRobPath + '/Clustering/Results/';
        this.clusterOverallMetricsPath = this.textClassResClusterPath + 'overallmetrics.csv';
        this.clusterMetricsPath = this.textClassResClusterPath + 'output.csv';
        this.textClassResAnalogyPath = this.textClassRobPath + '/Analogy/Results/';
        this.analogyOverallMetricsPath = this.textClassResAnalogyPath + 'overallmetrics.csv';
        this.analogyResultsMetricsPath = this.textClassResAnalogyPath + 'output.csv';
        this.textClassResOutlierPath = this.textClassRobPath + '/Outlier/Results/';
        this.outlierOverallMetricsPath = this.textClassResOutlierPath + 'overallmetrics.csv';
        this.outlierResultsMetricsPath = this.textClassResOutlierPath + 'output.csv';
        this.textClassResSynonymsPath = this.textClassRobPath + '/Synonyms/Results/';
        this.synonymsOverallMetricsPath = this.textClassResSynonymsPath + 'overallmetrics.csv';
        this.synonymsResultsMetricsPath = this.textClassResSynonymsPath + 'output.csv';
        this.experimentCsvPath = this.textClassResPath + '/experiments.csv';
        this.loadExperiments(this.experimentCsvPath);
    };
    TextClassifierComponent.prototype.readTextClassClusterOverallMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.clusterOverallMetricsPath).subscribe(function (resp) {
            var allLinesOverallMetrics = _this.textServe.extractCsvData(resp);
            var splitOverallData = allLinesOverallMetrics[0].split(',');
            _this.textClassifierClusterOverallScore = Number(Number(splitOverallData[2]).toFixed(2)) * 100;
            _this.textClassifierClusterTotal = Number(splitOverallData[1]);
            _this.textClassifierClusterCorrect = Number(splitOverallData[0]);
            _this.checkEmptyForClustering = false;
        }, function (err) {
            //console.log("overall text classifier data -- ", err)
            _this.textClassifierClusterOverallScore = 0;
            _this.textClassifierClusterTotal = 0;
            _this.textClassifierClusterCorrect = 0;
            _this.checkEmptyForClustering = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassAnalogyOverallMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.analogyOverallMetricsPath).subscribe(function (resp) {
            var allLinesOverallMetrics = _this.textServe.extractCsvData(resp);
            var splitOverallData = allLinesOverallMetrics[0].split(',');
            _this.textClassifierAnalogyOverallScore = Number(Number(splitOverallData[2]).toFixed(2)) * 100;
            _this.textClassifierAnalogyTotal = Number(splitOverallData[1]);
            _this.textClassifierAnalogyCorrect = Number(splitOverallData[0]);
            _this.checkEmptyForAnalogy = false;
        }, function (err) {
            //console.log("overall text classifier data -- ", err)
            _this.textClassifierAnalogyOverallScore = 0;
            _this.textClassifierAnalogyTotal = 0;
            _this.textClassifierAnalogyCorrect = 0;
            _this.checkEmptyForAnalogy = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassOutlierOverallMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.outlierOverallMetricsPath).subscribe(function (resp) {
            var allLinesOverallMetrics = _this.textServe.extractCsvData(resp);
            var splitOverallData = allLinesOverallMetrics[0].split(',');
            _this.textClassifierOutlierOverallScore = Number(Number(splitOverallData[2]).toFixed(2)) * 100;
            _this.textClassifierOutlierTotal = Number(splitOverallData[1]);
            _this.textClassifierOutlierCorrect = Number(splitOverallData[0]);
            _this.checkEmptyForOutlier = false;
        }, function (err) {
            //console.log("overall text classifier data -- ", err)
            _this.textClassifierOutlierOverallScore = 0;
            _this.textClassifierOutlierTotal = 0;
            _this.textClassifierOutlierCorrect = 0;
            _this.checkEmptyForOutlier = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassSynonymsOverallMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.synonymsOverallMetricsPath).subscribe(function (resp) {
            var allLinesOverallMetrics = _this.textServe.extractCsvData(resp);
            var splitOverallData = allLinesOverallMetrics[0].split(',');
            _this.textClassifierSynonymsOverallScore = Number(Number(splitOverallData[2]).toFixed(2)) * 100;
            _this.textClassifierSynonymsTotal = Number(splitOverallData[1]);
            _this.textClassifierSynonymsCorrect = Number(splitOverallData[0]);
            _this.checkEmptyForSynonyms = false;
        }, function (err) {
            //console.log("overall text classifier data -- ", err)
            _this.textClassifierSynonymsOverallScore = 0;
            _this.textClassifierSynonymsTotal = 0;
            _this.textClassifierSynonymsCorrect = 0;
            _this.checkEmptyForSynonyms = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassClusterResultData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.clusterMetricsPath).subscribe(function (resp) {
            var allLineTextClassDecoupledclusterMetricesData = _this.textServe.extractCsvData(resp);
            _this.loadTextClassClusterMetricesData(allLineTextClassDecoupledclusterMetricesData);
            _this.checkEmptyForClustering = false;
        }, function (err) {
            //console.log("decoupled cluster data -- ", err)
            _this.clusteringOriginalDataArray = [];
            _this.clusteringPredictedDataArray = [];
            _this.checkEmptyForClustering = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassAnalogyResultsMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.analogyResultsMetricsPath).subscribe(function (resp) {
            var allLineTextClassanalogyMetricesData = _this.textServe.extractCsvData(resp);
            _this.loadTextClassAnalogyMetricesData(allLineTextClassanalogyMetricesData);
            _this.checkEmptyForAnalogy = false;
        }, function (err) {
            //console.log("decoupled cluster data -- ", err)
            _this.analogyPredictionResults = [];
            _this.checkEmptyForAnalogy = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassOutlierResultsMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.outlierResultsMetricsPath).subscribe(function (resp) {
            var allLineTextClassanalogyMetricesData = _this.textServe.extractCsvData(resp);
            _this.loadTextClassOutlierMetricesData(allLineTextClassanalogyMetricesData);
            _this.checkEmptyForOutlier = false;
        }, function (err) {
            //console.log("decoupled cluster data -- ", err)
            _this.outlierPredictionResults = [];
            _this.checkEmptyForOutlier = true;
        });
    };
    TextClassifierComponent.prototype.readTextClassSynonymsResultsMetricesData = function () {
        var _this = this;
        this.textServe.getHttpResponse(this.synonymsResultsMetricsPath).subscribe(function (resp) {
            var allLineTextClassanalogyMetricesData = _this.textServe.extractCsvData(resp);
            _this.loadTextClassSynonymsMetricesData(allLineTextClassanalogyMetricesData);
            _this.checkEmptyForSynonyms = false;
        }, function (err) {
            //console.log("decoupled cluster data -- ", err)
            _this.synonymsPredictionResults = [];
            _this.checkEmptyForSynonyms = true;
        });
    };
    TextClassifierComponent.prototype.loadTextClassClusterMetricesData = function (allLineDeclusterData) {
        this.clusteringOriginalDataArray = [];
        this.clusteringPredictedDataArray = [];
        for (var i = 0; i < 55; i++) {
            var keyvaluessPerRecord = [];
            var checkVal = true;
            allLineDeclusterData[i] = allLineDeclusterData[i].replace(/"/g, '');
            while (checkVal) {
                if (allLineDeclusterData[i].includes('[')) {
                    var f1 = allLineDeclusterData[i].substring(0, allLineDeclusterData[i].indexOf(']') + 1);
                    allLineDeclusterData[i] = allLineDeclusterData[i].replace(f1, '');
                    var valu = f1.substring(f1.indexOf('['), f1.indexOf(']') + 1);
                    f1 = f1.replace(valu, '');
                    keyvaluessPerRecord.push(f1.replace(/,/g, '') + ' : ' + valu);
                }
                else {
                    checkVal = false;
                    this.setBgColor.push(allLineDeclusterData[i].replace(/,/g, ''));
                }
            }
            this.clusteringOriginalDataArray.push(keyvaluessPerRecord.slice(0, keyvaluessPerRecord.length / 2));
            this.clusteringPredictedDataArray.push(keyvaluessPerRecord.slice(keyvaluessPerRecord.length / 2, keyvaluessPerRecord.length));
        }
    };
    TextClassifierComponent.prototype.getNextClusterSet = function (limit) {
        if (this.nextSetCluster < this.clusteringOriginalDataArray.length - 1) {
            this.clusteringOriginalDataArrayOrg = [];
            this.clusteringPredictedDataArrayOrg = [];
            this.emsgCluster = '';
            while (limit > 0) {
                this.clusteringOriginalDataArrayOrg.push(this.clusteringOriginalDataArray[this.nextSetCluster]);
                this.clusteringPredictedDataArrayOrg.push(this.clusteringPredictedDataArray[this.nextSetCluster]);
                this.nextSetCluster += 1;
                limit -= 1;
                if ((this.nextSetCluster) == this.clusteringOriginalDataArray.length) {
                    this.nextSetCluster = 0;
                    this.emsgCluster = "All items covered. start over!";
                    break;
                }
            }
        }
        if (limit >= this.clusteringOriginalDataArray.length) {
            this.emsgCluster = '';
        }
    };
    TextClassifierComponent.prototype.getNextAnalogySet = function (limit) {
        if (this.nextSetAnalogy < this.analogyPredictionResults.length - 1) {
            this.analogyPredictionResultsOrg = [];
            this.emsgAnalogy = '';
            while (limit > 0) {
                this.analogyPredictionResultsOrg.push(this.analogyPredictionResults[this.nextSetAnalogy]);
                this.nextSetAnalogy += 1;
                limit -= 1;
                if ((this.nextSetAnalogy) == this.analogyPredictionResults.length) {
                    this.nextSetAnalogy = 0;
                    this.emsgAnalogy = "All items covered. start over!";
                    break;
                }
            }
        }
        if (limit >= this.analogyPredictionResults.length) {
            this.emsgAnalogy = '';
        }
    };
    TextClassifierComponent.prototype.loadTextClassAnalogyMetricesData = function (allLineAnalogyData) {
        this.analogyPredictionResults = [];
        for (var i = 0; i < allLineAnalogyData.length; i++) {
            var analogyDataPerLine = allLineAnalogyData[i].split(',');
            var record = {
                word1: analogyDataPerLine[0],
                word2: analogyDataPerLine[1],
                word3: analogyDataPerLine[2],
                word4: analogyDataPerLine[3],
                predWord: analogyDataPerLine[4],
                analogyPredictor: Number(analogyDataPerLine[5])
            };
            this.analogyPredictionResults.push(record);
        }
    };
    TextClassifierComponent.prototype.loadTextClassOutlierMetricesData = function (allLineOutlierData) {
        this.outlierPredictionResults = [];
        for (var i = 0; i < allLineOutlierData.length; i++) {
            var outlierDataPerLine = allLineOutlierData[i].split(',');
            if (Number(outlierDataPerLine[10] != -1)) {
                var record = {
                    inlier1: outlierDataPerLine[0],
                    inlier2: outlierDataPerLine[1],
                    inlier3: outlierDataPerLine[2],
                    inlier4: outlierDataPerLine[3],
                    inlier5: outlierDataPerLine[4],
                    inlier6: outlierDataPerLine[5],
                    inlier7: outlierDataPerLine[6],
                    inlier8: outlierDataPerLine[7],
                    outlier: outlierDataPerLine[8],
                    predicted: outlierDataPerLine[9],
                    outlierPredictor: Number(outlierDataPerLine[10])
                };
                this.outlierPredictionResults.push(record);
            }
        }
    };
    TextClassifierComponent.prototype.loadTextClassSynonymsMetricesData = function (allLineOutlierData) {
        this.synonymsPredictionResults = [];
        for (var i = 0; i < allLineOutlierData.length; i++) {
            var synonymsDataPerLine = allLineOutlierData[i].split(',');
            var record = {
                quest: synonymsDataPerLine[0],
                choice1: synonymsDataPerLine[1],
                choice2: synonymsDataPerLine[2],
                choice3: synonymsDataPerLine[3],
                choice4: synonymsDataPerLine[4],
                correct_Choice: synonymsDataPerLine[5],
                pred_Choice: synonymsDataPerLine[6],
                choice_Predictor: Number(synonymsDataPerLine[7])
            };
            this.synonymsPredictionResults.push(record);
        }
    };
    TextClassifierComponent.prototype.projectNameChange = function ($event) {
        this.projectName = $event;
        this.resetAllMethods();
        this.setFilePaths($event);
        this.loadTextClassifiers();
    };
    TextClassifierComponent.prototype.forceScrollUpdate = function ($event) {
        var _this = this;
        // alert("Hi");
        //console.log("selected index -- ", this.selectedIndex);
        setTimeout(function () {
            // alert("Working");
            _this.mScrollbarService.initScrollbar('.horizontal-images', { axis: 'x', theme: 'dark', scrollButtons: { enable: true }, autoExpandScrollbar: true, advanced: { autoExpandHorizontalScroll: true } });
            // this.mScrollbarService.initScrollbar('#ScrollExp', { axis: 'x', theme: 'dark-thick', scrollButtons: { enable: true } });
        }, 40);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('menuBurger'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], TextClassifierComponent.prototype, "menuBurger", void 0);
    TextClassifierComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-text-classifier',
            template: __webpack_require__(/*! ./text-classifier.component.html */ "./src/app/text-classifier/text-classifier.component.html"),
            styles: [__webpack_require__(/*! ./text-classifier.component.css */ "./src/app/text-classifier/text-classifier.component.css")]
        }),
        __metadata("design:paramtypes", [_services_text_class_serve_service__WEBPACK_IMPORTED_MODULE_0__["TextClassServeService"], ngx_malihu_scrollbar__WEBPACK_IMPORTED_MODULE_2__["MalihuScrollbarService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])
    ], TextClassifierComponent);
    return TextClassifierComponent;
}());

// clusteringOriginalDataArray:{ [key]: string } =
//   {
//     'solid': '[cuboid, droop, octahedron]',
//     'district': '[borough, shire, caliphate]',
//     'social_unit': '[legion, divan, committee]'
//   };
// clusteringPredictedDataArray:{ [key]: string } =
//   {
//     '1': '[cuboid, droop, octahedron]',
//     '2': '[borough, shire, caliphate, committee]',
//     '3': '[legion, divan]'
//   };


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Harsha\GIT\development\tft_lib_ui\web\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map