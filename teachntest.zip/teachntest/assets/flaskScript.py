'''
auther: ankit.bw.kumar@accenture.com
'''
from flask import Flask, redirect, url_for, request, render_template, abort
from flask_cors import CORS, cross_origin
from flask import Response
import pandas as pd
import sys
import os, time
import json
from flask import jsonify
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
#cors = CORS(app, resources={r"/file": {"origins": "http://localhost:4200"}})
current_DIR_NAME = os.path.dirname(os.path.realpath(__file__))
print("current_DIR_NAME --- ",current_DIR_NAME)
@app.route('/projectDirs/<category>')
def projNameLists(category):
    nameList = []
    try:
        if(category=="imageClassifier"):
            DIR_NAME = current_DIR_NAME+r'\results'
        else:
            DIR_NAME = current_DIR_NAME+r'\textClassifierResults'
        for i in os.listdir(DIR_NAME):
            if(i!='Benchmark'):
                if(os.path.isdir(os.path.abspath(os.path.join(DIR_NAME,i)))):
                    nameList.append(i)
        nameList.sort(key=lambda x: os.path.getctime(os.path.abspath(os.path.join(DIR_NAME,x))), reverse=True)
        if(len(nameList)>0):
            return jsonify(nameList)
        else:
            return jsonify([])
    except Exception as e:
        nameList = []
        return jsonify(nameList)
        #abort(400)
        #return Response(str(e), status=400)
    #return Response('%s' %nameList, status=200)

@app.route('/file/<projectName>',methods = ['POST', 'GET'])
def file(projectName):
    #Request method must be POST
   benchmarklist =['InceptionV3','ResNet','DenseNet','MobileNet']
   if request.method == 'POST':
        try:
              if(projectName not in benchmarklist):
                      print("Saving as csv...")
                      #Get the request field value from the request json
                      limeOutputAsString = request.json['limeCsv']
                      #split each line by \n
                      limeOutputLines = limeOutputAsString.split('\r\n')
                      IMAGE = []
                      ORIGINAL_LABEL = []
                      Top_n_Predictions = []
                      Explanations = []
                      OriginalPredicted = []
                      Probability_Of_Top_Most_Prediction = []
                      Probability_Of_Top_n_Predictions = []
                      Misclassified_classes_with_high_probability = []
                      Classified_classes_with_low_probability = []
                      Correctly_classified_with_high_probability = []
                      isSelected = []
                      comments = []
                      #Get each column value by looping through all the record and appending to the particular list
                      for record in limeOutputLines[1:]:
                        tempRec = record.split(',')
                        IMAGE.append(tempRec[0].replace('\"',''))
                        ORIGINAL_LABEL.append(tempRec[1].replace('\"',''))
                        tpPred = tempRec[2].replace('\"','').split(';')
                        Top_n_Predictions.append(tpPred)
                        expl = tempRec[3].replace('\"','').split(';')
                        Explanations.append(expl)
                        OriginalPredicted.append(tempRec[4].replace('\"',''))
                        Probability_Of_Top_Most_Prediction.append(tempRec[5].replace('\"',''))
                        probTpPred = tempRec[6].replace('\"','').split(';')
                        Probability_Of_Top_n_Predictions.append(probTpPred)
                        Misclassified_classes_with_high_probability.append(tempRec[7].replace('\"',''))
                        Classified_classes_with_low_probability.append(tempRec[8].replace('\"',''))
                        Correctly_classified_with_high_probability.append(tempRec[9].replace('\"',''))
                        isSelected.append(tempRec[10].replace('\"',''))
                        comments.append(tempRec[11].replace('\"',''))
                      #Creating the dictonary to generate the csv by specifying key(column name) and its value(list)
                      dict = {'IMAGE': IMAGE, 'ORIGINAL LABEL': ORIGINAL_LABEL, 'Top n Predictions': Top_n_Predictions, 
                      'Explanations': Explanations, 'Original=Predicted?': OriginalPredicted, 
                      'Probability Of Top Most Prediction': Probability_Of_Top_Most_Prediction, 
                      'Probability Of Top n Predictions': Probability_Of_Top_n_Predictions, 
                      'misclsfied_with_high_prob': Misclassified_classes_with_high_probability, 
                      'corr_clsfied_with_low_prob': Classified_classes_with_low_probability, 
                      'corr_clsfied_with_high_prob': Correctly_classified_with_high_probability, 'isSelected': isSelected, 'comments': comments}
                      #Creating the data frame
                      print("project name --- ", projectName)
                      df = pd.DataFrame(dict, columns=['IMAGE', 'ORIGINAL LABEL', 'Top n Predictions', 'Explanations', 'Original=Predicted?', 
                      'Probability Of Top Most Prediction', 'Probability Of Top n Predictions', 'misclsfied_with_high_prob', 
                      'corr_clsfied_with_low_prob', 'corr_clsfied_with_high_prob', 'isSelected', 'comments'])
                      # arrange the output to show mis classifications on top of the list
                      df = df.sort_values(by=['Original=Predicted?', 'Probability Of Top Most Prediction'], ascending=[True, False])
                      #Generate new csv file at the given location
                      DIR_NAME=current_DIR_NAME+r'\results'+'\\'+projectName+r'\Interpretability\Results'
                      df.to_csv(os.path.join(DIR_NAME, 'limeoutput.csv'), index=False)
                      #Return a response
                      return Response("projectName %s" %projectName, status=200)
              else:
                      print("I am in else")
                      print("Saving as csv...")
                      #Get the request field value from the request json
                      limeOutputAsString = request.json['limeCsv']
                      #split each line by \n
                      limeOutputLines = limeOutputAsString.split('\r\n')
                      IMAGE = []
                      ORIGINAL_LABEL = []
                      Top_n_Predictions = []
                      Explanations = []
                      OriginalPredicted = []
                      Probability_Of_Top_Most_Prediction = []
                      Probability_Of_Top_n_Predictions = []
                      Misclassified_classes_with_high_probability = []
                      Classified_classes_with_low_probability = []
                      Correctly_classified_with_high_probability = []
                      isSelected = []
                      comments = []
                      #Get each column value by looping through all the record and appending to the particular list
                      for record in limeOutputLines[1:]:
                        tempRec = record.split(',')
                        IMAGE.append(tempRec[0].replace('\"',''))
                        ORIGINAL_LABEL.append(tempRec[1].replace('\"',''))
                        tpPred = tempRec[2].replace('\"','').split(';')
                        Top_n_Predictions.append(tpPred)
                        expl = tempRec[3].replace('\"','').split(';')
                        Explanations.append(expl)
                        OriginalPredicted.append(tempRec[4].replace('\"',''))
                        Probability_Of_Top_Most_Prediction.append(tempRec[5].replace('\"',''))
                        probTpPred = tempRec[6].replace('\"','').split(';')
                        Probability_Of_Top_n_Predictions.append(probTpPred)
                        Misclassified_classes_with_high_probability.append(tempRec[7].replace('\"',''))
                        Classified_classes_with_low_probability.append(tempRec[8].replace('\"',''))
                        Correctly_classified_with_high_probability.append(tempRec[9].replace('\"',''))
                        isSelected.append(tempRec[10].replace('\"',''))
                        comments.append(tempRec[11].replace('\"',''))
                      #Creating the dictonary to generate the csv by specifying key(column name) and its value(list)
                      dict = {'IMAGE': IMAGE, 'ORIGINAL LABEL': ORIGINAL_LABEL, 'Top n Predictions': Top_n_Predictions, 
                      'Explanations': Explanations, 'Original=Predicted?': OriginalPredicted, 
                      'Probability Of Top Most Prediction': Probability_Of_Top_Most_Prediction, 
                      'Probability Of Top n Predictions': Probability_Of_Top_n_Predictions, 
                      'misclsfied_with_high_prob': Misclassified_classes_with_high_probability, 
                      'corr_clsfied_with_low_prob': Classified_classes_with_low_probability, 
                      'corr_clsfied_with_high_prob': Correctly_classified_with_high_probability, 'isSelected': isSelected, 'comments': comments}
                      #Creating the data frame
                      print("project name --- ", projectName)
                      print("current_DIR_NAME ---- ", current_DIR_NAME)
                      df = pd.DataFrame(dict, columns=['IMAGE', 'ORIGINAL LABEL', 'Top n Predictions', 'Explanations', 'Original=Predicted?', 
                      'Probability Of Top Most Prediction', 'Probability Of Top n Predictions', 'misclsfied_with_high_prob', 
                      'corr_clsfied_with_low_prob', 'corr_clsfied_with_high_prob', 'isSelected', 'comments'])
                      # arrange the output to show mis classifications on top of the list
                      df = df.sort_values(by=['Original=Predicted?', 'Probability Of Top Most Prediction'], ascending=[True, False])
                      #Generate new csv file at the given location
                      DIR_NAME=current_DIR_NAME+r'\results'+'\\'+'Benchmark' + '\\'+projectName+r'\Interpretability\Results'
                      df.to_csv(os.path.join(DIR_NAME, 'limeoutput.csv'), index=False)
                      #Return a response
                      return Response("projectName %s" %projectName, status=200)
        except Exception as e:
              print(e)
              abort(400)

   else:
      return Response(status=400)
      


if __name__ == '__main__':
    app.run()

